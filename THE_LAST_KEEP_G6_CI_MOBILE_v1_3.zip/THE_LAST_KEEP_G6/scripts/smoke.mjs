// Browser smoke test against a running Vite preview, checks render and runtime errors.
import { chromium } from 'playwright';
const url=process.env.SMOKE_URL||'http://127.0.0.1:4173/';
const browser=await chromium.launch({headless:true,args:['--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1280,height:800}});
const errors=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
try{
 const response=await page.goto(url,{waitUntil:'networkidle',timeout:30000});
 if(!response?.ok())throw new Error('HTTP status '+response?.status());
 await page.waitForSelector('canvas',{timeout:15000});
 await page.waitForTimeout(1800);
 const result=await page.evaluate(()=>({title:document.title,canvases:document.querySelectorAll('canvas').length,webgl:[...document.querySelectorAll('canvas')].some(c=>!!(c.getContext('webgl2')||c.getContext('webgl')))}));
 await page.screenshot({path:'smoke-desktop.png'});
 if(errors.length)throw new Error('Browser errors: '+errors.join(' | '));
 if(!result.webgl)throw new Error('No WebGL canvas: '+JSON.stringify(result));
 console.log('Desktop smoke OK:',result);
 await page.setViewportSize({width:390,height:844});
 await page.reload({waitUntil:'networkidle'});
 await page.waitForTimeout(1000);
 await page.screenshot({path:'smoke-mobile.png'});
 if(errors.length)throw new Error('Browser errors: '+errors.join(' | '));
 console.log('Mobile viewport smoke OK');
}finally{await browser.close()}
