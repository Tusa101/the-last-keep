# G4.1 — Mobile Playtest / Input Integration (v0.9)

This is a continuation of G4 v0.8, not a new standalone demo.

## Mobile input
- Automatically activates on coarse-pointer/touch devices; desktop pointer-lock controls remain unchanged.
- Left virtual joystick: move relative to camera direction. Right-side drag: aim camera.
- Hold **Огонь** to fire, **↑** to jump; tap **Строить**, **Снести**, **Чинить**, **Добыть** for contextual actions at the reticle.
- Bottom toolbar: weapon, material, block shape, rotate, line build.
- Top toolbar: early wave, next wave, auto-purchase first affordable research, menu with save/load.
- Uses existing gameplay action logic and save format. No new resources or balance changes.

## QA / limitations
- Existing Node gameplay suite: 49/49 passing.
- Full TypeScript/Vite build and real mobile browser execution **not verified**: npm packages unavailable in offline cache.
- Mobile UX is a first-pass touch layout; landscape recommended. Portrait supported with reduced HUD, but cramped on small screens.
- Long-press fire and jump use pointer capture; joystick and camera support two simultaneous touches.
- Mobile line mode uses two taps on Build. Vertical columns remain desktop-only in this iteration.
- Browser must serve over HTTPS (GitHub Pages is suitable); publishing has NOT been performed.

## Playtest checklist
1. Open on Android Chrome / iOS Safari in landscape; ensure no pointer-lock prompt appears.
2. Move left joystick while aiming with right thumb; test diagonal movement and stairs.
3. Hold Fire during an active siege; check that walls block shots and camera keeps responding.
4. Gather X-equivalent using ⛏ near deposit, build with +, repair and remove with dedicated buttons.
5. Start early wave; complete wave; advance with Далее; purchase research with Наука.
6. Save and reload; verify world, resource deposits, research and wave persist.
7. Rotate device mid-session; ensure buttons stay accessible and gameplay remains responsive.
8. Repeat desktop WASD/pointer-lock regression checks.

## Next iteration after user playtest
Fix issues found on physical devices, then introduce G5 worker NPCs only after core loop usability is confirmed.
