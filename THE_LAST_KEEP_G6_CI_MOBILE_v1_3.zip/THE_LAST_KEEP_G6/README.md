# THE LAST KEEP — G6 v1.3

Full project, including G5.2 Architect Mode, mobile controls, workers, and siege. G6 adds deployment reliability.

See `MILESTONE_G6.md` and `deployment/README_RU.md`.

Run: `npm install && npm test && npm run build && npm run dev`.
