# THE LAST KEEP — G3.1 Combat & Siege Polish

**Version:** 0.7.0 · 10 October 2026  
**Status:** implemented source changes + deterministic unit tests. **Not yet browser-verified.**

## Delivered

1. **Correct 3D line-of-sight shooting.** `src/game/combat.ts` tests actual ray intersections against the complete volume of every block shape, including half-slabs and slits, and target spheres. Wall wins when closer than enemy. Aim pitch matters. No shooting through castle walls.
2. **Two distinguishable FPS weapons.** Basic crossbow bolt (35 HP; 0.35 sec cooldown) and research-unlocked spring carrot launcher (14 HP; 0.7 sec cooldown; knockback and temporary stun). Brutes resist push; blocked cells cannot be crossed by knockback. Both have lightweight first-person meshes and visible tracer.
3. **Two enemy roles.** Jellies move faster, weakly damage walls; brutes are slower but breach high-HP obstacles much faster. They use the same existing ground-only pathfinder.
4. **Real research choices.** After successful defense, spend earned research points on unlockable carrot launcher, a five-charge trap instead of a two-charge trap, or improved repairs (+55 HP vs +30 HP). **No more research→stone conversion.** Physical resources remain separate.
5. **Visual/sonic feedback.** Enemy health bars, status highlighting, muzzle recoil, short-lived hit/trap/death effects, synthesized browser sounds with mute (M), Nexus health bar and warning announcement.
6. **Siege save/restore.** Persist phase, wave, preparation timer, Nexus HP, accumulated research, technologies, the remaining charges, AI unit positions/health, player location/direction, current weapon, and world state. Validate data in temporary objects before applying it. Auto-save at the end of each wave, manual K/L at any phase; the save format has changed, older saves are **not** accepted by G3.1.
7. **Additional regression tests.** Combat occlusion, shot ordering, real arrow slit, raised slabs, weapon roles, upgrade budget rules, knockback collision, persistence, invalid saves, and wave invariants.

## Still missing / known limitations

- Dependencies weren't installable inside the creation environment (npm registry DNS unavailable). The project has **not** been Vite-built or launched in a browser here; do not claim browser correctness based solely on the passing unit tests.
- AI still navigates on a 2.5D ground grid. It cannot intelligently use stairs, multi-storey pathing, tunnels, or flying routes.
- Graphics remain programmer art. Enemies are primitive-based caricatures; no skeletal animation, full weapon reload sequence, bespoke particles, shaders or authored sounds.
- Block batch instances are rebuilt for every world change (not dirty chunk updates). Scale and framerate are unproven beyond small map tests.
- Siege rewards, waves, and weapon strengths are playtest hypotheses, not a finalized balance.
- No player HP/damage, mining loop, autonomous worker, physics-based block falling, proper roof/water simulations, or metaprogression in this milestone.
- Browser saves are local to an origin. Different GitHub Pages URLs/domains do not share localStorage.

## Verification actually performed

- `npm test` — **42/42 pass** on Node.js 22.
- `tsc --project tsconfig.core.json` — pass; core game/world/AI/physics TS checked.
- Source-only TypeScript transpilation of `main.ts` and `render/scene.ts` — no syntax diagnostics; not full typing or execution.
- `npm install` — failed/timed out due to DNS `EAI_AGAIN` for `registry.npmjs.org`.
- `npm run build` — **not verified**, because `three`, `vite`, and `@types/three` cannot be installed here.
- GitHub Pages — workflow present but **not deployed**.

## Acceptance checks to run in browser

1. From inside castle, aim at an approaching raider behind a solid wall and shoot; shot should strike the wall, leaving raider HP unchanged.
2. Move to a direct line of sight and shoot: enemy loses 35 HP; short beam and recoil appear.
3. During a break, use `5` to spend 20 knowledge on carrot gun; `E` changes weapon. It should visibly push away jelly enemies without moving through walls.
4. Try `6` or `7` on a different run: trap's five charges or faster repairs; no research may produce free building stone.
5. `K` during wave, refresh page, click scene, `L`: enemies, health, timer and unlocked research should resume correctly.
6. Survive three waves using modified walls; damage should persist. Verify no web-console errors.
7. Push `main` to an empty GitHub repository; ensure Pages action passes install/test/build/deploy and actual URL works with correct assets.
