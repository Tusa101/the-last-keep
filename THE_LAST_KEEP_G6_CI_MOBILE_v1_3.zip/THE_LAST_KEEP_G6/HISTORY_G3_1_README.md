# THE LAST KEEP · G3.1 Combat & Siege Polish · v0.7

First-person browser castle builder + siege defense prototype (Three.js, TypeScript, Vite). Stylized medieval castle, absurd attacking NPCs, direct player participation and persistent material damage. This is **source code for a technical prototype**, not the full game.

## Installation and local launch

Requires **Node.js 22+** and access to the npm registry.

```bash
npm install
npm test
npm run build
npm run dev
```

Open the URL printed by Vite in a desktop browser (mouse + keyboard). If dependencies cannot be downloaded due to a network restriction, use an environment with npm access. `npm run build` requires `three`, `vite`, and the Three.js type declarations.

## The three-wave game loop

1. Spawn in a partly ruined stone fortress. You start with limited wood and stone; repair and build a defensible passage.
2. Every ~90 seconds (or after `G`) the enemy arrives; a short warning precedes automatic arrival.
3. Waves advance from jelly recruits to the stone-breaking brute. Both will route around or break obstacles using ground-grid navigation.
4. Fire bolts in first person; optionally unlock a peculiar spring carrot launcher that pushes light enemies.
5. After each successful siege you gain **knowledge**, not stone. Unlock distinct abilities and continue with damage still in the walls.
6. Win after three waves or lose if the Nexus reaches zero.

## Controls

| Input | Action |
| --- | --- |
| WASD, mouse, Space | Walk, look, jump |
| Shift + left click | Shoot while siege is active |
| E | Switch between crossbow and researched carrot launcher |
| G | Call next siege early |
| N | Continue after successful wave (RESULT) |
| 5 / 6 / 7 | Research carrot launcher / improved trap / stronger repair (20 knowledge each) |
| M | Toggle synthesized sound |
| Right click | Build (or start/finish a line) |
| Left click (without Shift) | Dismantle aimed block; partial physical material return |
| F | Repair damaged block with physical resources |
| 1 / 2 / 3 / 4 | Stone / wood / cycle shape / stairs |
| Q | Rotate building piece |
| B / V | Horizontal line / vertical column building mode |
| Wheel while V active | Set vertical column height |
| K / L | Save / load complete run in localStorage |
| H | Reset to initial castle and initial game state |
| Esc | Release mouse and pause active world |

## Project layout

```text
src/
  main.ts             Desktop inputs, HUD, overall runtime
  world/              Data model, discrete structure checks, castle seed, shapes
  ai/                 Dynamic ground routing and breach AI
  physics/            FPS movement and collisions
  game/
    siege.ts          Time phases, attackers, weapons, rewards, research, persistence
    combat.ts         CPU 3D hits, block shape and target occlusion
    audio.ts          Small procedural browser sounds
  render/
    scene.ts          Three.js rendering, VFX, first-person weapon meshes
    batches.ts        Instanced batching plans
tests/                 Node built-in tests for core modules
```

## GitHub Pages deployment

Create a GitHub repository, commit **the contents of this folder at the repository root**, and push to `main`. Enable `Settings → Pages → Source: GitHub Actions`. `.github/workflows/deploy.yml` installs packages, runs tests, builds Vite, and deploys `dist/`. The Vite config automatically chooses the project repository base path when the `GITHUB_REPOSITORY` environment variable exists. Check deployment logs and open the actual URL; no deployment was performed as part of this ZIP creation.

## Verification and scope

See [`MILESTONE_G3_1.md`](MILESTONE_G3_1.md) for exact verification results and limitations. Key constraints: 2.5D enemy pathfinding, programmer art, single-player, small handcrafted map, no workers/mining gameplay yet. This version is a battle-loop validation prototype, not a polished commercial vertical slice.
