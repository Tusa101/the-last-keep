# G5 Validation Record (10 Oct 2026)

| Verification | Result | Evidence |
|---|---|---|
| Existing G0–G4 gameplay regression suite | PASS | 49 legacy Node tests |
| New worker tests | PASS | 12 tests in `tests/workers.test.mjs` |
| Total Node test suite | **61/61 PASS** | `npm test` |
| Strict standalone core TypeScript check | PASS | `npm run typecheck:core` |
| TypeScript syntax/transpilation of modified game and rendering TS files | PASS | `transpileModule` on six changed modules |
| Routing in seeded castle | Manual Node smoke PASS | Stockpile to all five physical deposits reachable |
| Full TS check including Three.js types | **NOT RUN / blocked** | npm registry DNS error `EAI_AGAIN` when retrieving dependencies |
| Production Vite build | **NOT RUN / blocked** | npm installation unavailable |
| Interactive desktop Chrome WebGL QA | **NOT TESTED** | no bundled Three.js dependency to run browser build |
| Android Chrome / iOS Safari gameplay | **NOT TESTED** | real devices/browser link unavailable |
| GitHub Pages | **NOT DEPLOYED** | workflow included only |

## Notes

Test code verifies model logic, not every WebGL interaction. It would be misleading to claim the game is fully playable or mobile-polished without the remaining build and browser checks. Runtime environment for offline Node tests was Node.js 22.16.0. No downloaded assets or fonts are required by this milestone.

## Commands

```bash
npm install
npm test
npm run typecheck:core
npm run build
npm run dev
```

If `npm install` fails, a machine with npm registry access is necessary. Do not skip the build check and assume CI deployed successfully.
