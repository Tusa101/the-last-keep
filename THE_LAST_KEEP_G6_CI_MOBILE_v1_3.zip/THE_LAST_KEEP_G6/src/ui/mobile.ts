/** Touch-first controls. No synthetic mouse clicks or pointer-lock required. */
export type MobileAction = 'fire'|'build'|'remove'|'repair'|'gather'|'jump'|'weapon'|'material'|'shape'|'rotate'|'line'|'wave'|'next'|'research'|'save'|'load'|'menu'|'worker'|'order'|'priority'|'cancel'|'quality'|'architect'|'help';
export function isTouchDevice(){return matchMedia('(pointer: coarse)').matches || ('ontouchstart' in window);}
export function installMobileControls(onLook:(dx:number,dy:number)=>void,onAction:(action:MobileAction)=>void){
 const root=document.createElement('div');root.id='mobile-controls';
 root.innerHTML=`<div id="touch-look" aria-label="Область поворота камеры"></div>
 <div class="mobile-top"><button data-action="menu">☰</button><button data-action="wave">⚑ Волна</button><button data-action="next">→ Далее</button><button data-action="research">✦ Наука</button></div>
 <div class="mobile-joystick" id="mobile-joystick" aria-label="Джойстик движения"><div id="joystick-knob"></div></div>
 <div class="mobile-actions"><button data-action="jump">↑</button><button data-action="fire" class="primary">⚔ Огонь</button><button data-action="build">＋ Строить</button><button data-action="remove">− Снести</button><button data-action="repair">✚ Чинить</button><button data-action="gather">⛏ Добыть</button></div>
 <div class="mobile-tools"><button data-action="weapon">Оружие</button><button data-action="material">Материал</button><button data-action="shape">Форма</button><button data-action="rotate">↻</button><button data-action="line">Линия</button></div>
 <div class="mobile-menu" id="mobile-menu" hidden><button data-action="architect">🏰 Архитектор</button><button data-action="worker">👷 Нанять</button><button data-action="order">⚒ Поручить стройку</button><button data-action="priority">↻ Задачи</button><button data-action="cancel">× Очередь</button><button data-action="quality">⚙ Графика: авто</button><button data-action="help">? Справка</button><button data-action="save">Сохранить</button><button data-action="load">Загрузить</button><button data-action="menu">Закрыть</button></div>`;
 document.body.append(root);
 let move={x:0,y:0};let joystickPointer:number|null=null;let lookPointer:number|null=null;let lastX=0,lastY=0;
 const joystick=root.querySelector<HTMLElement>('#mobile-joystick')!,knob=root.querySelector<HTMLElement>('#joystick-knob')!;
 const update=(e:PointerEvent)=>{const r=joystick.getBoundingClientRect();const x=e.clientX-(r.left+r.width/2),y=e.clientY-(r.top+r.height/2);const max=42;const len=Math.hypot(x,y)||1;const scale=Math.min(1,max/len);move={x:x*scale/max,y:y*scale/max};knob.style.transform=`translate(${move.x*max}px,${move.y*max}px)`;};
 joystick.addEventListener('pointerdown',e=>{if(joystickPointer!==null)return;e.preventDefault();joystickPointer=e.pointerId;joystick.setPointerCapture(e.pointerId);update(e);});
 joystick.addEventListener('pointermove',e=>{if(e.pointerId===joystickPointer)update(e);});
 const resetMove=(e:PointerEvent)=>{if(e.pointerId===joystickPointer){joystickPointer=null;move={x:0,y:0};knob.style.transform='translate(0,0)';}};
 joystick.addEventListener('pointerup',resetMove);joystick.addEventListener('pointercancel',resetMove);joystick.addEventListener('lostpointercapture',resetMove);
 const look=root.querySelector<HTMLElement>('#touch-look')!;
 look.addEventListener('pointerdown',e=>{if(lookPointer!==null)return;e.preventDefault();lookPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;look.setPointerCapture(e.pointerId);});
 look.addEventListener('pointermove',e=>{if(e.pointerId!==lookPointer)return;onLook(e.clientX-lastX,e.clientY-lastY);lastX=e.clientX;lastY=e.clientY;});
 const endLook=(e:PointerEvent)=>{if(e.pointerId===lookPointer)lookPointer=null;};
 look.addEventListener('pointerup',endLook);look.addEventListener('pointercancel',endLook);look.addEventListener('lostpointercapture',endLook);
 const held=new Set<MobileAction>();
 const resetAll=()=>{joystickPointer=null;lookPointer=null;move={x:0,y:0};held.clear();knob.style.transform='translate(0,0)';};
 window.addEventListener('blur',resetAll);document.addEventListener('visibilitychange',()=>{if(document.hidden)resetAll();});
 root.querySelectorAll<HTMLButtonElement>('button[data-action]').forEach(button=>{
  const action=button.dataset.action as MobileAction;
  button.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();button.setPointerCapture(e.pointerId);if(action==='fire'||action==='jump')held.add(action);else onAction(action);});
  for(const name of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(name,()=>held.delete(action));
 });
 return {root,getMove:()=>move,isHeld:(a:MobileAction)=>held.has(a),setQualityLabel:(label:string)=>{const button=root.querySelector<HTMLButtonElement>('[data-action=quality]');if(button)button.textContent=`⚙ Графика: ${label}`;},toggleMenu:()=>{const menu=root.querySelector<HTMLElement>('#mobile-menu')!;menu.hidden=!menu.hidden;},destroy:()=>{window.removeEventListener('blur',resetAll);root.remove();}};
}
