import type {World,Cell,Material,Shape,Orientation} from '../world/model.ts';
import type {Workers} from '../game/workers.ts';
import {gridToScreen,screenToGrid,planLine,planRectangle,type Point} from '../game/architect.ts';
export type Architect={open:()=>void;close:()=>void;toggle:()=>void;isOpen:()=>boolean};
export function installArchitect(world:World,workers:Workers,onMessage:(s:string)=>void,onOpen:(open:boolean)=>void):Architect{
 const root=document.createElement('section');root.id='architect';root.hidden=true;
 root.innerHTML=`<div class="architect-panel"><header><strong>⚒ ПЛАН КРЕПОСТИ</strong><button data-cmd="close">✕ Закрыть</button></header><p>Вид сверху · коснись начала и конца стены. Чертёж появится на карте, рабочие построят его постепенно.</p><div class="architect-layout"><canvas width="630" height="630" aria-label="План крепости, нажми для выбора клеток"></canvas><aside><label>Постройка<select id="architect-tool"><option value="line">Стена / линия</option><option value="rectangle">Контур башни</option></select></label><label>Материал<select id="architect-material"><option value="stone">Камень</option><option value="wood">Дерево</option></select></label><label>Форма<select id="architect-shape"><option value="full">Куб</option><option value="slab">Плита</option><option value="stair">Лестница</option><option value="battlement">Зубцы</option><option value="arrowSlit">Бойница</option></select></label><label>Высота (этаж)<input id="architect-level" type="number" min="0" max="10" value="0"></label><label>Ориентация<select id="architect-dir"><option value="0">+X</option><option value="1">+Z</option><option value="2">−X</option><option value="3">−Z</option></select></label><div class="architect-status" aria-live="polite"></div><button data-cmd="confirm">👷 Передать рабочим</button><button data-cmd="undo">↶ Сбросить выделение</button><button data-cmd="cancel">× Очистить очередь</button><p class="architect-hint">Не более 24 блоков за поручение. Нужен хотя бы один рабочий. Очередь ограничена 60 блоками. Материалы списываются при строительстве.</p></aside></div></div>`;
 document.body.append(root);
 const canvas=root.querySelector('canvas')!,ctx=canvas.getContext('2d')!;
 const status=root.querySelector<HTMLElement>('.architect-status')!;
 const get=<T extends HTMLElement>(id:string)=>root.querySelector<T>('#'+id)!;
 let first:Point|null=null,last:Point|null=null,open=false;
 const cells=():Cell[]=>{if(!first||!last)return [];const y=Number(get<HTMLInputElement>('architect-level').value);
  return get<HTMLSelectElement>('architect-tool').value==='rectangle'?planRectangle(first,last,y):planLine(first,last,y);};
 function draw(){
  const w=canvas.width,h=canvas.height;ctx.fillStyle='#243a30';ctx.fillRect(0,0,w,h);
  const step=w/45;ctx.strokeStyle='#ffffff19';ctx.lineWidth=1;
  for(let i=0;i<=45;i++){ctx.beginPath();ctx.moveTo(i*step,0);ctx.lineTo(i*step,h);ctx.moveTo(0,i*step);ctx.lineTo(w,i*step);ctx.stroke();}
  const y=Number(get<HTMLInputElement>('architect-level').value);
  for(const [k,b] of world.blocks){const [x,by,z]=k.split(',').map(Number);if(by!==y)continue;const p=gridToScreen(x,z,w,h);
   ctx.fillStyle=b.material==='stone'?'#b5aa93':'#a4764e';ctx.fillRect(p.x-step*.46,p.y-step*.46,step*.92,step*.92);}
  for(const order of workers.orders){if(order.cell.y!==y)continue;const p=gridToScreen(order.cell.x,order.cell.z,w,h);ctx.fillStyle='#6fe4b6aa';ctx.fillRect(p.x-step*.46,p.y-step*.46,step*.92,step*.92);}
  const selection=cells();for(const c of selection){const p=gridToScreen(c.x,c.z,w,h);ctx.fillStyle='#f6c965cc';ctx.fillRect(p.x-step*.46,p.y-step*.46,step*.92,step*.92);}
  const nexus=gridToScreen(9,0,w,h);ctx.fillStyle='#80ffff';ctx.beginPath();ctx.arc(nexus.x,nexus.y,step*.75,0,Math.PI*2);ctx.fill();
  status.textContent=`Выделено: ${selection.length} блоков · очередь: ${workers.orders.length}/60 · рабочих: ${workers.workers.length} · камень: ${Math.floor(world.resources.stone)} · дерево: ${Math.floor(world.resources.wood)}`+(first&&!selection.length?' · слишком большой контур':'');
 }
 canvas.addEventListener('pointerdown',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();const point=screenToGrid((e.clientX-r.left)/r.width*canvas.width,(e.clientY-r.top)/r.height*canvas.height,canvas.width,canvas.height);
  if(!first||last){first=point;last=null;}else last=point;draw();});
 root.querySelectorAll('select,input').forEach(el=>el.addEventListener('change',draw));
 function close(){open=false;root.hidden=true;onOpen(false);}
 function show(){open=true;root.hidden=false;onOpen(true);draw();}
 root.addEventListener('click',e=>{const cmd=(e.target as HTMLElement).closest<HTMLButtonElement>('[data-cmd]')?.dataset.cmd;
  if(cmd==='close')close();if(cmd==='undo'){first=null;last=null;draw();}
  if(cmd==='cancel'){const count=workers.clearOrders();onMessage(`Отменено заданий: ${count}`);draw();}
  if(cmd==='confirm'){
   const plan=cells();if(!plan.length){onMessage('Ошибка: выбери начало и конец, не более 24 блоков');return;}
   const result=workers.queueBuild(plan,get<HTMLSelectElement>('architect-material').value as Material,get<HTMLSelectElement>('architect-shape').value as Shape,Number(get<HTMLSelectElement>('architect-dir').value) as Orientation);
   onMessage(result.message);if(result.ok){first=null;last=null;}draw();
  }
 });
 world.onChange(()=>{if(open)draw();});
 return {open:show,close,toggle:()=>open?close():show(),isOpen:()=>open};
}
