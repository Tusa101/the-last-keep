import {World,LIMIT} from '../world/model.ts';
export type Waypoint={x:number;z:number};
export type Route={cells:Waypoint[];cost:number;breaches:number};
const id=(x:number,z:number)=>`${x},${z}`;
type Item={x:number;z:number;score:number};
class Heap{
 private a:Item[]=[];
 push(value:Item){const a=this.a;a.push(value);let i=a.length-1;while(i){const p=(i-1)>>1;if(a[p].score<=value.score)break;a[i]=a[p];i=p;}a[i]=value;}
 pop():Item|undefined{const a=this.a;if(!a.length)return;const top=a[0],last=a.pop()!;if(a.length){let i=0;while(true){let c=i*2+1;if(c>=a.length)break;if(c+1<a.length&&a[c+1].score<a[c].score)c++;if(a[c].score>=last.score)break;a[i]=a[c];i=c;}a[i]=last;}return top;}
 get size(){return this.a.length;}
}
/** A* on ground projection. Explicit breach cost for 1–2 stacked blocks. */
export function findRoute(world:World,start:Waypoint,goal:Waypoint):Route|null{
 if(![start,goal].every(p=>Number.isInteger(p.x)&&Number.isInteger(p.z)&&Math.abs(p.x)<=LIMIT&&Math.abs(p.z)<=LIMIT))return null;
 const origin=id(start.x,start.z),target=id(goal.x,goal.z),dist=new Map([[origin,0]]),prev=new Map<string,string>(),closed=new Set<string>(),heap=new Heap();
 const h=(x:number,z:number)=>Math.abs(x-goal.x)+Math.abs(z-goal.z);
 heap.push({...start,score:h(start.x,start.z)});
 while(heap.size){const item=heap.pop()!,current=id(item.x,item.z);if(closed.has(current))continue;closed.add(current);
  if(current===target){const cells:Waypoint[]=[];let n=target;while(n!==origin){const [x,z]=n.split(',').map(Number);cells.push({x,z});n=prev.get(n)!;}cells.reverse();return {cells,cost:dist.get(current)!,breaches:cells.filter(p=>world.groundObstructions(p.x,p.z).length>0).length};}
  for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const x=item.x+dx,z=item.z+dz;if(Math.abs(x)>LIMIT||Math.abs(z)>LIMIT)continue;
   const k=id(x,z);if(closed.has(k))continue;
   const penalty=world.groundObstructions(x,z).reduce((v,c)=>v+Math.ceil(world.get(c.x,c.y,c.z)!.hp/22)*3,0);
   const candidate=dist.get(current)!+1+penalty;if(candidate<(dist.get(k)??Infinity)){dist.set(k,candidate);prev.set(k,current);heap.push({x,z,score:candidate+h(x,z)});}
  }
 }
 return null;
}
