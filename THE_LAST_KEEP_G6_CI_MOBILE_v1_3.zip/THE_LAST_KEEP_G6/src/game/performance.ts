/** Bounded, deterministic adaptive rendering controller (no WebGL dependency). */
export type QualityMode='auto'|'battery'|'quality';
export class AdaptiveQuality {
 mode:QualityMode='auto';
 scale=1;
 private samples:number[]=[];
 private cooldown=0;
 setMode(mode:QualityMode){this.mode=mode;this.samples=[];this.cooldown=0;this.scale=mode==='battery'?.65:mode==='quality'?1.35:1;return this.scale;}
 observe(frameSeconds:number){
  if(!Number.isFinite(frameSeconds)||frameSeconds<=0||frameSeconds>.25)return false;
  if(this.mode!=='auto')return false;
  this.samples.push(frameSeconds);if(this.samples.length<120)return false;
  const average=this.samples.reduce((a,b)=>a+b,0)/this.samples.length;
  this.samples=[];
  if(this.cooldown>0){this.cooldown--;return false;}
  const old=this.scale;
  if(average>1/42)this.scale=Math.max(.55,Math.round((this.scale-.15)*100)/100);
  else if(average<1/58)this.scale=Math.min(1.2,Math.round((this.scale+.1)*100)/100);
  if(old!==this.scale){this.cooldown=1;return true;}
  return false;
 }
 reset(){this.samples=[];}
}
