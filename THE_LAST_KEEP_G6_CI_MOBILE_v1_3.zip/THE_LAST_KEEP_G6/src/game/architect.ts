import type {Cell} from '../world/model.ts';
export const MAP_MIN=-22,MAP_MAX=22;
export type Point={x:number;z:number};
export function clampGrid(n:number){return Math.max(MAP_MIN,Math.min(MAP_MAX,Math.round(n)));}
export function screenToGrid(px:number,py:number,width:number,height:number):Point{
 const size=Math.max(1,Math.min(width,height));const left=(width-size)/2,top=(height-size)/2;
 return {x:clampGrid((px-left)/size*45-22.5),z:clampGrid((py-top)/size*45-22.5)};
}
export function gridToScreen(x:number,z:number,width:number,height:number){
 const size=Math.min(width,height),step=size/45;
 return {x:(width-size)/2+(x+22.5)*step,y:(height-size)/2+(z+22.5)*step};
}
export function planLine(a:Point,b:Point,y:number):Cell[]{
 const dx=b.x-a.x,dz=b.z-a.z,alongX=Math.abs(dx)>=Math.abs(dz),len=Math.min(24,Math.abs(alongX?dx:dz)+1);
 return Array.from({length:len},(_,i)=>({x:clampGrid(a.x+(alongX?Math.sign(dx)*i:0)),y,z:clampGrid(a.z+(!alongX?Math.sign(dz)*i:0))}));
}
export function planRectangle(a:Point,b:Point,y:number):Cell[]{
 const x0=Math.min(a.x,b.x),x1=Math.max(a.x,b.x),z0=Math.min(a.z,b.z),z1=Math.max(a.z,b.z);
 const cells:Cell[]=[];for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++){
  if(x===x0||x===x1||z===z0||z===z1)cells.push({x,y,z});
  if(cells.length>24)return [];
 }return cells;
}
