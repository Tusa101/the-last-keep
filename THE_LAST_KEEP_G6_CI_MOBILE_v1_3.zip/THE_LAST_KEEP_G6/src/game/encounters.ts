/** Deterministic assault staging; art/UI, spawns and testing share one plan.
 * Future waves remain proposals, these three encounters are the G4 playable slice. */
export type AssaultFront='west'|'north';
export type Intel={wave:1|2|3;title:string;brief:string;fronts:AssaultFront[];jellies:number;brutes:number};
export const ENCOUNTERS:readonly Intel[]=[
 {wave:1,title:'ПРОБА ВОРОТ',brief:'Западный дозор сообщает о желейном авангарде. Закрой пролом!',fronts:['west'],jellies:4,brutes:0},
 {wave:2,title:'ТЯЖЁЛАЯ ПОСЫЛКА',brief:'На западном тракте замечен карамельный таран. Береги опоры!',fronts:['west'],jellies:5,brutes:1},
 {wave:3,title:'ДВА ЗНАМЕНИ',brief:'Главный удар с запада, обходной отряд с севера. Раздели оборону!',fronts:['west','north'],jellies:7,brutes:1}
];
export function waveIntel(wave:number):Intel{return ENCOUNTERS[Math.max(0,Math.min(2,Math.floor(wave)-1))];}
export function nextIntel(currentWave:number):Intel|null{return currentWave>=3?null:waveIntel(currentWave+1);}
/** All spawn cells are outside the curtain walls; waves > 2 really use two axes. */
export function raiderSpawn(wave:number,index:number,count:number):{x:number;z:number;front:AssaultFront}{
 if(wave>=3&&index>=Math.ceil(count/2)){
  const lane=index-Math.ceil(count/2);
  return {x:-3+lane%4*2,z:-17-Math.floor(lane/4),front:'north'};
 }
 return {x:-17-Math.floor(index/3),z:(index%3-1)*2,front:'west'};
}
export function clockLabel(seconds:number){const n=Math.max(0,Math.ceil(Number.isFinite(seconds)?seconds:0));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;}
export function phaseLabel(phase:string):string{return ({PREP:'ПОДГОТОВКА',WARNING:'АРМИЯ БЛИЗКО',SIEGE:'ОСАДА',RESULT:'ОТБИТО',VICTORY:'ПОБЕДА',DEFEAT:'НЕКСУС ПАЛ'} as Record<string,string>)[phase]??phase;}
