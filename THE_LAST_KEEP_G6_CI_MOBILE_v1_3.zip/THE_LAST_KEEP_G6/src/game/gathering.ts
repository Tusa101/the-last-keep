import type {Material,World} from '../world/model.ts';
export type Deposit={id:string;material:Material;x:number;z:number;remaining:number;capacity:number};
export type GatherResult={ok:boolean;reason:string;material?:Material;amount:number;id?:string};
export const BASE_DEPOSITS:readonly Deposit[]=[
 {id:'fallen_masonry',material:'stone',x:3,z:6,remaining:18,capacity:18},
 {id:'west_quarry',material:'stone',x:-14,z:4,remaining:65,capacity:65},
 {id:'south_quarry',material:'stone',x:17,z:10,remaining:48,capacity:48},
 {id:'east_copse',material:'wood',x:16,z:-13,remaining:38,capacity:38},
 {id:'south_timber',material:'wood',x:-5,z:12,remaining:34,capacity:34}
];
/** Simple early-loop hand collection. Physically finite deposits, no score->stone conversion.
 * A later milestone can attach animations/tool hits, carrying, terrain editing and NPC work. */
export class Gathering{
 readonly deposits:Deposit[]=BASE_DEPOSITS.map(d=>({...d}));
 private cooldownUntil=0;
 readonly world:World;
 constructor(world:World){this.world=world;}
 nearest(x:number,z:number,radius=2.8):Deposit|null{
  let best:Deposit|null=null,d=radius;
  for(const deposit of this.deposits){if(deposit.remaining<=0)continue;
   const distance=Math.hypot(x-deposit.x,z-deposit.z);
   if(distance<=d){best=deposit;d=distance;}
  }return best;
 }
 harvest(x:number,z:number,now:number):GatherResult{
  if(![x,z,now].every(Number.isFinite))return {ok:false,reason:'Некорректные координаты',amount:0};
  const deposit=this.nearest(x,z);if(!deposit)return {ok:false,reason:'Подойди к карьеру или древесному складу (≤ 2.8 м)',amount:0};
  if(now<this.cooldownUntil)return {ok:false,reason:'Инструмент ещё не готов',amount:0};
  const amount=Math.min(deposit.material==='stone'?6:5,deposit.remaining);
  deposit.remaining-=amount;this.world.resources[deposit.material]+=amount;
  this.cooldownUntil=now+.65;
  return {ok:true,reason:'Добыто',material:deposit.material,amount,id:deposit.id};
 }
 snapshot():string{return JSON.stringify({version:1,deposits:this.deposits.map(d=>({id:d.id,remaining:d.remaining}))});}
 restore(json:string){const state=JSON.parse(json) as {version:number;deposits:{id:string;remaining:number}[]};
  if(state.version!==1||!Array.isArray(state.deposits)||state.deposits.length!==this.deposits.length)throw Error('Invalid gathering save');
  const next=new Map<string,number>();for(const entry of state.deposits){
   const base=BASE_DEPOSITS.find(n=>n.id===entry?.id);
   if(!base||next.has(entry.id)||!Number.isInteger(entry.remaining)||entry.remaining<0||entry.remaining>base.capacity)throw Error('Invalid resource deposit');
   next.set(entry.id,entry.remaining);
  }
  if(next.size!==this.deposits.length)throw Error('Missing deposits');
  for(const d of this.deposits)d.remaining=next.get(d.id)!;
  this.cooldownUntil=0;
 }
 reset(){for(const d of this.deposits){const original=BASE_DEPOSITS.find(n=>n.id===d.id)!;d.remaining=original.capacity;}this.cooldownUntil=0;}
}
