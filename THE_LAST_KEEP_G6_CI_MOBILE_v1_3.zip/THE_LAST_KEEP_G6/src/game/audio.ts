/** Optional, synthesized one-shots. Created on first mouse gesture, no downloadable assets. */
export class Sfx{
 private context:AudioContext|null=null;enabled=true;
 play(kind:'bolt'|'carrot'|'hit'|'trap'|'alarm'){
  if(!this.enabled||typeof AudioContext==='undefined')return;
  try{
   this.context??=new AudioContext();if(this.context.state==='suspended')void this.context.resume();
   const t=this.context.currentTime,osc=this.context.createOscillator(),gain=this.context.createGain();
   const presets={bolt:[220,110,.11,.07],carrot:[480,115,.22,.10],hit:[150,65,.10,.06],
    trap:[600,120,.25,.12],alarm:[310,420,.45,.10]} as const;
   const [start,end,duration,volume]=presets[kind];osc.type=kind==='carrot'?'triangle':'sawtooth';
   osc.frequency.setValueAtTime(start,t);osc.frequency.exponentialRampToValueAtTime(end,t+duration);
   gain.gain.setValueAtTime(volume,t);gain.gain.exponentialRampToValueAtTime(.001,t+duration);
   osc.connect(gain);gain.connect(this.context.destination);osc.start(t);osc.stop(t+duration+.02);
   osc.addEventListener('ended',()=>{osc.disconnect();gain.disconnect();},{once:true});
  }catch{/* Audio can be unavailable in privacy-restricted browsers. Gameplay still works. */}
 }
}
