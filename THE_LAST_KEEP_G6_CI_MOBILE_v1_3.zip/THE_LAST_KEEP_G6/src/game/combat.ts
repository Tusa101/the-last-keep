/** CPU-side 3D line-of-sight combat; independent of renderer or Three.js. */
import {World,type Cell} from '../world/model.ts';
import {shapeBoxes} from '../world/shapes.ts';
export type Vec3={x:number;y:number;z:number};
export type Target={id:number;position:Vec3;radius:number};
export type Hit={kind:'enemy'|'wall'|'miss';distance:number;point:Vec3;targetId?:number;cell?:Cell};
const EPS=1e-8;
export function normalize(v:Vec3):Vec3|null{
 const mag=Math.hypot(v.x,v.y,v.z);
 return mag>EPS&&Number.isFinite(mag)?{x:v.x/mag,y:v.y/mag,z:v.z/mag}:null;
}
function boxRay(o:Vec3,d:Vec3,lo:Vec3,hi:Vec3):number|null{
 let near=-Infinity,far=Infinity;
 for(const axis of ['x','y','z'] as const){
  if(Math.abs(d[axis])<EPS){if(o[axis]<lo[axis]||o[axis]>hi[axis])return null;continue;}
  let a=(lo[axis]-o[axis])/d[axis],b=(hi[axis]-o[axis])/d[axis];
  if(a>b)[a,b]=[b,a];near=Math.max(near,a);far=Math.min(far,b);
  if(near>far)return null;
 }
 return far>=0?Math.max(0,near):null;
}
function sphereRay(o:Vec3,d:Vec3,p:Vec3,radius:number):number|null{
 const ox=o.x-p.x,oy=o.y-p.y,oz=o.z-p.z;
 const b=ox*d.x+oy*d.y+oz*d.z,c=ox*ox+oy*oy+oz*oz-radius*radius;
 const disc=b*b-c;if(disc<0)return null;
 const first=-b-Math.sqrt(disc),last=-b+Math.sqrt(disc);
 return last>=0?Math.max(0,first):null;
}
/** Finds the first actual shape or enemy sphere, not just the closest angle. */
export function traceShot(world:World,origin:Vec3,rawDirection:Vec3,targets:Target[],maxDistance=22):Hit{
 const dir=normalize(rawDirection);if(!dir||!Number.isFinite(maxDistance)||maxDistance<=0)
  return {kind:'miss',distance:0,point:{...origin}};
 let best=maxDistance,kind:Hit['kind']='miss',targetId:number|undefined,cell:Cell|undefined;
 for(const [name,block] of world.blocks){
  const [x,y,z]=name.split(',').map(Number);
  if(Math.abs(x-origin.x)>best+1.5||Math.abs(y-origin.y)>best+1.5||Math.abs(z-origin.z)>best+1.5)continue;
  for(const b of shapeBoxes(block.shape,block.dir)){
   const t=boxRay(origin,dir,{x:x+b.x0,y:y+b.y0,z:z+b.z0},{x:x+b.x1,y:y+b.y1,z:z+b.z1});
   if(t!==null&&t<best){best=t;kind='wall';cell={x,y,z};targetId=undefined;}
  }
 }
 for(const target of targets){
  const t=sphereRay(origin,dir,target.position,target.radius);
  if(t!==null&&t<best-1e-5){best=t;kind='enemy';targetId=target.id;cell=undefined;}
 }
 const point={x:origin.x+dir.x*best,y:origin.y+dir.y*best,z:origin.z+dir.z*best};
 return {kind,distance:best,point,targetId,cell};
}
