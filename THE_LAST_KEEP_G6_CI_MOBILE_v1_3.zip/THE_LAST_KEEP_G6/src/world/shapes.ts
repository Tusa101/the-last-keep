/** Logical colliders and visual primitives share one shape definition. Local boxes are
 * centered around the X/Z cell, and Y is measured upward from the cell floor.
 * Orientation: 0 = rise/front +X; 1 = +Z; 2 = -X; 3 = -Z.
 */
export type Shape='full'|'slab'|'stair'|'battlement'|'arrowSlit';
export type Orientation=0|1|2|3;
export type Box={x0:number;x1:number;y0:number;y1:number;z0:number;z1:number};
export const SHAPES:readonly Shape[]=['full','slab','stair','battlement','arrowSlit'];
export const isShape=(s:unknown):s is Shape=>typeof s==='string'&&SHAPES.includes(s as Shape);
export const isOrientation=(d:unknown):d is Orientation=>Number.isInteger(d)&&Number(d)>=0&&Number(d)<=3;
const b=(x0:number,x1:number,y0:number,y1:number,z0:number,z1:number):Box=>({x0,x1,y0,y1,z0,z1});
const local:Record<Shape,readonly Box[]>={
 full:[b(-.5,.5,0,1,-.5,.5)],
 slab:[b(-.5,.5,0,.5,-.5,.5)],
 // Two actual half-meter steps: can be walked up, no invisible ramp collision.
 stair:[b(-.5,0,0,.5,-.5,.5),b(0,.5,0,1,-.5,.5)],
 // Traditional crenellation: stone base and two separated raised merlons.
 battlement:[b(-.5,.5,0,.45,-.5,.5),b(-.5,.5,.45,1,-.5,-.31),b(-.5,.5,.45,1,.31,.5)],
 // Thin vertical firing aperture; it is narrow enough to block the player.
 arrowSlit:[b(-.5,.5,0,.21,-.5,.5),b(-.5,.5,.21,.83,-.5,-.23),b(-.5,.5,.21,.83,.23,.5),b(-.5,.5,.83,1,-.5,.5)]
};
function rotatePoint(x:number,z:number,d:Orientation):[number,number]{
 switch(d){case 0:return [x,z];case 1:return [-z,x];case 2:return [-x,-z];case 3:return [z,-x];}
}
export function shapeBoxes(shape:Shape,dir:Orientation=0):Box[]{
 return local[shape].map(v=>{
  const points=[rotatePoint(v.x0,v.z0,dir),rotatePoint(v.x0,v.z1,dir),rotatePoint(v.x1,v.z0,dir),rotatePoint(v.x1,v.z1,dir)];
  return b(Math.min(...points.map(p=>p[0])),Math.max(...points.map(p=>p[0])),v.y0,v.y1,
   Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[1])));
 });
}
