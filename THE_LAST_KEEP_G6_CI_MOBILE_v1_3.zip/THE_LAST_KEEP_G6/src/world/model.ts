/** Authoritative, deterministic game state: Three.js never owns gameplay state. */
import {isShape,isOrientation,type Shape,type Orientation} from './shapes.ts';
export type {Shape,Orientation} from './shapes.ts';
export type Material='stone'|'wood';
export type Cell={x:number;y:number;z:number};
export type Block={material:Material;shape:Shape;dir:Orientation;hp:number};
export type Result={ok:boolean;reason:string;cost:number};
export const LIMIT=22,HEIGHT=10,MAX_CANTILEVER=3;
export const key=(x:number,y:number,z:number)=>`${x},${y},${z}`;
export const maxHP=(m:Material)=>m==='stone'?100:55;
export const inBounds=(c:Cell)=>[c.x,c.y,c.z].every(Number.isInteger)&&Math.abs(c.x)<=LIMIT&&Math.abs(c.z)<=LIMIT&&c.y>=0&&c.y<=HEIGHT;
const directions=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]] as const;
export class World{
 readonly blocks=new Map<string,Block>();readonly processed=new Set<string>();
 readonly listeners=new Set<(reason:string)=>void>();
 resources:Record<Material,number>={stone:90,wood:45};revision=0;
 get(x:number,y:number,z:number){return this.blocks.get(key(x,y,z));}
 seed(c:Cell,material:Material='stone',shape:Shape='full',dir:Orientation=0){
  if(!inBounds(c)||!isShape(shape)||!isOrientation(dir))throw Error('Invalid seed');
  this.blocks.set(key(c.x,c.y,c.z),{material,shape,dir,hp:maxHP(material)});
 }
 onChange(l:(reason:string)=>void){this.listeners.add(l);return ()=>this.listeners.delete(l);}
 private changed(reason:string){this.revision++;for(const l of this.listeners)l(reason);}
 /** Discrete bearing check. Grounded cells seed the graph with zero sideways reach.
  * Moving vertically costs zero; each horizontal face-to-face connection costs one.
  * A section more than 3 horizontal connections away from grounded masonry falls.
  * This is intentionally NOT a full load/torque/weight simulation. */
 private anchored(occupied:Set<string>){
  const distance=new Map<string,number>(),buckets:string[][]=Array.from({length:MAX_CANTILEVER+1},()=>[]);
  for(const k of occupied){const [,y]=k.split(',').map(Number);if(y===0){distance.set(k,0);buckets[0].push(k);}}
  for(let cost=0;cost<=MAX_CANTILEVER;cost++){
   for(let i=0;i<buckets[cost].length;i++){
    const current=buckets[cost][i];if(distance.get(current)!==cost)continue;
    const [x,y,z]=current.split(',').map(Number);
    for(const [dx,dy,dz] of directions){const k=key(x+dx,y+dy,z+dz);
     const next=cost+(dy===0?1:0);
     if(next>MAX_CANTILEVER||!occupied.has(k)||next>=(distance.get(k)??Infinity))continue;
     distance.set(k,next);buckets[next].push(k);
    }
   }
  }
  return new Set(distance.keys());
 }
 checkBuild(cells:Cell[],material:Material):Result{
  if(!cells.length||cells.length>24)return {ok:false,reason:'Лимит 1–24 блока',cost:cells.length};
  const incoming=new Set<string>();
  for(const c of cells){if(!inBounds(c))return {ok:false,reason:'Вне границ мира',cost:cells.length};
   const k=key(c.x,c.y,c.z);if(incoming.has(k)||this.blocks.has(k))return {ok:false,reason:'Клетка занята',cost:cells.length};incoming.add(k);
  }
  if(material!=='stone'&&material!=='wood')return {ok:false,reason:'Материал недоступен',cost:cells.length};
  if(this.resources[material]<cells.length)return {ok:false,reason:'Не хватает ресурсов',cost:cells.length};
  const supported=this.anchored(new Set([...this.blocks.keys(),...incoming]));
  if([...incoming].some(k=>!supported.has(k)))return {ok:false,reason:`Пролёт > ${MAX_CANTILEVER} клеток без опоры`,cost:cells.length};
  return {ok:true,reason:'Можно строить',cost:cells.length};
 }
 build(id:string,cells:Cell[],material:Material,shape:Shape='full',dir:Orientation=0):Result{
  if(this.processed.has(id))return {ok:false,reason:'Операция уже обработана',cost:0};
  if(!isShape(shape)||!isOrientation(dir))return {ok:false,reason:'Неизвестная форма или ориентация',cost:0};
  const check=this.checkBuild(cells,material);if(!check.ok)return check;
  this.resources[material]-=cells.length;
  for(const c of cells)this.blocks.set(key(c.x,c.y,c.z),{material,shape,dir,hp:maxHP(material)});
  this.processed.add(id);this.changed('build');return check;
 }
 static line(a:Cell,b:Cell):Cell[]{
  if(![a.x,a.y,a.z,b.x,b.y,b.z].every(Number.isInteger))return [];
  const deltas=[b.x-a.x,b.y-a.y,b.z-a.z],axes=deltas.filter(d=>d!==0).length;
  if(axes>1)return [];
  const length=Math.max(...deltas.map(Math.abs))+1;if(length>24)return [];
  return Array.from({length},(_,i)=>({x:a.x+Math.sign(deltas[0])*i,y:a.y+Math.sign(deltas[1])*i,z:a.z+Math.sign(deltas[2])*i}));
 }
 placeLine(id:string,a:Cell,b:Cell,m:Material,shape:Shape='full',dir:Orientation=0){return this.build(id,World.line(a,b),m,shape,dir);}
 private collapse(){const supported=this.anchored(new Set(this.blocks.keys()));let removed=0;
  for(const k of this.blocks.keys())if(!supported.has(k)){this.blocks.delete(k);removed++;}return removed;
 }
 remove(id:string,c:Cell){if(this.processed.has(id)||!inBounds(c))return false;
  const k=key(c.x,c.y,c.z),b=this.blocks.get(k);if(!b)return false;
  this.blocks.delete(k);this.resources[b.material]+=.5;this.collapse();this.processed.add(id);this.changed('remove');return true;
 }
 repair(id:string,c:Cell,strength=30){if(this.processed.has(id)||!inBounds(c))return false;
  const b=this.get(c.x,c.y,c.z);if(!b||b.hp>=maxHP(b.material)||this.resources[b.material]<1)return false;
  this.resources[b.material]--;b.hp=Math.min(maxHP(b.material),b.hp+Math.max(1,Math.min(100,strength)));this.processed.add(id);this.changed('repair');return true;
 }
 damage(c:Cell,amount:number){if(!inBounds(c)||!Number.isFinite(amount)||amount<=0)return false;
  const k=key(c.x,c.y,c.z),b=this.blocks.get(k);if(!b)return false;
  b.hp-=amount;if(b.hp<=0){this.blocks.delete(k);this.collapse();}this.changed('damage');return true;
 }
 /** Ground-only AI intentionally treats every cell shape as a ground obstruction. */
 groundObstructions(x:number,z:number):Cell[]{const a:Cell[]=[];for(const y of [0,1])if(this.get(x,y,z))a.push({x,y,z});return a;}
 serialize(){return JSON.stringify({schema:3,resources:this.resources,blocks:[...this.blocks]});}
 restore(json:string){
  const raw=JSON.parse(json) as {schema:number;resources:Record<string,unknown>;blocks:unknown};
  if(![1,2,3].includes(raw.schema)||!Array.isArray(raw.blocks)||raw.blocks.length>30000)throw Error('Invalid save schema');
  const res=raw.resources;
  if(!res||!['stone','wood'].every(m=>typeof res[m]==='number'&&Number.isFinite(res[m])&&(res[m] as number)>=0))throw Error('Invalid resources');
  const fresh=new Map<string,Block>();
  for(const pair of raw.blocks){
   if(!Array.isArray(pair)||pair.length!==2||typeof pair[0]!=='string')throw Error('Invalid block entry');
   const coords=pair[0].split(',');if(coords.length!==(raw.schema===1?2:3)||coords.some((n:string)=>!/^[-]?\d+$/.test(n)))throw Error('Invalid coordinates');
   const nums=coords.map(Number),c:Cell=raw.schema===1?{x:nums[0],y:0,z:nums[1]}:{x:nums[0],y:nums[1],z:nums[2]};
   const b=pair[1] as Partial<Block>;
   if(!inBounds(c)||!b||b.material!=='stone'&&b.material!=='wood'||typeof b.hp!=='number'||!Number.isFinite(b.hp)||b.hp<=0||b.hp>maxHP(b.material))throw Error('Invalid block');
   const shape=raw.schema===1?'full':b.shape;if(!isShape(shape)||(raw.schema===2&&!['full','slab'].includes(shape)))throw Error('Invalid shape');
   const dir=raw.schema===3?b.dir:0;if(!isOrientation(dir))throw Error('Invalid orientation');
   const k=key(c.x,c.y,c.z);if(fresh.has(k))throw Error('Duplicate cell');fresh.set(k,{material:b.material,shape,dir,hp:b.hp});
  }
  // Validation completed before any state is modified.
  this.blocks.clear();for(const [k,v] of fresh)this.blocks.set(k,v);
  this.resources={stone:res.stone as number,wood:res.wood as number};this.processed.clear();this.collapse();this.changed('load');
 }
}
