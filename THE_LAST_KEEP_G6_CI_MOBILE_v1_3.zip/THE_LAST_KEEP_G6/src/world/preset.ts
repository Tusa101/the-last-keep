import {World,type Shape,type Orientation} from './model.ts';

export function seedCastle(world:World){
 const stone=(x:number,y:number,z:number,shape:Shape='full',dir:Orientation=0)=>world.seed({x,y,z},'stone',shape,dir);
 const wood=(x:number,y:number,z:number,shape:Shape='full',dir:Orientation=0)=>world.seed({x,y,z},'wood',shape,dir);
 // West-facing medieval curtain wall, intact side walls, two weathered towers, gate gap.
 for(let z=-8;z<=8;z++){
  if(Math.abs(z)>1){for(const y of [0,1])stone(-10,y,z);if(z%2===0)stone(-10,2,z,'slab');}
  for(const y of [0,1])stone(12,y,z);
 }
 for(let x=-9;x<=11;x++)for(const z of [-8,8]){
  stone(x,0,z);if(x%5!==0)stone(x,1,z);
 }
 for(const z0 of [-8,8])for(let y=0;y<5;y++)for(const dx of [0,1])for(const dz of [0,1]){
  if(y===4&&dx===1&&dz===1)continue;
  stone(-10+dx,y,z0+dz);
 }
 // Distinct medieval defense silhouettes: crenels and an elevated firing aperture.
 for(const z of [-6,-4,4,6])stone(-10,2,z,'battlement');
 stone(-9,3,-7,'arrowSlit',0);stone(-9,3,8,'arrowSlit',0);
 // Ruined internal parapet; the breach is traversable and can be restored.
 for(let z=-3;z<=3;z++){
  if(z!==0){stone(-1,0,z);if(z%2===0)stone(-1,1,z);}
 }
 for(let x=1;x<5;x++)wood(x,0,5,'slab');
 // Visible elevated ledge connected to the front wall.
 stone(-10,2,-5);for(let x=-9;x<=-7;x++)stone(x,2,-5,'slab');
 // Pre-built playable staircase in the courtyard, rising to a watch gallery.
 // This is a genuine collider-driven test fixture, not a decorative mesh.
 for(let x=-6;x<=-4;x++){const y=x+6;for(let foot=0;foot<y;foot++)stone(x,foot,-4);stone(x,y,-4,'stair',0);}
 for(let y=0;y<3;y++)wood(-3,y,-4);
 for(let x=-3;x<=-1;x++)wood(x,3,-4,'slab');
}

