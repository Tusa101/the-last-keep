import {World,maxHP,type Cell} from '../world/model.ts';
import {shapeBoxes,type Box} from '../world/shapes.ts';
export type Instance={cell:Cell;box:Box};
export type BatchKey='stone'|'wood'|'stoneDamaged'|'woodDamaged';
/** Renderer-agnostic instancing plan: one draw group per material/damage variant,
 * independent of total block count and geometry type. */
export function collectBatches(world:World){
 const groups=new Map<BatchKey,Instance[]>();
 for(const [key,b] of world.blocks){
  const [x,y,z]=key.split(',').map(Number),cell={x,y,z};
  const matKey=(b.hp<maxHP(b.material)*.45?`${b.material}Damaged`:b.material) as BatchKey;
  const group=groups.get(matKey)??[];
  for(const box of shapeBoxes(b.shape,b.dir))group.push({cell,box});
  groups.set(matKey,group);
 }
 return groups;
}
