import * as THREE from 'three';
/** Small generated textures, not external images. One masonry / wood tile shared by every buildable block. */
export function makeSurfaceTexture(material:'stone'|'wood'){
 const canvas=document.createElement('canvas');canvas.width=128;canvas.height=128;
 const c=canvas.getContext('2d');if(!c)throw Error('2D canvas unavailable');
 let state=material==='stone'?4523:2113;const rand=()=>{state=(1664525*state+1013904223)>>>0;return state/4294967296;};
 if(material==='stone'){
  c.fillStyle='#776c60';c.fillRect(0,0,128,128);
  const rows=4,hh=128/rows;
  for(let row=0;row<rows;row++){
   const offset=(row%2)*22;
   for(let col=-1;col<4;col++){
    const x=col*45+offset,y=row*hh;
    const shade=147+Math.floor(rand()*31),r=shade+6,g=shade,b=shade-12;
    c.fillStyle=`rgb(${r},${g},${b})`;c.fillRect(x+1,y+1,43,hh-2);
    c.fillStyle='rgba(255,241,215,.18)';c.fillRect(x+3,y+3,40,2);
    c.fillStyle='rgba(45,42,38,.16)';c.fillRect(x+2,y+hh-5,40,2);
    for(let i=0;i<9;i++){
     c.fillStyle=rand()>.50?'rgba(65,65,62,.08)':'rgba(252,244,217,.06)';
     c.fillRect(x+4+rand()*36,y+4+rand()*(hh-8),2+rand()*8,1+rand()*3);
    }
   }
  }
 }else{
  c.fillStyle='#60462c';c.fillRect(0,0,128,128);
  for(let i=0;i<5;i++){
   const x=i*26-2,shade=105+Math.floor(rand()*25);
   c.fillStyle=`rgb(${shade+19},${shade-15},${shade-39})`;c.fillRect(x+1,0,24,128);
   c.fillStyle='rgba(255,214,147,.20)';c.fillRect(x+3,0,2,128);
   c.fillStyle='rgba(20,16,12,.25)';c.fillRect(x+23,0,2,128);
   for(let j=0;j<11;j++){
    c.fillStyle=rand()>.5?'rgba(36,20,12,.13)':'rgba(246,192,125,.11)';
    c.fillRect(x+3+rand()*18,rand()*128,1,4+rand()*24);
   }
   for(const y of [9,114]){
    c.fillStyle='#4b4132';c.fillRect(x+11,y,3,3);
    c.fillStyle='#d0b078';c.fillRect(x+11,y,1,1);
   }
  }
 }
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
 texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;
 texture.anisotropy=4;return texture;
}
