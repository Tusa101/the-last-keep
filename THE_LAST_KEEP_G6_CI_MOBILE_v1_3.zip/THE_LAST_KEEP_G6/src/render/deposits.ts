import * as THREE from 'three';
import type {Deposit} from '../game/gathering.ts';
export function makeDepositVisuals(scene:THREE.Scene,deposits:readonly Deposit[]){
 const stone=new THREE.MeshLambertMaterial({color:'#9b9a91',flatShading:true});
 const rawStone=new THREE.MeshLambertMaterial({color:'#777a70',flatShading:true});
 const timber=new THREE.MeshLambertMaterial({color:'#987044',flatShading:true});
 const rings=new THREE.MeshLambertMaterial({color:'#ccad74',flatShading:true});
 const iron=new THREE.MeshLambertMaterial({color:'#464b42',flatShading:true});
 const markerStone=new THREE.MeshBasicMaterial({color:'#e8d298'});
 const markerWood=new THREE.MeshBasicMaterial({color:'#96e2aa'});
 const instances=new Map<string,{root:THREE.Group;marker:THREE.Mesh}>();
 for(const d of deposits){
  const root=new THREE.Group();root.position.set(d.x,0,d.z);
  for(let i=0;i<5;i++){
   if(d.material==='stone'){
    const chunk=new THREE.Mesh(new THREE.DodecahedronGeometry(.42+i*.032,0),i%2?stone:rawStone);
    chunk.position.set(Math.cos(i*2.45)*.56,.28+i*.06,Math.sin(i*2.45)*.42);chunk.rotation.set(i*.18,i*.7,i*.25);root.add(chunk);
   }else{
    const log=new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,1.6+i*.03,8),timber);
    log.rotation.z=Math.PI/2;log.position.set(0,.26+(i%3)*.39,(i-2)*.33);root.add(log);
    for(const x of [-.82,.82]){
     const end=new THREE.Mesh(new THREE.CircleGeometry(.19,8),rings);end.rotation.y=x>0?Math.PI/2:-Math.PI/2;
     end.position.set(x,.26+(i%3)*.39,(i-2)*.33);root.add(end);
    }
   }
  }
  // Simple hovering jewel tells the player this pile is gatherable, not decorative.
  const marker=new THREE.Mesh(new THREE.OctahedronGeometry(.20),d.material==='stone'?markerStone:markerWood);
  marker.position.y=2.25;root.add(marker);
  const stand=new THREE.Mesh(new THREE.CylinderGeometry(.04,.05,1.08,6),iron);stand.position.set(.8,.54,.8);root.add(stand);
  root.userData.remaining=d.remaining;
  scene.add(root);instances.set(d.id,{root,marker});
 }
 return {
  sync:(deposits:readonly Deposit[],now:number)=>{for(const d of deposits){const item=instances.get(d.id);if(!item)continue;
   const ratio=d.remaining/d.capacity;item.root.scale.setScalar(d.remaining>0?.45+.55*Math.sqrt(ratio):.20);
   item.root.visible=d.remaining>0;
   item.marker.position.y=2.25+.13*Math.sin(now*.003+d.x);item.marker.rotation.y=now*.001;
  }}
 };
}
