import * as THREE from 'three';
import {World,type Cell,type Shape,type Orientation} from '../world/model.ts';
import {shapeBoxes} from '../world/shapes.ts';
import {collectBatches} from './batches.ts';
import type {Raider,Weapon,BattleEvent} from '../game/siege.ts';
import type {Vec3} from '../game/combat.ts';
import {makeSurfaceTexture} from './textures.ts';
import {makeScenery} from './scenery.ts';
import {makeDepositVisuals} from './deposits.ts';
import type {Deposit} from '../game/gathering.ts';
import {STOCKPILE,type Worker,type Order} from '../game/workers.ts';
import {workerRenderer} from './workers.ts';
import {makeRaiderVisual,animateRaiderVisual,removeRaiderVisual,type RaiderVisual} from './characters.ts';
export type Aim={hit:Cell|null;place:Cell|null};
export function makeScene(world:World){
 const scene=new THREE.Scene();scene.background=new THREE.Color('#bdc6b1');scene.fog=new THREE.Fog('#bdc6b1',34,94);
 const camera=new THREE.PerspectiveCamera(76,innerWidth/innerHeight,.06,140);
 const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);
 renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;
 document.body.appendChild(renderer.domElement);
 const hemisphere=new THREE.HemisphereLight('#f9e7c6','#5b6252',2.15);scene.add(hemisphere);
 const sun=new THREE.DirectionalLight('#fff0c9',2.15);sun.position.set(-14,27,21);scene.add(sun);
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(47,47),new THREE.MeshLambertMaterial({color:'#80916f'}));
 ground.rotation.x=-Math.PI/2;ground.userData.ground=true;scene.add(ground);
 const stoneMap=makeSurfaceTexture('stone'),woodMap=makeSurfaceTexture('wood');
 const materials={
  stone:new THREE.MeshLambertMaterial({map:stoneMap,color:'#ddd7c8'}),wood:new THREE.MeshLambertMaterial({map:woodMap,color:'#e5d6b9'}),
  stoneDamaged:new THREE.MeshLambertMaterial({map:stoneMap,color:'#8a7771'}),woodDamaged:new THREE.MeshLambertMaterial({map:woodMap,color:'#986c65'})
 };
 const cube=new THREE.BoxGeometry(1,1,1),batchMeshes:THREE.InstancedMesh[]=[];
 const dummy=new THREE.Object3D();const tint=new THREE.Color();
 const seed=(x:number,y:number,z:number,part:number)=>{
  const hash=Math.sin(x*31.17+y*39.67+z*13.19+part*92.3)*43758.5453;
  return .88+((hash-Math.floor(hash))*.19);
 };
 /** Instancing groups identical material and damage state into a handful of draw calls.
  * For now edits still rebuild all instance buffers; chunk-dirty updates come later. */
 function rebuild(){
  for(const mesh of batchMeshes){scene.remove(mesh);mesh.dispose();}batchMeshes.length=0;
  const groups=collectBatches(world);
  for(const [kind,items] of groups){
   const mesh=new THREE.InstancedMesh(cube,materials[kind as keyof typeof materials],items.length);
   const lookup:Cell[]=[];
   items.forEach(({cell,box},i)=>{
    dummy.position.set(cell.x+(box.x0+box.x1)/2,cell.y+(box.y0+box.y1)/2,cell.z+(box.z0+box.z1)/2);
    dummy.scale.set(box.x1-box.x0,box.y1-box.y0,box.z1-box.z0);dummy.rotation.set(0,0,0);dummy.updateMatrix();
    mesh.setMatrixAt(i,dummy.matrix);tint.setScalar(seed(cell.x,cell.y,cell.z,i));mesh.setColorAt(i,tint);
    lookup.push(cell);
   });
   mesh.instanceMatrix.needsUpdate=true;
   if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
   mesh.userData.cells=lookup;mesh.computeBoundingSphere();scene.add(mesh);batchMeshes.push(mesh);
  }
 }
 world.onChange(rebuild);rebuild();
 const preview=new THREE.Group();scene.add(preview);
 const green=new THREE.MeshBasicMaterial({color:'#70edb3',transparent:true,opacity:.40,depthWrite:false,side:THREE.DoubleSide});
 const red=new THREE.MeshBasicMaterial({color:'#ff7770',transparent:true,opacity:.44,depthWrite:false,side:THREE.DoubleSide});
 let previewSignature='';
 function showPreview(cells:Cell[],valid:boolean,shape:Shape,dir:Orientation=0){
  const signature=`${valid}/${shape}/${dir}/${cells.map(c=>`${c.x},${c.y},${c.z}`).join(';')}`;
  if(signature===previewSignature)return;previewSignature=signature;
  preview.clear();
  const boxes=shapeBoxes(shape,dir);
  for(const c of cells)for(const box of boxes){
   const mesh=new THREE.Mesh(cube,valid?green:red);
   mesh.position.set(c.x+(box.x0+box.x1)/2,c.y+(box.y0+box.y1)/2,c.z+(box.z0+box.z1)/2);
   mesh.scale.set(box.x1-box.x0,box.y1-box.y0,box.z1-box.z0);preview.add(mesh);
  }
 }
 // Worker construction orders appear as transparent blue plans, not built masonry.
 // These projections never alter collisions, resources or the authoritative world.
 const ordersVisual=new THREE.Group();scene.add(ordersVisual);
 const orderMaterial=new THREE.MeshBasicMaterial({color:'#80c9bd',transparent:true,opacity:.24,depthWrite:false,side:THREE.DoubleSide});
 let orderSignature='';
 function syncOrders(orders:readonly Order[]){
  const signature=orders.map(o=>`${o.id}@${o.cell.x},${o.cell.y},${o.cell.z}/${o.shape}/${o.dir}`).join('|');
  if(signature===orderSignature)return;orderSignature=signature;ordersVisual.clear();
  for(const o of orders){
   for(const part of shapeBoxes(o.shape,o.dir)){
    const mesh=new THREE.Mesh(cube,orderMaterial);
    mesh.position.set(o.cell.x+(part.x0+part.x1)/2,o.cell.y+(part.y0+part.y1)/2,o.cell.z+(part.z0+part.z1)/2);
    mesh.scale.set(part.x1-part.x0,part.y1-part.y0,part.z1-part.z0);
    ordersVisual.add(mesh);
   }
  }
 }
 const ray=new THREE.Raycaster();ray.far=8;const direction=new THREE.Vector3();
 function aim():Aim{
  camera.getWorldDirection(direction);ray.set(camera.position,direction);
  const hits=ray.intersectObjects([...batchMeshes,ground]);if(!hits.length)return {hit:null,place:null};
  const h=hits[0];if(h.object.userData.ground)return {hit:null,place:{x:Math.round(h.point.x),y:0,z:Math.round(h.point.z)}};
  const cell=(h.object.userData.cells as Cell[])[h.instanceId??-1];
  if(!cell||!h.face)return {hit:null,place:null};
  const n=h.face.normal;
  return {hit:cell,place:{x:cell.x+Math.round(n.x),y:cell.y+Math.round(n.y),z:cell.z+Math.round(n.z)}};
 }
 // Environmental meshes are visual props, never blockers or resource deposits.
 const scenery=makeScenery(scene);
 let depositVisuals:ReturnType<typeof makeDepositVisuals>|null=null;
 function setDeposits(deposits:readonly Deposit[]){if(!depositVisuals)depositVisuals=makeDepositVisuals(scene,deposits);}
 const nexus=new THREE.Mesh(new THREE.OctahedronGeometry(1.15),new THREE.MeshLambertMaterial({color:'#70d9c5',emissive:'#14675c',emissiveIntensity:.5}));nexus.position.set(9,1.65,0);scene.add(nexus);
 const pedestal=new THREE.Mesh(new THREE.CylinderGeometry(1.2,1.5,.6,8),new THREE.MeshLambertMaterial({color:'#67675c'}));pedestal.position.set(9,.3,0);scene.add(pedestal);
 // A simple visible spring trap near the Nexus; its charges are simulated by Siege.
 const trap=new THREE.Group();trap.position.set(7,0,0);scene.add(trap);
 // The common stockpile is intentionally readable from a distance. Supplies
 // enter the shared resource economy ONLY when a porter returns here.
 const stock=new THREE.Group();stock.position.set(STOCKPILE.x,0,STOCKPILE.z);scene.add(stock);
 const stockWood=new THREE.MeshLambertMaterial({color:'#7c543a'});
 const stockIron=new THREE.MeshLambertMaterial({color:'#3d4d49'});
 const stockCloth=new THREE.MeshLambertMaterial({color:'#d5bd8a'});
 const platform=new THREE.Mesh(new THREE.BoxGeometry(2.5,.16,2.5),stockWood);
 platform.position.y=.08;stock.add(platform);
 for(const [x,z] of [[-.85,-.85],[.85,-.85],[-.85,.85],[.85,.85]]){
  const post=new THREE.Mesh(new THREE.BoxGeometry(.13,1.65,.13),stockWood);
  post.position.set(x,.9,z);stock.add(post);
 }
 const canopy=new THREE.Mesh(new THREE.ConeGeometry(1.83,.95,4),stockCloth);
 canopy.rotation.y=Math.PI/4;canopy.position.set(0,2.1,0);stock.add(canopy);
 for(const x of [-.45,.40]){
  const crate=new THREE.Mesh(new THREE.BoxGeometry(.65,.52,.60),stockWood);
  crate.position.set(x,.40,.60);stock.add(crate);
  const band=new THREE.Mesh(new THREE.BoxGeometry(.71,.10,.65),stockIron);
  band.position.set(x,.42,.60);stock.add(band);
 }
 const stockFlag=new THREE.Mesh(new THREE.PlaneGeometry(.64,.42),new THREE.MeshLambertMaterial({color:'#658f7e',side:THREE.DoubleSide}));
 stockFlag.position.set(0,1.24,-.94);stock.add(stockFlag);
 const springMetal=new THREE.MeshStandardMaterial({color:'#bf8d48',metalness:.5,roughness:.4});
 const trapBase=new THREE.Mesh(new THREE.CylinderGeometry(.67,.76,.25,10),springMetal);trapBase.position.y=.15;trap.add(trapBase);
 for(let i=0;i<5;i++){const coil=new THREE.Mesh(new THREE.TorusGeometry(.3,.036,6,14),springMetal);coil.rotation.x=Math.PI/2;coil.position.y=.38+i*.12;trap.add(coil);}
 const springHead=new THREE.Mesh(new THREE.IcosahedronGeometry(.32,0),new THREE.MeshLambertMaterial({color:'#e9a638'}));springHead.position.y=1.06;trap.add(springHead);
 // Short-lived local VFX; drawn separately from the authoritative combat simulation.
 const effects:{object:THREE.Object3D;ttl:number;duration:number;type:'shot'|'burst'}[]=[];
 const beamGeo=new THREE.CylinderGeometry(.025,.025,1,6);
 function playShot(from:Vec3,to:Vec3,weapon:Weapon){
  const a=new THREE.Vector3(from.x,from.y,from.z),b=new THREE.Vector3(to.x,to.y,to.z),delta=b.clone().sub(a);
  if(delta.lengthSq()<.001)return;
  const beam=new THREE.Mesh(beamGeo,new THREE.MeshBasicMaterial({color:weapon==='carrot'?'#f98a24':'#e9d8a0',transparent:true,opacity:.9,depthWrite:false}));
  beam.position.copy(a).add(b).multiplyScalar(.5);beam.scale.y=delta.length();beam.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());
  scene.add(beam);effects.push({object:beam,ttl:.12,duration:.12,type:'shot'});
 }
 function playImpact(point:Vec3,type:BattleEvent['kind']){
  const geometry=new THREE.IcosahedronGeometry(type==='kill'?.32:.16,0);
  const tint=type==='trap'?'#ffb33a':type==='breach'?'#dad3b4':type==='kill'?'#ffa4cd':type==='nexus'?'#45ecdf':'#ffe6aa';
  const mesh=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:tint,transparent:true,opacity:.95,depthWrite:false}));
  mesh.position.set(point.x,point.y,point.z);scene.add(mesh);
  effects.push({object:mesh,ttl:type==='kill'?.48:.25,duration:type==='kill'?.48:.25,type:'burst'});
 }
 function tickEffects(dt:number){for(let i=effects.length-1;i>=0;i--){const effect=effects[i];effect.ttl-=dt;
  if(effect.type==='burst')effect.object.scale.setScalar(1+(1-effect.ttl/effect.duration)*1.8);
  const mesh=effect.object as THREE.Mesh;const mat=mesh.material as THREE.MeshBasicMaterial;mat.opacity=Math.max(0,effect.ttl/effect.duration);
  if(effect.ttl<=0){scene.remove(effect.object);if(effect.type==='burst')mesh.geometry.dispose();mat.dispose();effects.splice(i,1);}
 }}
 // Two lightweight first-person props make the weapon identity readable without external assets.
 scene.add(camera);
 const weaponMount=new THREE.Group();weaponMount.position.set(.46,-.40,-.77);camera.add(weaponMount);
 const boltModel=new THREE.Group(),carrotModel=new THREE.Group();weaponMount.add(boltModel,carrotModel);
 const oak=new THREE.MeshLambertMaterial({color:'#805236'}),metal=new THREE.MeshLambertMaterial({color:'#4e5456'});
 const carrotOrange=new THREE.MeshLambertMaterial({color:'#ee8233'}),greens=new THREE.MeshLambertMaterial({color:'#5aa76a'});
 function cylinder(parent:THREE.Group,from:THREE.Vector3,to:THREE.Vector3,r:number,mat:THREE.Material){
  const diff=to.clone().sub(from);const beam=new THREE.Mesh(new THREE.CylinderGeometry(r,r,diff.length(),7),mat);
  beam.position.copy(from).add(to).multiplyScalar(.5);beam.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),diff.normalize());parent.add(beam);
 }
 // Conventional small medieval crossbow: stock, arms and visible steel bowstring.
 cylinder(boltModel,new THREE.Vector3(0,-.15,.22),new THREE.Vector3(0,0,-.60),.08,oak);
 cylinder(boltModel,new THREE.Vector3(-.28,0,-.48),new THREE.Vector3(.28,0,-.48),.075,oak);
 cylinder(boltModel,new THREE.Vector3(-.28,0,-.48),new THREE.Vector3(0,-.025,-.15),.009,metal);
 cylinder(boltModel,new THREE.Vector3(.28,0,-.48),new THREE.Vector3(0,-.025,-.15),.009,metal);
 cylinder(boltModel,new THREE.Vector3(0,.03,.05),new THREE.Vector3(0,.04,-.60),.022,metal);
 // Absurd equipment keeps a medieval stock and brass fittings, not sci-fi styling.
 cylinder(carrotModel,new THREE.Vector3(0,-.15,.22),new THREE.Vector3(0,-.03,-.30),.10,oak);
 const fat=new THREE.Mesh(new THREE.ConeGeometry(.135,.54,8),carrotOrange);fat.rotation.x=Math.PI/2;fat.position.set(0,.03,-.42);carrotModel.add(fat);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(.14,.025,8,16),metal);ring.position.set(0,.03,-.17);carrotModel.add(ring);
 for(const angle of [-.45,0,.45]){const leaf=new THREE.Mesh(new THREE.ConeGeometry(.04,.23,5),greens);leaf.rotation.x=1.25;leaf.rotation.z=angle;leaf.position.set(angle*.18,.13,-.24);carrotModel.add(leaf);}
 let currentWeapon:Weapon='bolt',recoil=0;
 function setWeapon(type:Weapon){currentWeapon=type;boltModel.visible=type==='bolt';carrotModel.visible=type==='carrot';}
 function fireWeapon(){recoil=.19;}
 setWeapon('bolt');
 function animateWeapon(dt:number,now:number){recoil=Math.max(0,recoil-dt*.8);weaponMount.position.z=-.77+recoil;
  weaponMount.rotation.x=-recoil*.7+Math.sin(now*.0019)*.008;}
 const workerViews=workerRenderer(scene);
 const raiderMeshes=new Map<number,RaiderVisual>();
 function syncRaiders(raiders:Raider[],now:number){
  const active=new Set<number>();
  for(const r of raiders){if(!r.alive||r.spawnIn>0)continue;active.add(r.id);
   let visual=raiderMeshes.get(r.id);
   if(!visual){visual=makeRaiderVisual(r);scene.add(visual.root);raiderMeshes.set(r.id,visual);}
   animateRaiderVisual(visual,r,now,camera);
  }
  for(const [id,visual] of raiderMeshes)if(!active.has(id)){
   removeRaiderVisual(scene,visual);raiderMeshes.delete(id);
  }
 }
 let currentPhase='PREP';
 const colors:Record<string,{sky:string;sun:string;strength:number;hemi:number;fog:number}>={
  PREP:{sky:'#bdc6b1',sun:'#fff0c9',strength:2.15,hemi:2.15,fog:94},
  WARNING:{sky:'#b49b8b',sun:'#ffd4a1',strength:2.2,hemi:1.95,fog:84},
  SIEGE:{sky:'#819fa5',sun:'#d5dfe4',strength:1.66,hemi:1.72,fog:77},
  RESULT:{sky:'#b9c5ae',sun:'#fff0c9',strength:2.15,hemi:2.15,fog:94},
  VICTORY:{sky:'#e2cba7',sun:'#fff2be',strength:2.45,hemi:2.3,fog:100},
  DEFEAT:{sky:'#8b7a79',sun:'#c9b5aa',strength:1.36,hemi:1.50,fog:68}
 };
 function setPhase(phase:string){currentPhase=phase;}
 const sky=new THREE.Color(),sunColor=new THREE.Color();
 const updateAtmosphere=()=>{
  const settings=colors[currentPhase]??colors.PREP;
  sky.set(settings.sky);sunColor.set(settings.sun);
  (scene.background as THREE.Color).lerp(sky,.045);
  (scene.fog as THREE.Fog).color.copy(scene.background as THREE.Color);
  sun.color.lerp(sunColor,.045);sun.intensity+=(settings.strength-sun.intensity)*.04;
  hemisphere.intensity+=(settings.hemi-hemisphere.intensity)*.04;
  (scene.fog as THREE.Fog).far+=(settings.fog-(scene.fog as THREE.Fog).far)*.04;
 };
 let resolutionScale=1;
 const updateResolution=()=>{renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)*resolutionScale);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);};
 addEventListener('resize',updateResolution);
 return {camera,renderer,syncOrders,syncRaiders,syncWorkers:(people:readonly Worker[],now:number)=>workerViews.sync(people,now),setPhase,setDeposits,syncDeposits:(deposits:readonly Deposit[],now:number)=>depositVisuals?.sync(deposits,now),aim,showPreview,playShot,playImpact,tickEffects,setWeapon,fireWeapon,animateWeapon,stats:()=>({drawCalls:renderer.info.render.calls,batches:batchMeshes.length}),
  setResolutionScale:(scale:number)=>{resolutionScale=Math.max(.5,Math.min(1.4,scale));updateResolution();},
  render:(now:number)=>{updateAtmosphere();scenery.animate(now,currentPhase);nexus.rotation.y+=.008;nexus.position.y=1.65+.12*Math.sin(now*.002);springHead.position.y=1.06+.055*Math.sin(now*.008);renderer.render(scene,camera);}};
}
