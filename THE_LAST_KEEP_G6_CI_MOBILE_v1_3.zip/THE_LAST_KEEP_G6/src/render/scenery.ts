import * as THREE from 'three';

/** Decorative medieval world. All objects here are deliberately NON-COLLIDING:
 * gameplay walls/loot must only be placed through the authoritative World model. */
export function makeScenery(scene:THREE.Scene){
 const rock=new THREE.MeshLambertMaterial({color:'#a49b84',flatShading:true});
 const darkRock=new THREE.MeshLambertMaterial({color:'#777667',flatShading:true});
 const soil=new THREE.MeshLambertMaterial({color:'#b29d7a',flatShading:true});
 const grass=new THREE.MeshLambertMaterial({color:'#6e8962',flatShading:true});
 const grass2=new THREE.MeshLambertMaterial({color:'#8a9a70',flatShading:true});
 const bark=new THREE.MeshLambertMaterial({color:'#66503c',flatShading:true});
 const needles=new THREE.MeshLambertMaterial({color:'#466853',flatShading:true});
 const deepNeedles=new THREE.MeshLambertMaterial({color:'#365947',flatShading:true});
 const crimson=new THREE.MeshLambertMaterial({color:'#9f4843',side:THREE.DoubleSide});
 const gold=new THREE.MeshLambertMaterial({color:'#dab36b',side:THREE.DoubleSide});
 const iron=new THREE.MeshStandardMaterial({color:'#5b5b52',metalness:.38,roughness:.7});
 // Subtle irregular flagstone approach and central courtyard.
 const walkway=new THREE.Mesh(new THREE.PlaneGeometry(45,4.5),soil);walkway.rotation.x=-Math.PI/2;walkway.position.set(0,.011,0);scene.add(walkway);
 const yard=new THREE.Mesh(new THREE.PlaneGeometry(15.4,12.8),new THREE.MeshLambertMaterial({color:'#a1a086'}));
 yard.rotation.x=-Math.PI/2;yard.position.set(2,.008,0);scene.add(yard);
 // Two-tone walk stones are single instanced batches.
 const slabGeometry=new THREE.BoxGeometry(1,.045,.75),slabs=new THREE.InstancedMesh(slabGeometry,rock,90);
 const marker=new THREE.Object3D();let si=0;
 for(let x=-20;x<=20;x+=1.45)for(let z of [-1.22,1.22]){
  marker.position.set(x+(si%3)*.11,.017,z);marker.scale.set(.85+si%4*.05,1,.70);marker.rotation.y=(si%3-1)*.10;marker.updateMatrix();slabs.setMatrixAt(si++,marker.matrix);
 }slabs.count=si;slabs.instanceMatrix.needsUpdate=true;scene.add(slabs);
 // Stones and tufts placed out of the castle footprint.
 let seed=73451;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const boulder=new THREE.IcosahedronGeometry(.5,0),boulders=new THREE.InstancedMesh(boulder,darkRock,70);
 const tuft=new THREE.ConeGeometry(.16,.46,4),tufts=new THREE.InstancedMesh(tuft,grass2,145);
 for(let i=0;i<70;i++){
  let x=rnd()*43-21.5,z=rnd()*43-21.5;if(Math.abs(x)<13&&Math.abs(z)<11){x+=(x>0?8:-8);}
  marker.position.set(Math.max(-22,Math.min(22,x)),.14,Math.max(-22,Math.min(22,z)));
  marker.scale.set(.28+rnd()*.55,.27+rnd()*.32,.29+rnd()*.46);marker.rotation.set(rnd()*.2,rnd()*3,.0);marker.updateMatrix();boulders.setMatrixAt(i,marker.matrix);
 }
 for(let i=0;i<145;i++){
  let x=rnd()*44-22,z=rnd()*44-22;if(Math.abs(x)<13&&Math.abs(z)<10)x+=x>0?10:-10;
  marker.position.set(Math.max(-22,Math.min(22,x)),.11,Math.max(-22,Math.min(22,z)));
  marker.scale.set(.8+rnd()*.65,.4+rnd()*.55,.7+rnd()*.65);marker.rotation.set(0,rnd()*6.28,0);marker.updateMatrix();tufts.setMatrixAt(i,marker.matrix);
 }
 boulders.instanceMatrix.needsUpdate=true;tufts.instanceMatrix.needsUpdate=true;scene.add(boulders,tufts);
 // Sparse stylised pine silhouettes frame the playable stage without obstructing gameplay.
 for(const [x,z,s] of [[-20,-18,1.2],[-18,18,1.15],[18,-17,1.35],[19,16,1],[3,-20,.93],[-12,19,.8],[13,19,1.1]] as [number,number,number][]){
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.13*s,.27*s,2.5*s,6),bark);trunk.position.set(x,1.25*s,z);scene.add(trunk);
  for(let level=0;level<3;level++){
   const crown=new THREE.Mesh(new THREE.ConeGeometry((1.65-level*.25)*s,2.15*s,7),level===1?needles:deepNeedles);
   crown.position.set(x,(2.25+level*.89)*s,z);crown.rotation.y=(level%2)*.3;scene.add(crown);
  }
 }
 // Non-interactive heraldic standards, grounded OUTSIDE the stone walls.
 const flagGroups:THREE.Group[]=[];
 for(const [x,z] of [[-11,-11],[-11,11],[13,-11],[13,11]] as [number,number][]){
  const banner=new THREE.Group();banner.position.set(x,0,z);
  const mast=new THREE.Mesh(new THREE.CylinderGeometry(.06,.08,5,7),bark);mast.position.y=2.5;banner.add(mast);
  const finial=new THREE.Mesh(new THREE.OctahedronGeometry(.17),gold);finial.position.y=5.03;banner.add(finial);
  const cloth=new THREE.Mesh(new THREE.PlaneGeometry(.95,1.42),crimson);
  cloth.position.set(.47,4.15,.05);cloth.name='cloth';banner.add(cloth);
  // Heraldic diamond, not text: compatible with the quiet medieval art rule.
  const badge=new THREE.Mesh(new THREE.PlaneGeometry(.27,.27),gold);badge.rotation.z=Math.PI/4;badge.position.set(.47,4.16,.061);banner.add(badge);
  flagGroups.push(banner);scene.add(banner);
 }
 // Iron fire baskets and a gold-framed, worn castle notice board.
 const flames:THREE.Group[]=[];
 for(const [x,z] of [[-8,-7],[-8,7],[10,-7],[10,7]] as [number,number][]){
  const torch=new THREE.Group();torch.position.set(x,0,z);
  const stand=new THREE.Mesh(new THREE.CylinderGeometry(.065,.10,1.2,7),iron);stand.position.y=.63;torch.add(stand);
  const bowl=new THREE.Mesh(new THREE.CylinderGeometry(.32,.23,.17,9),iron);bowl.position.y=1.24;torch.add(bowl);
  const flame=new THREE.Mesh(new THREE.ConeGeometry(.18,.48,7),new THREE.MeshBasicMaterial({color:'#ffb75e'}));flame.position.y=1.53;torch.add(flame);
  flame.name='flame';flames.push(torch);scene.add(torch);
 }
 const board=new THREE.Group();board.position.set(-5,0,7.5);
 const plank=new THREE.Mesh(new THREE.BoxGeometry(2.0,1.05,.13),bark);plank.position.y=1.40;board.add(plank);
 const notice=new THREE.Mesh(new THREE.BoxGeometry(1.72,.78,.02),new THREE.MeshLambertMaterial({color:'#c4b18b'}));notice.position.set(0,1.4,.09);board.add(notice);
 for(const dy of [-.26,-.08,.10]){const row=new THREE.Mesh(new THREE.BoxGeometry(1.18,.035,.02),darkRock);row.position.set(-.12,1.4+dy,.11);board.add(row);}
 for(const x of [-.85,.85]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.12,1.35,.12),bark);leg.position.set(x,.675,0);board.add(leg);}
 scene.add(board);
 // Decorative tower roofs, intentionally do not imply buildable walkable surfaces.
 const roofMaterial=new THREE.MeshLambertMaterial({color:'#664b43'});
 for(const z of [-7.5,8.5]){
  const roof=new THREE.Mesh(new THREE.ConeGeometry(1.86,1.7,4),roofMaterial);
  roof.rotation.y=Math.PI/4;roof.position.set(-9.5,5.85,z);scene.add(roof);
  const tip=new THREE.Mesh(new THREE.CylinderGeometry(.035,.05,.45,5),iron);tip.position.set(-9.5,6.9,z);scene.add(tip);
 }
 return {
  animate:(now:number,phase:string)=>{
   for(let i=0;i<flagGroups.length;i++){
    const cloth=flagGroups[i].getObjectByName('cloth');if(cloth)cloth.rotation.y=Math.sin(now*.0012+i)*.12;
   }
   for(let i=0;i<flames.length;i++){
    const flame=flames[i].getObjectByName('flame');if(flame){flame.scale.y=.86+.18*Math.sin(now*.012+i);flame.scale.x=.92+.08*Math.cos(now*.016+i);}
   }
  }
 };
}
