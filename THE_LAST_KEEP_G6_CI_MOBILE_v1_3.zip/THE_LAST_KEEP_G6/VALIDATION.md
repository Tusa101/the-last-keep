# G3.1 Validation Record

10 October 2026 — source-level checks only.

| Command / check | Result |
| --- | --- |
| `npm test` (Node 22) | PASS — 42/42 |
| `tsc --project tsconfig.core.json` | PASS |
| TS parsing/transpile for `main.ts`, `render/scene.ts` | PASS (syntax only) |
| `npm install --no-audit --no-fund` | FAILED — npm registry DNS unavailable (`EAI_AGAIN`) |
| `npm run build` | NOT RUN — missing dependencies |
| Browser smoke test | NOT RUN |
| GitHub Pages publication | NOT RUN |

## Test focus

* Ground-routing, collision, 3D building geometry and structure support retained from earlier versions.
* Additional tests in `tests/combat.test.mjs`: precise wall/sphere ordering, arrow-slit aperture, low slabs, vertical aim, range, degenerate directions.
* Expanded `tests/siege.test.mjs`: three-wave cycle, no material-from-research loophole, two weapon roles, trap improvement, knockback blocked by wall, save/reload of live raid, invalid save handling, distinctive brute behavior.

## Remaining verification obligations

The `src/render/scene.ts` Three.js API usage and the TypeScript typing of `src/main.ts` have not been compiled against actual `three` dependencies here. Run full `npm run build`, then manually inspect the game in Chrome/Firefox and check the console. Do not treat passing game-model tests as evidence of an error-free browser scene.
