import test from 'node:test';import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {traceShot} from '../src/game/combat.ts';
const target=(x,y,z)=>[{id:42,position:{x,y,z},radius:.35}];
test('an intact wall occludes the enemy regardless of aim angle proximity',()=>{
 const w=new World();w.seed({x:2,y:0,z:0});
 const hit=traceShot(w,{x:0,y:.5,z:0},{x:1,y:0,z:0},target(4,.5,0));
 assert.equal(hit.kind,'wall');assert.deepEqual(hit.cell,{x:2,y:0,z:0});
});
test('a front enemy is hit before a more distant wall',()=>{
 const w=new World();w.seed({x:5,y:0,z:0});
 const hit=traceShot(w,{x:0,y:.5,z:0},{x:1,y:0,z:0},target(2,.5,0));
 assert.equal(hit.kind,'enemy');assert.equal(hit.targetId,42);
});
test('arrow slit can pass a narrow 3D ray while its solid piers obstruct another',()=>{
 const w=new World();w.seed({x:2,y:0,z:0},'stone','arrowSlit');
 const clear=traceShot(w,{x:0,y:.5,z:0},{x:1,y:0,z:0},target(4,.5,0));
 const blocked=traceShot(w,{x:0,y:.5,z:.32},{x:1,y:0,z:0},target(4,.5,.32));
 assert.equal(clear.kind,'enemy');assert.equal(blocked.kind,'wall');
});
test('shot over a low slab misses the slab',()=>{
 const w=new World();w.seed({x:2,y:0,z:0},'stone','slab');
 assert.equal(traceShot(w,{x:0,y:.8,z:0},{x:1,y:0,z:0},target(4,.8,0)).kind,'enemy');
});
test('vertical aim matters, distant/out-of-range enemies cannot be hit',()=>{
 const w=new World();
 assert.equal(traceShot(w,{x:0,y:1,z:0},{x:1,y:1,z:0},target(4,.5,0)).kind,'miss');
 assert.equal(traceShot(w,{x:0,y:.5,z:0},{x:1,y:0,z:0},target(30,.5,0)).kind,'miss');
});
test('degenerate direction cannot produce NaN ray hits',()=>{
 assert.equal(traceShot(new World(),{x:0,y:0,z:0},{x:0,y:0,z:0},target(2,0,0)).kind,'miss');
});
