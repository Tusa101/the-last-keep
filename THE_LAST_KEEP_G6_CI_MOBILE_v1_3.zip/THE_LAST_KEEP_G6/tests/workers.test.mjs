import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Gathering} from '../src/game/gathering.ts';
import {Workers,STOCKPILE} from '../src/game/workers.ts';
import {findWorkerRoute} from '../src/ai/workerNavigation.ts';

const setup=()=>{const world=new World(),g=new Gathering(world),w=new Workers(world,g);return {world,g,w};};
const tick=(w,n=500,phase='PREP')=>{for(let i=0;i<n;i++)w.step(.1,phase);};

test('worker nav refuses solid masonry but can find another opening',()=>{
 const world=new World();for(let z=-2;z<=2;z++)world.seed({x:0,y:0,z});
 const route=findWorkerRoute(world,{x:-2,z:0},{x:2,z:0},.1);
 assert.ok(route);assert.ok(route.some(p=>Math.abs(p.z)>2));
 assert.ok(route.every(p=>world.groundObstructions(p.x,p.z).length===0));
});
test('unreachable friendly goals are not achieved by breach or teleport',()=>{
 const world=new World();for(let z=-22;z<=22;z++)world.seed({x:0,y:0,z});
 assert.equal(findWorkerRoute(world,{x:-2,z:0},{x:2,z:0}),null);
 assert.equal(world.get(0,0,0).hp,100);
});
test('first helper is gated by completed first wave, second costs wood and limit 2',()=>{
 const {world,w}=setup(),wood=world.resources.wood;
 assert.equal(w.hire('PREP',0).ok,false);assert.equal(w.hire('SIEGE',1).ok,false);
 assert.equal(w.hire('RESULT',1).ok,true);assert.equal(world.resources.wood,wood);
 assert.equal(w.hire('PREP',1).ok,true);assert.equal(world.resources.wood,wood-10);
 assert.equal(w.hire('PREP',2).ok,false);
});
test('worker harvest consumes finite deposit but credits stock only after delivery',()=>{
 const {world,g,w}=setup();w.hire('PREP',1);w.setMode('gather');
 const initialStock=world.resources.stone+world.resources.wood;
 let sawCargo=false;let stockAtCargo=0;
 for(let i=0;i<900;i++){
  w.step(.1,'PREP');
  if(w.workers[0].cargo&&!sawCargo){sawCargo=true;stockAtCargo=world.resources.stone+world.resources.wood;
   assert.ok(g.deposits.some(d=>d.remaining<d.capacity));break;}
 }
 assert.ok(sawCargo,'deposit was harvested');assert.equal(stockAtCargo,initialStock,'no instant resource credit');
 const item=w.workers[0].amount;
 for(let i=0;i<900&&w.workers[0].cargo;i++)w.step(.1,'PREP');
 assert.equal(w.workers[0].cargo,null,'cargo arrived at warehouse');
 assert.equal(world.resources.stone+world.resources.wood,initialStock+item);
});
test('queued building consumes material only upon work completion; no duplicate orders',()=>{
 const {world,w}=setup();w.hire('PREP',1);w.setMode('build');
 const one={x:6,y:0,z:3},two={x:7,y:0,z:3};
 assert.equal(w.queueBuild([one,two],'wood','full',0).ok,true);
 assert.equal(w.queueBuild([one],'wood','full',0).ok,false);
 assert.equal(world.resources.wood,45);
 tick(w,500);
 assert.ok(world.get(6,0,3));assert.ok(world.get(7,0,3));
 assert.equal(world.resources.wood,43);assert.equal(w.orders.length,0);
});
test('unfinished orders can remain pending until materials are delivered',()=>{
 const {world,w}=setup();w.hire('PREP',1);
 world.resources.stone=0;
 assert.equal(w.queueBuild([{x:6,y:0,z:3}],'stone','full',0).ok,true);
 tick(w,1200);
 assert.ok(world.get(6,0,3));assert.equal(w.orders.length,0);
 assert.ok(world.resources.stone>=0);
});
test('worker repairs damage and spends one matching physical resource',()=>{
 const {world,w}=setup();world.seed({x:6,y:0,z:3},'stone');world.damage({x:6,y:0,z:3},45);
 w.hire('PREP',1);w.setMode('repair');
 const initial=world.resources.stone;
 tick(w,450);
 assert.equal(world.get(6,0,3).hp,100);
 assert.equal(world.resources.stone,initial-2,'45 damage repaired over 2 operations');
});
test('under attack workers retreat, keep carrying cargo, and never mine',()=>{
 const {world,g,w}=setup();w.hire('PREP',1);w.setMode('gather');
 for(let i=0;i<950&&!w.workers[0].cargo;i++)w.step(.1,'PREP');
 assert.ok(w.workers[0].cargo);
 const left=g.deposits.reduce((a,b)=>a+b.remaining,0);
 tick(w,280,'SIEGE');
 assert.equal(g.deposits.reduce((a,b)=>a+b.remaining,0),left);
 assert.equal(w.workers[0].cargo,null,'cargo is delivered without loss during retreat');
 assert.equal(w.workers[0].status,'В укрытии');
});
test('save restores in-flight cargo and queue without duplication',()=>{
 const {world,g,w}=setup();w.hire('PREP',1);w.setMode('gather');
 const queued=w.queueBuild([{x:6,y:0,z:3}],'stone','full',0);assert.ok(queued.ok);
 for(let i=0;i<800&&!w.workers[0].cargo;i++)w.step(.1,'PREP');
 assert.ok(w.workers[0].cargo);
 const snap=[world.serialize(),g.snapshot(),w.snapshot()];
 const world2=new World();world2.restore(snap[0]);const g2=new Gathering(world2);g2.restore(snap[1]);
 const w2=new Workers(world2,g2);w2.restore(snap[2]);
 assert.equal(w2.workers[0].amount,w.workers[0].amount);
 assert.equal(w2.orders.length,1);
 const initial=world2.resources.stone+world2.resources.wood,carry=w2.workers[0].amount;
 for(let i=0;i<700&&w2.workers[0].cargo;i++)w2.step(.1,'PREP');
 assert.equal(world2.resources.stone+world2.resources.wood,initial+carry);
});
test('invalid state is refused atomically, cancellation does not refund nonexistent cost',()=>{
 const {world,w}=setup();w.hire('PREP',1);w.setMode('build');
 w.queueBuild([{x:8,y:0,z:6}],'stone','full',0);
 const snap=w.snapshot(),resources=world.resources.stone;
 const bad=JSON.parse(snap);bad.orders.push({...bad.orders[0]});
 assert.throws(()=>w.restore(JSON.stringify(bad)),/Invalid worker orders/);
 assert.equal(w.snapshot(),snap);
 assert.equal(w.clearOrders(),1);assert.equal(world.resources.stone,resources);
});
test('delayed worker construction never traps player inside a newly placed block',()=>{
 const {world,w}=setup();w.hire('PREP',1);w.setMode('build');
 const cell={x:6,y:0,z:3};w.queueBuild([cell],'stone','full',0);
 for(let i=0;i<120;i++)w.step(.1,'PREP',{x:6,y:0,z:3});
 assert.equal(world.get(6,0,3),undefined);
 assert.equal(w.orders.length,1);
 for(let i=0;i<120;i++)w.step(.1,'PREP',{x:0,y:0,z:0});
 assert.ok(world.get(6,0,3));assert.equal(w.orders.length,0);
});
test('workers do not build or harvest during siege even with queued plans',()=>{
 const {world,g,w}=setup();w.hire('PREP',1);w.setMode('balanced');
 w.queueBuild([{x:5,y:0,z:2}],'stone','full',0);
 const inventory=world.resources.stone;
 tick(w,200,'SIEGE');
 assert.equal(world.get(5,0,2),undefined);
 assert.equal(world.resources.stone,inventory);
 assert.ok(g.deposits.every(d=>d.remaining===d.capacity));
 tick(w,200,'PREP');assert.ok(world.get(5,0,2));
});
