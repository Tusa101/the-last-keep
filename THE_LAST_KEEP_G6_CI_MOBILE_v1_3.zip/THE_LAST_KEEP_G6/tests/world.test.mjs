import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
const c=(x,y,z)=>({x,y,z});
test('multi-level construction is grounded, 3D and transactional',()=>{
 const w=new World();
 const balance=w.resources.stone;
 assert.equal(w.build('float',[c(2,3,2)],'stone').ok,false);
 assert.equal(w.resources.stone,balance);assert.equal(w.revision,0);
 assert.equal(w.build('foundation',[c(2,0,2)],'stone').ok,true);
 assert.equal(w.placeLine('column',c(2,1,2),c(2,4,2),'stone').ok,true);
 assert.equal(w.get(2,4,2)?.hp,100);
 assert.equal(w.resources.stone,balance-5);
 assert.equal(w.placeLine('column',c(2,1,2),c(2,4,2),'stone').ok,false);
 assert.equal(w.resources.stone,balance-5);
 const before=w.blocks.size,rev=w.revision;
 assert.equal(w.build('bad-line',[c(3,4,2),c(2,4,2)],'stone').ok,false);
 assert.equal(w.blocks.size,before);assert.equal(w.revision,rev);
});
test('lateral platforms require support and are lost when disconnected',()=>{
 const w=new World();w.seed(c(0,0,0));w.seed(c(0,1,0));
 assert.equal(w.placeLine('bridge',c(1,1,0),c(3,1,0),'wood','slab').ok,true);
 assert.equal(w.get(3,1,0)?.shape,'slab');
 assert.equal(w.remove('remove-root',c(0,0,0)),true);
 assert.equal(w.blocks.size,0); // support dependency really collapses
 assert.equal(w.resources.stone,90.5); // no refund for collapse
 assert.equal(w.resources.wood,42); // bridge resources never refunded
});
test('3D saves preserve full/half height, resources; schema 1 migration',()=>{
 const w=new World();w.seed(c(1,0,1));w.build('stair-step',[c(1,1,1)],'wood','slab');
 const next=new World();next.restore(w.serialize());
 assert.deepEqual(next.get(1,1,1),w.get(1,1,1));
 assert.deepEqual(next.resources,w.resources);
 const legacy=JSON.stringify({schema:1,blocks:[['4,5',{material:'wood',hp:20}]],resources:{stone:4,wood:1}});
 next.restore(legacy);assert.equal(next.get(4,0,5)?.hp,20);assert.equal(next.get(4,1,5),undefined);
});
test('invalid save is rejected atomically',()=>{
 const w=new World();w.seed(c(0,0,0));const before=w.serialize();
 assert.throws(()=>w.restore(JSON.stringify({schema:2,resources:{stone:-5,wood:3},blocks:[]})));
 assert.throws(()=>w.restore(JSON.stringify({schema:2,resources:{stone:4,wood:3},blocks:[['1,9,0',{material:'stone',hp:200,shape:'full'}]]})));
 assert.equal(w.serialize(),before);
});
test('damage at ground level disconnects upper masonry',()=>{
 const w=new World();for(let y=0;y<3;y++)w.seed(c(0,y,0));
 w.damage(c(0,0,0),105);
 assert.equal(w.blocks.size,0);
});
test('damage and repair update revision; repair spends physical resources',()=>{
 const w=new World();w.seed(c(0,0,0));
 const r=w.revision;w.damage(c(0,0,0),20);
 assert.ok(w.revision>r);assert.equal(w.repair('fix',c(0,0,0)),true);
 assert.equal(w.get(0,0,0)?.hp,100);assert.equal(w.resources.stone,89);
});
