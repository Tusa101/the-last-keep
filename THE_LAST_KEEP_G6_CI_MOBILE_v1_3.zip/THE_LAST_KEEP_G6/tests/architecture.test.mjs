import test from 'node:test';
import assert from 'node:assert/strict';
import {World,MAX_CANTILEVER} from '../src/world/model.ts';
import {shapeBoxes} from '../src/world/shapes.ts';
import {stepPlayer,intersectsPlayer} from '../src/physics/player.ts';
const c=(x,y,z)=>({x,y,z});
const controls=(dx,dz)=>({dx,dz,jump:false});

test('stair has two half-height treads and rotates consistently',()=>{
 const east=shapeBoxes('stair',0),north=shapeBoxes('stair',1);
 assert.equal(east.length,2);
 assert.equal(east[0].y1,.5);assert.equal(east[1].y1,1);
 assert.equal(east[0].x1,0);assert.equal(north[0].z1,0);
 assert.ok(shapeBoxes('arrowSlit',1).some(v=>v.x0>0));
});
test('player can walk up a full block of stairs, from low to high step',()=>{
 const world=new World();world.seed(c(0,0,0),'stone','stair',0);
 let p={x:-1.3,y:0,z:0,vy:0,grounded:true};
 let sawHalf=false,sawTop=false;
 for(let i=0;i<46;i++){
  p=stepPlayer(world,p,controls(1,0),1/60);
  if(Math.abs(p.y-.5)<1e-3)sawHalf=true;
  if(Math.abs(p.y-1)<1e-3)sawTop=true;
 }
 assert.ok(sawHalf,'reaches lower 0.5m stair tread');
 assert.ok(sawTop,'reaches upper 1.0m stair tread');
 assert.ok(p.x>.2,'has progressed over the high tread');
});
test('player cannot step over a solid one-meter wall',()=>{
 const world=new World();world.seed(c(0,0,0));
 let p={x:-1.3,y:0,z:0,vy:0,grounded:true};
 for(let i=0;i<40;i++)p=stepPlayer(world,p,controls(1,0),1/60);
 assert.ok(p.x<-.7);assert.ok(p.y<.01);
});
test('rotating the staircase 90° makes it ascend +Z, not +X',()=>{
 const world=new World();world.seed(c(0,0,0),'wood','stair',1);
 let p={x:0,y:0,z:-1.3,vy:0,grounded:true},half=false,top=false;
 for(let i=0;i<46;i++){p=stepPlayer(world,p,controls(0,1),1/60);half ||= Math.abs(p.y-.5)<.001;top ||= Math.abs(p.y-1)<.001;}
 assert.ok(half&&top,'climbs rotated stair');assert.ok(p.z>.1);
});
test('narrow arrow slit blocks walking but provides empty aperture between piers',()=>{
 const boxes=shapeBoxes('arrowSlit');
 const crosses=(x,y,z,b)=>x>b.x0&&x<b.x1&&y>b.y0&&y<b.y1&&z>b.z0&&z<b.z1;
 assert.equal(boxes.some(b=>crosses(0,.6,0,b)),false,'ray can fly through slit at eye height');
 assert.equal(intersectsPlayer(c(0,0,0),'arrowSlit',{x:0,y:0,z:0,vy:0,grounded:true}),true,'body too broad to pass');
});
test('cantilevers are capped at three laterally supported cells',()=>{
 const w=new World();w.seed(c(0,0,0));w.seed(c(0,1,0));
 assert.equal(MAX_CANTILEVER,3);
 assert.equal(w.build('gallery',[c(1,1,0),c(2,1,0),c(3,1,0)],'wood','slab').ok,true);
 const resources=w.resources.wood,revision=w.revision;
 assert.equal(w.build('too-long',[c(4,1,0)],'wood','slab').ok,false);
 assert.equal(w.resources.wood,resources);assert.equal(w.revision,revision);
 assert.equal(w.get(4,1,0),undefined);
});
test('second grounded column permits supported bridge between piers',()=>{
 const w=new World();for(const x of [0,6]){w.seed(c(x,0,0));w.seed(c(x,1,0));}
 assert.equal(w.build('bridge',Array.from({length:5},(_,i)=>c(i+1,1,0)),'wood','slab').ok,true);
 assert.equal(w.get(3,1,0)?.shape,'slab');
});
test('removing an anchor collapses overextended gallery but saves the near section',()=>{
 const w=new World();for(const x of [0,6]){w.seed(c(x,0,0));w.seed(c(x,1,0));}
 w.build('bridge',Array.from({length:5},(_,i)=>c(i+1,1,0)),'wood');
 w.remove('delete-right',c(6,0,0));
 assert.ok(w.get(2,1,0),'near left support stays up');
 assert.equal(w.get(5,1,0),undefined,'rightmost unsupported span collapses');
});
test('orientation and new shapes survive version 3 serialization',()=>{
 const w=new World();w.build('stair',[c(1,0,1)],'wood','stair',3);
 w.build('slit',[c(2,0,1)],'stone','arrowSlit',2);
 const copy=new World();copy.restore(w.serialize());
 assert.equal(copy.get(1,0,1)?.dir,3);assert.equal(copy.get(1,0,1)?.shape,'stair');
 assert.equal(copy.get(2,0,1)?.dir,2);assert.equal(copy.get(2,0,1)?.shape,'arrowSlit');
});
test('legacy version 2 schema receives orientation default 0',()=>{
 const w=new World();w.restore(JSON.stringify({schema:2,resources:{stone:2,wood:3},blocks:[['0,0,0',{material:'stone',shape:'slab',hp:40}]]}));
 assert.equal(w.get(0,0,0)?.dir,0);assert.equal(w.get(0,0,0)?.shape,'slab');
});
test('invalid rotation or shape in a save is rejected without mutation',()=>{
 const w=new World();w.seed(c(0,0,0));const before=w.serialize();
 assert.throws(()=>w.restore(JSON.stringify({schema:3,resources:{stone:5,wood:4},blocks:[['0,0,0',{material:'stone',shape:'stair',dir:4,hp:40}]]})));
 assert.equal(w.serialize(),before);
 assert.equal(w.build('bad',[c(1,0,0)],'stone','stair',8).ok,false);
});
test('batch plan uses at most four draw groups for many different architectural shapes',async()=>{
 const {collectBatches}=await import('../src/render/batches.ts');
 const w=new World();let n=0;
 for(let x=-10;x<10;x++)for(let z=-10;z<10;z++){
  const shapes=['full','slab','stair','battlement','arrowSlit'];
  w.seed(c(x,0,z),z%2===0?'stone':'wood',shapes[(x+z+100)%5],((x+100)%4));n++;
 }
 const batches=collectBatches(w);
 assert.ok(batches.size<=4);assert.equal(n,w.blocks.size);
 assert.ok([...batches.values()].reduce((count,arr)=>count+arr.length,0)>n,'complex shapes create more than one instance');
 // The previous renderer created one Mesh per full block; now batches are bounded.
});
test('starting castle can be reloaded without collapsing any intended decorative or structural blocks',async()=>{
 const {seedCastle}=await import('../src/world/preset.ts');
 const w=new World();seedCastle(w);
 const startCount=w.blocks.size,baseline=w.serialize();
 const reloaded=new World();reloaded.restore(baseline);
 assert.equal(reloaded.blocks.size,startCount,'every initial block belongs to supported component');
 assert.ok([...reloaded.blocks.values()].some(b=>b.shape==='stair'));
 assert.ok([...reloaded.blocks.values()].some(b=>b.shape==='arrowSlit'));
});
