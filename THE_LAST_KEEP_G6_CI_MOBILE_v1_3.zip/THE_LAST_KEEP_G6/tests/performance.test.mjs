import test from 'node:test';import assert from 'node:assert/strict';import {AdaptiveQuality} from '../src/game/performance.ts';
test('quality presets have distinct pixel ratios',()=>{const q=new AdaptiveQuality();assert.equal(q.setMode('battery'),.65);assert.equal(q.setMode('quality'),1.35);assert.equal(q.setMode('auto'),1);});
test('auto quality drops after sustained slow frames',()=>{const q=new AdaptiveQuality();for(let i=0;i<120;i++)q.observe(1/25);assert.ok(q.scale<1);});
test('auto quality rises after sustained fast frames',()=>{const q=new AdaptiveQuality();q.scale=.7;for(let i=0;i<120;i++)q.observe(1/90);assert.ok(q.scale>.7);});
test('outlier frames do not trigger scaling',()=>{const q=new AdaptiveQuality();for(let i=0;i<120;i++)q.observe(2);assert.equal(q.scale,1);});
test('fixed quality mode ignores performance samples',()=>{const q=new AdaptiveQuality();q.setMode('battery');for(let i=0;i<500;i++)q.observe(.1);assert.equal(q.scale,.65);});
