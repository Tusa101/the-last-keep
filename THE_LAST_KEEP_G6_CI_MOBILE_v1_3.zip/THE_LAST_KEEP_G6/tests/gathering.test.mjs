import test from 'node:test';import assert from 'node:assert/strict';
import {Gathering} from '../src/game/gathering.ts';import {World} from '../src/world/model.ts';
test('mining requires physical proximity and takes finite quantities',()=>{
 const w=new World(),g=new Gathering(w),stone=w.resources.stone;
 assert.equal(g.harvest(0,0,0).ok,false);assert.equal(w.resources.stone,stone);
 const r=g.harvest(3,6,0);assert.equal(r.amount,6);assert.equal(w.resources.stone,stone+6);
 assert.equal(g.harvest(3,6,.01).ok,false);
 for(let i=1;i<4;i++)g.harvest(3,6,i);
 assert.equal(g.deposits[0].remaining,0);
 assert.equal(w.resources.stone,stone+18);
 assert.equal(g.harvest(3,6,6).ok,false);
});
test('harvest and building remain separate from research rewards',()=>{
 const w=new World(),g=new Gathering(w),wood=w.resources.wood;
 const r=g.harvest(-5,12,1);assert.equal(r.material,'wood');assert.equal(w.resources.wood,wood+5);
 assert.equal(w.resources.stone,90);
});
test('gather state roundtrips and corrupted saves are atomic',()=>{
 const w=new World(),g=new Gathering(w);g.harvest(3,6,0);
 const save=g.snapshot(),g2=new Gathering(w);g2.restore(save);
 assert.equal(g2.snapshot(),save);
 const bad=JSON.parse(save);bad.deposits[0].remaining=100000;
 assert.throws(()=>g2.restore(JSON.stringify(bad)),/Invalid resource/);
 assert.equal(g2.snapshot(),save);
});
