import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {stepPlayer,intersectsPlayer} from '../src/physics/player.ts';
const c=(x,y,z)=>({x,y,z});
const noInput={dx:0,dz:0,jump:false};
test('player cannot walk through a two-level wall',()=>{
 const w=new World();w.seed(c(0,0,0));w.seed(c(0,1,0));
 let p={x:-2,y:0,z:0,vy:0,grounded:true};
 for(let i=0;i<90;i++)p=stepPlayer(w,p,{dx:1,dz:0,jump:false},1/60);
 assert.ok(p.x<-.7);
});
test('player falls and lands on top of stone or a slab',()=>{
 const w=new World();w.seed(c(0,0,0));w.seed(c(2,0,0),'wood','slab');
 let p={x:0,y:2.5,z:0,vy:0,grounded:false};
 for(let i=0;i<120;i++)p=stepPlayer(w,p,noInput,1/60);
 assert.equal(p.y,1);assert.equal(p.grounded,true);
 p={x:2,y:2.5,z:0,vy:0,grounded:false};
 for(let i=0;i<120;i++)p=stepPlayer(w,p,noInput,1/60);
 assert.equal(p.y,.5);assert.equal(p.grounded,true);
});
test('collision includes roof voxels; player build overlap can be checked',()=>{
 const w=new World();w.seed(c(0,2,0));
 assert.ok(intersectsPlayer(c(0,2,0),'full',{x:0,y:1,z:0,vy:0,grounded:false}));
 let p={x:0,y:0,z:0,vy:0,grounded:true};
 for(let i=0;i<12;i++)p=stepPlayer(w,p,{dx:0,dz:0,jump:i===0},1/60);
 assert.ok(p.y<.4,'head collides with block above');
});
