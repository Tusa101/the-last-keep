import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {findRoute} from '../src/ai/navigation.ts';
import {Enemy} from '../src/ai/breach.ts';
const c=(x,y,z)=>({x,y,z});
test('AI detours around expensive stacked blocks',()=>{
 const w=new World();for(const y of [0,1])w.seed(c(0,y,0));
 const route=findRoute(w,{x:-2,z:0},{x:2,z:0});
 assert.ok(route);assert.equal(route.breaches,0);assert.ok(route.cells.some(p=>p.z!==0));
});
test('AI breaches long wall blocking all ground routes',()=>{
 const w=new World();for(let z=-22;z<=22;z++)w.seed(c(0,0,z),'wood');
 const route=findRoute(w,{x:-2,z:0},{x:2,z:0});
 assert.ok(route);assert.ok(route.breaches>=1);
});
test('upper floating bridge is not treated as ground obstacle',()=>{
 const w=new World();w.seed(c(0,0,1));w.seed(c(0,1,1));w.seed(c(0,2,1));w.seed(c(0,2,0));
 assert.deepEqual(w.groundObstructions(0,0),[]);
 const route=findRoute(w,{x:-2,z:0},{x:2,z:0});
 assert.ok(route);assert.equal(route.breaches,0);
});
test('enemy repaths on 3D construction during travel',()=>{
 const w=new World(),enemy=new Enemy(w);
 for(let i=0;i<90;i++)enemy.step(1/60);
 const z=enemy.z;
 w.build('wall',[c(-10,0,0)],'stone');
 for(let i=0;i<145;i++)enemy.step(1/60);
 assert.equal(w.get(-10,0,0)?.hp,100);
 assert.notEqual(enemy.z,z);
});
