import test from 'node:test';import assert from 'node:assert/strict';
import {screenToGrid,gridToScreen,planLine,planRectangle} from '../src/game/architect.ts';
test('screen center maps to grid origin',()=>assert.deepEqual(screenToGrid(315,315,630,630),{x:0,z:0}));
test('grid coordinates roundtrip',()=>{for(const [x,z] of [[-22,-22],[0,0],[10,-5],[22,22]]){const p=gridToScreen(x,z,630,630);assert.deepEqual(screenToGrid(p.x,p.y,630,630),{x,z});}});
test('line clamps to 24 blocks',()=>assert.equal(planLine({x:-22,z:0},{x:22,z:0},0).length,24));
test('line follows dominant axis',()=>assert.deepEqual(planLine({x:0,z:0},{x:2,z:5},1).at(-1),{x:0,y:1,z:5}));
test('rectangle is hollow perimeter',()=>assert.equal(planRectangle({x:0,z:0},{x:3,z:3},0).length,12));
test('oversized rectangle rejected',()=>assert.deepEqual(planRectangle({x:-10,z:-10},{x:10,z:10},0),[]));
test('single cell rectangle',()=>assert.deepEqual(planRectangle({x:2,z:3},{x:2,z:3},2),[{x:2,y:2,z:3}]));
