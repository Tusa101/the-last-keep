# G5.2 — Castle Management / Architect Mode (v1.2)

## Implemented
- P on desktop and 🏰 Architect in mobile menu opens a touch-first overhead map.
- Tap two cells to design a straight wall or hollow tower perimeter; switch floor (0–10), material, shape, rotation.
- Existing blocks and pending worker blueprints displayed with different colors; Nexus marker shown.
- Worker orders created through existing authoritative queue, with same validation and material costs.
- Queue clearing and selection reset.
- Movement and firing disabled while planning; siege simulation continues (architect is NOT a pause exploit).
- Seven new tests for grid conversion and plan shapes.

## Known limitations
- Architectural view is a 2D top-down blueprint, not a second Three.js orbit camera.
- Each order capped at 24 cells and total queue capped at 60; no batch multi-order transaction.
- No automatic assignment of distinct professions or multi-level worker navigation yet.
- Walls are not automatically checked for accessibility until workers try to build them.
- Actual mobile browser / full Vite build not verified in this environment.
