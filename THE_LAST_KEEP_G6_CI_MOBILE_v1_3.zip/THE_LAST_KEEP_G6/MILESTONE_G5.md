# THE LAST KEEP — G5: Workers & Automation (v1.0)

## What shipped

- **Two physical NPC workers** (procedural medieval porters with shoulder packs and visible cargo). One free after the first successful wave; a second requires 10 real units of wood. No unlimited population or exchange of research points for stone.
- **Physical resource transfer**: workers visit an existing finite stone/wood deposit; at the end of a short mining animation/delay they subtract up to 8 stone or 6 wood; then carry it through the map to the courtyard stockpile, where the amount is credited to the shared inventory. Resources carried in transit survive save/load and wave interruptions.
- **Real ground navigation**: friendly BFS ground routing avoids occupied cells. Workers do not attack or phase through masonry. Unreachable tasks show a blocked reason; queued jobs can be cancelled. No fake teleport workaround.
- **Blueprint queue**: aim at a single block or select a line/column with existing controls; queue up to 60 distinct block placements through `T`. Blocks appear as faint cyan ghosts; each is built only after a worker reaches a neighboring free cell and a valid supported placement is possible. Stock is deducted at that moment.
- **Repair**: find damaged accessible lower masonry; walk adjacent and repair using the corresponding physical material. Priorities: auto, gather, build, repair.
- **Siege rules**: upon WARNING/SIEGE workers stop production/repair, retreat to stockpile, and deposit carried cargo. They do not fight. PREP resumes activity.
- **Persistence**: new save envelope v4 includes complete worker state (positions, cargo, queue, mode); old v2/v3 save envelopes remain loadable. Invalid new worker saves are checked using disposable world/gatherer prior to mutating the live world.
- **Desktop and mobile**: J/T/Y/C shortcuts; touch menu with hire, plan, priorities and clear queue. Work status and stock positions are visible on the HUD/minimap.

## Explicit scope cuts

- No real mining animations, carts, resource items rolling on terrain, worker health, morale, combat AI, worker death, lifts, 3D floor-to-floor pathfinding, building stairs by following multi-storey waypoints, voice lines, or automatic structural planning.
- Workers are ground-based (2.5D). They can place blocks above them within the simplified work model, but do not physically climb tower stairs or stand on galleries.
- Shared stockpile is an abstract supply point on the authoritative grid; its scenic canopy is visual only, not a collision object.
- No browser performance measurement, real device touch usability test, or GitHub Pages deployment is claimed.

## Acceptance gates to complete after deployment

1. Load in desktop Chrome; confirm two workers never duplicate resources, never walk through solid wall cells, and carry physical materials before inventory increases.
2. Repair a damaged curtain wall during the second preparation; verify the material cost and permanent result.
3. Queue a line of blocks with T, watch each placed individually with ghost preview disappearing, and cancel pending work with C.
4. Begin wave while a worker has cargo; verify it returns to the warehouse, suspends work, and resumes after a win.
5. On Android Chrome in landscape, move/aim/fire with two thumbs and hire/order/mode/save using touch ☰, then reload and verify queued work.
6. Verify production build and GitHub Pages before sharing a play link.

## Next milestone proposal — G5.1 / End-to-end browser QA

Run actual desktop/mobile browser tests, fix any WebGL or overlay/collision bugs, inspect current FPS and draw calls on Android, and improve mobile order selection. Only then expand to carts, climbing helpers, complex automated plans or additional enemies.
