# Автодеплой последнего ZIP на GitHub Pages

## Как использовать (репозиторий с архивами)

1. Создайте пустой GitHub-репозиторий с веткой `main`.
2. Положите в корень репозитория файлы `scripts/select_latest.py` и `.github/workflows/deploy.yml` из **этого пакета**.
3. В настройках репозитория: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Загружайте в корень новые архивы `THE_LAST_KEEP_*_v1_3.zip`, `*_v1_4.zip` и т.д. — workflow запускается на push.
5. Автоматически выбирается **наибольшая семантическая версия** из имён ZIP (не дата изменения). Например, v1_10 новее v1_9.
6. Workflow безопасно распакует архив, установит зависимости, запустит тесты, соберёт Vite с base `/REPOSITORY/`, запустит браузерный smoke test, затем задеплоит `dist/`.
7. Адрес после деплоя: `https://<owner>.github.io/<repo>/`. Для репозитория `<owner>.github.io` Vite base нужно настроить отдельно (`/`).

**Важно:** ZIP должен содержать `package.json`, `index.html`, `src/` и тесты; допускается одна внешняя папка внутри ZIP. Для этого релиза workflow ожидает `npm run smoke` и зависимость `playwright`. Если в другом ZIP этих файлов нет, workflow остановится до публикации (без ложного успеха).

**Безопасность:** скрипт не исполняет файлы из ZIP до проверки путей, запрещает symlink и `../`, ограничивает объём распаковки. Архивы должны быть доверенными — npm scripts могут исполнять код в CI.

**Удобный способ обновления:** старые ZIP можно не удалять; workflow сам выберет наиболее новую версию. Можно вручную запустить через вкладку Actions → Deploy newest… → Run workflow.

## Проверка локально

```bash
python3 scripts/select_latest.py --root . --output _game
cd _game
npm install
npm test
npm run build
npm run dev
```

В ZIP включён `deployment/deploy-latest-zip.yml` — его содержимое надо разместить по пути `.github/workflows/deploy.yml` **в корне репозитория**, а `scripts/select_latest.py` — по соответствующему пути в корне репозитория. Сам архив в репозитории не распаковывайте.
