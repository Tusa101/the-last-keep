# G6 — Integration, CI and deployment reliability

- Packaged GitHub Pages workflow that automatically selects the newest versioned ZIP in the repository root.
- Safe extraction with ZIP path traversal and symlink guards, and size limits.
- Build/test pipeline runs on GitHub Actions where npm dependencies are available.
- Added browser smoke test with Playwright: desktop and narrow mobile viewport; captures screenshots.
- Added deployment setup instructions in Russian.

## What has NOT been verified in this environment

- Full npm install, Vite build, browser smoke, actual mobile touch controls, and GitHub Pages deployment: npm registry DNS is inaccessible here.
- A mobile viewport smoke is not a real phone/touch interaction test.

## Next gate

Run the GitHub Action once and inspect the logs/screenshots. Fix any actual compile/browser errors before feature expansion.
