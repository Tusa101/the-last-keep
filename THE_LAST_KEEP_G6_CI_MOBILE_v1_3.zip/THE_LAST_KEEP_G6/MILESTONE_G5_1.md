# G5.1 — Mobile & Performance Stabilization (v1.1)

This release continues the G5 project rather than introducing another major gameplay subsystem.

## Changes
- Auto/adaptive WebGL resolution: 120-frame sampling, lower/upper bounds, hysteresis via cooldown.
- Manual **battery / quality** presets accessible from the touch menu.
- FPS and resolution-scale telemetry in the HUD.
- Multi-pointer joystick/look guards, release touch states on blur and backgrounding.
- Reset simulation accumulator and frame clock after tab backgrounding, preventing catch-up bursts.
- Better safe-area padding and landscape/portrait layouts for small phone screens.
- Mobile help button.
- Five new deterministic performance tests.

## Limitations
- Browser/WebGL and actual phone testing are NOT claimed.
- Auto resolution uses main-loop frame timing, not GPU timer queries; it may react to CPU load.
- There is no FPS cap, native app, offline PWA, or accessibility audit yet.
- Touch UI still requires real-device usability review, especially portrait.

## Playtest checklist
1. Start on Android Chrome landscape, rotate to portrait, then back.
2. Hold joystick + look + fire concurrently; release all and verify movement stops.
3. Open ☰ → cycle Graphics: auto / battery / quality. Verify resolution indicator.
4. Lock screen or switch apps for >30 seconds; return. Confirm no simulation time spike.
5. Run all three siege waves and verify worker deliveries and save/load.
6. Inspect FPS and report device model, browser, orientation, frame rate and any overlaps.
