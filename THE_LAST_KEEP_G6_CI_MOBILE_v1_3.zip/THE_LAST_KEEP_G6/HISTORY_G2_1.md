# Milestone G2.1 — 3D Castle Structure / Status

## Achieved in source code
- Replace `WorldGrid(x,z)` with `World(x,y,z)`.
- Keep previous G1b enemy as a **2.5D ground infantry** navigator rather than misrepresent it as a 3D pathfinder.
- Add 3D block picking, stacking, horizontal wall lines, vertical columns, half-height slabs, gravity/collision/jump and raised structural platforms.
- Add basic support propagation and deterministic deletion of fully disconnected components.
- Include versioned saves, old save migration, and test checks for physical resource changes.

## Acceptance criteria checked by unit tests
1. Floating isolated block refused; column supported by a ground foundation succeeds.
2. Multi-block placement is atomic and idempotent.
3. Face-connected bridge collapses on removal of its last anchor, with no resource duplication.
4. Elevated blocks, half-height slabs, and resources round-trip through serialization.
5. Actor cannot walk through full-height walls and lands on elevated blocks/slabs.
6. Enemy avoids a costly stack, can plan a breach across an impassable row, and re-routes on world revision changes.

## NEXT: G2.2 / G3 prerequisites
- Model actual staircase/ramp parts, with appropriate step collision and AI navigation-link semantics.
- Incremental chunk or instanced voxel rendering; avoid full-rebuild cost.
- Per-face block selection and elevation overrides for faster 3D line placement.
- Structural integrity budget / short-span limit, damage and visually legible collapsing chunks.
- Simple ground digging down to absolute world Y boundary; world-space ground/nav changes.
- Define victory/loss state and timed wave machine, then integrate player FPS combat, two enemy roles and wave rewards.

**The G2.1 demo does not claim to be a full vertical slice or a working siege game.**
