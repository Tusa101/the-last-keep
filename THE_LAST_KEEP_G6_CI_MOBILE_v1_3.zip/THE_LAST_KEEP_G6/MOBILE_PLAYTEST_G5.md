# G5 Mobile Playtest — THE LAST KEEP v1.0

**Status: unverified on a physical device.** Prefer landscape orientation, Android Chrome or iOS Safari. A GitHub Pages deployment is not yet available.

## Open from phone on the same Wi-Fi (without deploying)

1. Install Node.js 22 on the **computer** and unpack this repository.
2. In its directory run `npm install`, then `npm run dev` (Vite is already configured with `--host 0.0.0.0`).
3. Find the computer's Wi-Fi LAN IP (e.g. `192.168.1.50`); open `http://192.168.1.50:5173` on the **phone** on the same LAN. Do not enter the placeholder address literally.
4. If the page does not load, check same network, firewall, Vite console port, and local network isolation; otherwise publish via the included GitHub Pages workflow (requires your own repository and GitHub authentication).

## Touch controls

- **Left stick** move; **drag on right** aim.
- **Огонь** hold to fire, **↑** hold to jump; + / − build/remove; ✚ repair, ⛏ mine.
- Top controls: start wave early, advance after results, buy research, **☰ menu**.
- **☰ → 👷 Нанять** after wave one; **☰ → ⚒ Поручить стройку** at the reticle; **☰ → ↻ Задачи** to change priority; **☰ → × Очередь** to cancel pending plans. The menu also has save/load.
- Select an initial line point by tapping build in Line mode, then aim at the endpoint and choose **☰ → Поручить стройку**. The game should project a cyan ghost blueprint and let the worker finish it; this uses the same task queue as the desktop version.

## Scenarios to record (PASS / FAIL + screenshot and device details)

1. Move, turn camera, and fire simultaneously (three touches). FPS stable, no accidental page scroll/zoom or button overlap.
2. Complete first siege, hire one worker from the menu, watch him go to a source and return with a visible pack; global resources increase only upon delivery.
3. Queue a small wooden wall near the courtyard, confirm it is built by the worker after resource deduction.
4. Switch to Repair, watch a damaged wall recover; switch back to Auto.
5. Begin a siege with worker carrying material and check that he retreats without dropping/duplicating cargo.
6. Save during an ongoing worker delivery, reload, and check worker, cargo, deposits, research and waves.
7. Rotate between portrait and landscape. Document any inaccessible menu/button regions, especially on narrow phones.

## Known constraints

- Workers operate on the **ground plane only**. High-floor navigation and resource transport animations are intentionally out of scope.
- The mobile menu displays extra actions but the landscape UI may still be cramped on small screens.
- Three.js WebGL build and mobile interaction have not yet been executed by the authoring environment; `npm install && npm run build` is the next verification gate.
