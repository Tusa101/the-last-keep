# Validation — G2.2 v0.5.0

Окружение: Node.js v22.16.0, глобальный TypeScript v5.8.3, **без установленных Three.js / Vite / @types/three**.

### Выполненные проверки

- `npm test`: **26/26 PASS**, включая 13 регрессионных тестов G2.1 и новые проверки лестниц, поворота, щели бойницы, опор, collapse, batch grouping, сериализации 1–3 и стартовой крепости.
- `tsc --noEmit --target es2022 --module esnext --moduleResolution bundler --strict --allowImportingTsExtensions src/world/model.ts src/world/shapes.ts src/world/preset.ts src/physics/player.ts src/ai/navigation.ts src/ai/breach.ts src/render/batches.ts`: **PASS**.
- TypeScript syntactic transpile `src/main.ts` и `src/render/scene.ts`: **0 синтаксических ошибок** (не заменяет typecheck).

### Непроверенные пункты

- `npm run build`: **не завершился**. Сборка остановилась на `TS2307 Cannot find module 'three'` в `src/main.ts` и `src/render/scene.ts`, поскольку npm-пакеты отсутствуют. Попытка `npm view three` завершилась DNS-ошибкой `EAI_AGAIN` для registry.npmjs.org. Это **не подтверждает** работоспособность браузерной сборки.
- Не проводились рендер-проверка, полноэкранный плейтест, fps-профилирование в браузере, публикация на GitHub Pages.

### Проверить у себя

```bash
npm install
npm test
npm run build
npm run dev
```

Затем пройти сценарии из `README.md`, проверить в DevTools ошибки JS, пересечения в бойницах, FPS при 200–5000 блоках, загрузку старого сохранения, точность выбора `instanceId` у нескольких блоков внутри одного InstancedMesh. Записать наблюдения в отдельный playtest log, прежде чем считать G2.2 принятым.
