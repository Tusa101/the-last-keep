# THE LAST KEEP — G3 First Siege (v0.6)

## Implemented
- Three waves; preparation (90 s), warning (15 s), active siege (90 s), result/victory/defeat.
- Early start `G`, next wave `N`.
- Multiple jelly raiders; heavy brute appears from wave two; all reuse the dynamic breach/navigation system.
- Nexus health; damage when raiders reach it; no automatic repair between waves.
- `Shift + left click` fires a simplified horizontal aim weapon (35 damage, 0.35 s cooldown, 19 m max range).
- Two-charge automated proximity trap at x=7, z=0; 60 damage per activation.
- Research points awarded for defense; `U` exchanges 20 points for 12 stone **as an explicitly temporary testing shortcut** (violates the locked two-economy design and must be replaced by blueprint/perk unlocks before the vertical slice).
- Existing construction, structural damage, dynamic navigation, and world saves retained.

## Known limitations
- No browser visual QA and no successful Vite build in this environment (npm registry DNS unavailable).
- Simplified hit detection ignores wall occlusion and enemy vertical geometry.
- Enemy pathing is 2.5D; several raiders may overlap.
- Brute uses slower stepping rather than its own attack damage profile.
- Wave/research/nexus progress is **not saved**; existing K/L saves only world and player.
- Enemy death has no effects/animation, trap lacks a firing animation, and waves have no spawn telegraph.
- No dedicated post-wave research UI or meaningful unlock choices.

## Test commands
`npm install && npm test && npm run build && npm run dev`

## Acceptance for next iteration
1. Verify browser build and play through all three waves.
2. Fix line-of-sight hits and add feedback, projectile visuals, sound.
3. Replace research-to-stone shortcut with real unlocks.
4. Persist phase/wave/nexus/research, add replay/restart and difficulty tuning.
