// Minimal browser integration smoke test, runs in CI only after npm install and Vite start.
// Checks render bootstrap, progression modal, touch UI and responsive button geometry.
import {chromium} from 'playwright';
import {readFileSync} from 'node:fs';
const expectedVersion=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8')).version;
const url=process.env.SMOKE_URL||'http://127.0.0.1:4173/';
const browser=await chromium.launch({headless:true,args:['--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const errors=[];
try{
 const desktop=await browser.newPage({viewport:{width:1280,height:800}});
 desktop.on('pageerror',e=>errors.push(e.message));
 desktop.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 const response=await desktop.goto(url,{waitUntil:'networkidle',timeout:30000});
 const releaseResponse=await desktop.request.get(new URL('release.json',url).toString());
 if(!releaseResponse.ok())throw Error('Missing production release.json receipt');
 const receipt=await releaseResponse.json();
 if(receipt.version!==expectedVersion)throw Error('Wrong deployed bundle: '+JSON.stringify(receipt));
 if(!response?.ok())throw new Error('Desktop HTTP '+response?.status());
 await desktop.waitForSelector('canvas',{timeout:15000});
 await desktop.waitForFunction(()=>document.documentElement.dataset.gameReady==='true',null,{timeout:20000});
 if(await desktop.locator('#last-keep-boot-error').count())throw Error('Bootstrap failed on desktop');
 await desktop.waitForTimeout(1000);
 const stats=await desktop.evaluate(()=>({title:document.title,webgl:[...document.querySelectorAll('canvas')].some(c=>!!(c.getContext('webgl2')||c.getContext('webgl')))}));
 // G9 feedback layer exists, but never captures pointer events or covers control taps.
 const feedback=await desktop.locator('#nexus-feedback').evaluate(e=>({pointer:getComputedStyle(e).pointerEvents,opacity:getComputedStyle(e).opacity}));
 if(feedback.pointer!=='none')throw new Error('G9 combat feedback blocks pointer input');
 await desktop.screenshot({path:'smoke-desktop.png'});
 await desktop.locator('#tutorial-guide').waitFor({timeout:4000});
 await desktop.keyboard.press('F1');
 if(await desktop.locator('#tutorial-guide').isVisible())throw new Error('F1 did not hide guide');
 await desktop.keyboard.press('F1');
 await desktop.locator('#tutorial-guide').waitFor({state:'visible',timeout:4000});
 if(!stats.webgl)throw new Error('No WebGL canvas: '+JSON.stringify(stats));
 await desktop.keyboard.press('u');
 await desktop.locator('#development:not([hidden])').waitFor({timeout:4000});
 const cards=await desktop.locator('.development-card').count();
 if(cards!==3)throw new Error('Missing progression choices: '+cards);
 const enabled=await desktop.locator('#development [data-dev]:not([disabled])').count();
 if(enabled!==0)throw new Error('Progression should be locked before wave 1');
 await desktop.keyboard.press('u');
 if(await desktop.locator('#development').isVisible())throw new Error('U did not close progression');
 // Check the tactical briefing and that it cannot silently spend materials.
 await desktop.keyboard.press('r');
 await desktop.locator('#war-room:not([hidden])').waitFor({timeout:4000});
 if(await desktop.locator('.war-check').count()<3)throw new Error('Readiness checks missing');
 if(await desktop.locator('.war-slots button').count()!==3)throw new Error('Defense slots missing');
 if(await desktop.locator('.war-types button').count()!==3)throw new Error('Defense selection missing');
 await desktop.locator('[data-war-kind="cheeseMortar"]').click();
 await desktop.locator('[data-war-slot="2"]').click();
 await desktop.locator('[data-war="install"]').click();
 if(!((await desktop.locator('.war-slots button').nth(2).innerText()).includes('Сырная')))throw new Error('War room installation failed');
 await desktop.screenshot({path:'smoke-warroom-desktop.png'});
 await desktop.keyboard.press('Escape');
 if(await desktop.locator('#war-room').isVisible())throw new Error('Escape did not close war room');
 if(errors.length)throw new Error('Desktop browser errors: '+errors.join(' | '));
 console.log('Desktop boot and upgrade modal OK:',stats);

 const mobileContext=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:2});
 const mobile=await mobileContext.newPage();
 mobile.on('pageerror',e=>errors.push(e.message));
 mobile.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 const mresp=await mobile.goto(url,{waitUntil:'networkidle',timeout:30000});
 if(!mresp?.ok())throw new Error('Mobile HTTP '+mresp?.status());
 // Diagnose device emulation explicitly rather than reporting a generic locator timeout.
 const touchSignals=await mobile.evaluate(()=>({coarse:matchMedia('(pointer: coarse)').matches,maxTouchPoints:navigator.maxTouchPoints,ontouchstart:'ontouchstart' in window,ua:navigator.userAgent,controls:!!document.querySelector('#mobile-controls'),ready:document.documentElement.dataset.gameReady}));
 console.log('Mobile device capabilities:',touchSignals);
 if(!touchSignals.coarse && touchSignals.maxTouchPoints===0 && !touchSignals.ontouchstart)throw new Error('Playwright touch emulation is not active: '+JSON.stringify(touchSignals));
 try{await mobile.locator('#mobile-controls').waitFor({state:'attached',timeout:10000});}
 catch(e){await mobile.screenshot({path:'smoke-mobile-missing-controls.png',fullPage:true});throw new Error('Mobile controls were not mounted: '+JSON.stringify(touchSignals)+'; '+String(e));}
 await mobile.locator('.mobile-top [data-action="menu"]').waitFor({state:'visible',timeout:10000});
 await mobile.waitForFunction(()=>document.documentElement.dataset.gameReady==='true',null,{timeout:20000});
 if(await mobile.locator('#last-keep-boot-error').count())throw Error('Bootstrap failed on touch device');
 const buttons=mobile.locator('.mobile-top button, .mobile-actions button');
 const overlaps=await mobile.evaluate(()=>{
  const buttons=[...document.querySelectorAll('.mobile-top button, .mobile-actions button')];
  const r=buttons.map(e=>({name:e.textContent?.trim(),box:e.getBoundingClientRect()}));
  const out=[];
  for(let i=0;i<r.length;i++)for(let j=i+1;j<r.length;j++){
   const a=r[i].box,b=r[j].box;
   if(Math.min(a.right,b.right)-Math.max(a.left,b.left)>3&&Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)>3)out.push([r[i].name,r[j].name]);
  }
  return out;
 });
 if(overlaps.length)throw new Error('Touch primary buttons overlap: '+JSON.stringify(overlaps));
 if(await buttons.count()<7)throw new Error('Mobile buttons missing');
 await mobile.locator('#tutorial-guide').waitFor({timeout:4000});
 await mobile.locator('.mobile-top [data-action="menu"]').tap();
 if(await mobile.locator('.mobile-menu [data-action="tutorial"]').count()!==1)throw new Error('Tutorial restart entry missing');
 if(await mobile.locator('.mobile-menu [data-action="sound"]').count()!==1)throw new Error('G9 touch audio toggle missing');
 await mobile.locator('.mobile-menu [data-action="progression"]').tap();
 await mobile.locator('#development:not([hidden])').waitFor({timeout:4000});
 await mobile.screenshot({path:'smoke-mobile-development.png'});
 await mobile.locator('#development .dev-close').tap();
 await mobile.locator('.mobile-top [data-action="menu"]').tap();
 await mobile.locator('.mobile-menu [data-action="briefing"]').tap();
 await mobile.locator('#war-room:not([hidden])').waitFor({timeout:4000});
 await mobile.screenshot({path:'smoke-warroom-mobile.png'});
 // The modal must fit a narrow portrait viewport and scroll internally if taller.
 const warWidth=await mobile.locator('.war-panel').evaluate(e=>({scrollWidth:e.scrollWidth,width:e.clientWidth}));
 if(warWidth.scrollWidth>warWidth.width+2)throw new Error('War room horizontal overflow: '+JSON.stringify(warWidth));
 await mobile.locator('#war-room [data-war="close"]').tap();
 await mobile.screenshot({path:'smoke-mobile.png'});
 if(errors.length)throw new Error('Mobile browser errors: '+errors.join(' | '));
 console.log('Touch controls, no primary-button overlaps, and mobile progression OK');
 await mobileContext.close();
}finally{await browser.close();}
