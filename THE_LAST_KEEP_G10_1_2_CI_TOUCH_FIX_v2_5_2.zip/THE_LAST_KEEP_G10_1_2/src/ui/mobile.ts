/** Touch-first controls. No synthetic mouse clicks or pointer-lock required. */
export type MobileAction = 'fire'|'build'|'remove'|'repair'|'gather'|'jump'|'weapon'|'material'|'shape'|'rotate'|'line'|'wave'|'next'|'research'|'save'|'load'|'menu'|'worker'|'order'|'priority'|'cancel'|'quality'|'architect'|'help'|'fullscreen'|'dig'|'digOrder'|'defense'|'defenseSelect'|'progression'|'briefing'|'sound'|'tutorial';
export function isTouchDevice(){
 // Some headless Chromium/mobile emulations expose touch via maxTouchPoints only.
 // Check all browser touch signals rather than relying on pointer media queries alone.
 return matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0 || ('ontouchstart' in window);
}
export function installMobileControls(onLook:(dx:number,dy:number)=>void,onAction:(action:MobileAction)=>void){
 const root=document.createElement('div');root.id='mobile-controls';
 root.innerHTML=`<div id="touch-look" aria-label="Поворот камеры"></div>
 <div class="mobile-top"><button data-action="menu" aria-expanded="false" aria-controls="mobile-menu">☰ Меню</button><button data-action="fullscreen" aria-label="Полный экран">⛶ Экран</button><button data-action="wave">⚑ Волна</button></div>
 <div class="mobile-joystick" id="mobile-joystick" aria-label="Джойстик движения"><div id="joystick-knob"></div></div>
 <div class="mobile-actions"><button data-action="jump">↑ Прыжок</button><button data-action="fire" class="primary">⚔ Огонь</button><button data-action="build">＋ Строить</button><button data-action="remove">− Снести</button></div>
 <div class="mobile-menu" id="mobile-menu" hidden role="dialog" aria-modal="true" aria-label="Управление крепостью">
 <div class="mobile-menu-head"><strong>Управление крепостью</strong><button data-action="menu">✕ Закрыть</button></div>
 <p class="mobile-menu-tip">На телефоне: левый круг — движение, свайп справа — обзор. Все вторичные действия — здесь.</p>
 <div class="mobile-menu-scroll">
 <section class="mobile-menu-section"><h2>⚔ Бой и оборона</h2><div class="mobile-menu-grid">
 <button data-action="briefing">⚑ Военный совет</button><button data-action="wave">⚔ Начать волну</button>
 <button data-action="weapon">⚔ Сменить оружие</button><button data-action="defenseSelect">🔄 Выбрать орудие</button><button data-action="defense">🛡 Построить орудие</button><button data-action="next">→ Следующая волна</button>
 </div></section>
 <section class="mobile-menu-section"><h2>🏰 Строительство и развитие</h2><div class="mobile-menu-grid">
 <button data-action="architect">🏰 Архитектор</button><button data-action="progression">⚒ Развитие замка</button>
 <button data-action="material">🧱 Материал</button><button data-action="shape">◫ Форма блока</button><button data-action="rotate">↻ Повернуть</button><button data-action="line">━ Линия</button>
 <button data-action="repair">✚ Чинить стену</button><button data-action="gather">⛏ Добыть ресурс</button><button data-action="dig">⛏ Копать ров</button><button data-action="research">✦ Исследования</button>
 </div></section>
 <section class="mobile-menu-section"><h2>👷 Рабочие</h2><div class="mobile-menu-grid">
 <button data-action="worker">👷 Нанять</button><button data-action="order">⚒ Строить по плану</button><button data-action="digOrder">⛏ Поручить копать</button><button data-action="priority">↻ Приоритет</button><button data-action="cancel">× Очистить очередь</button>
 </div></section>
 <section class="mobile-menu-section"><h2>⚙ Настройки</h2><div class="mobile-menu-grid">
 <button data-action="fullscreen">⛶ Полный экран</button><button data-action="quality">⚙ Графика: авто</button><button data-action="sound">🔊 Звук: вкл</button><button data-action="save">💾 Сохранить</button><button data-action="load">📂 Загрузить</button><button data-action="help">? Справка</button><button data-action="tutorial">⚑ Обучение заново</button>
 </div></section>
 </div></div>`;
 document.body.append(root);
 let move={x:0,y:0};let joystickPointer:number|null=null;let lookPointer:number|null=null;let lastX=0,lastY=0;
 const joystick=root.querySelector<HTMLElement>('#mobile-joystick')!,knob=root.querySelector<HTMLElement>('#joystick-knob')!;
 const update=(e:PointerEvent)=>{const r=joystick.getBoundingClientRect();const x=e.clientX-(r.left+r.width/2),y=e.clientY-(r.top+r.height/2);const knobRadius=knob.getBoundingClientRect().width/2;const max=Math.max(8,Math.min(r.width,r.height)/2-knobRadius-3);const len=Math.hypot(x,y)||1;const scale=Math.min(1,max/len);const raw={x:x*scale/max,y:y*scale/max};move=Math.hypot(raw.x,raw.y)<.12?{x:0,y:0}:raw;knob.style.transform=`translate(${raw.x*max}px,${raw.y*max}px)`;};
 joystick.addEventListener('pointerdown',e=>{if(joystickPointer!==null)return;e.preventDefault();joystickPointer=e.pointerId;joystick.setPointerCapture(e.pointerId);update(e);});
 joystick.addEventListener('pointermove',e=>{if(e.pointerId===joystickPointer)update(e);});
 const resetMove=(e:PointerEvent)=>{if(e.pointerId===joystickPointer){joystickPointer=null;move={x:0,y:0};knob.style.transform='translate(0,0)';}};
 joystick.addEventListener('pointerup',resetMove);joystick.addEventListener('pointercancel',resetMove);joystick.addEventListener('lostpointercapture',resetMove);
 const look=root.querySelector<HTMLElement>('#touch-look')!;
 look.addEventListener('pointerdown',e=>{if(lookPointer!==null)return;e.preventDefault();lookPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;look.setPointerCapture(e.pointerId);});
 look.addEventListener('pointermove',e=>{if(e.pointerId!==lookPointer)return;onLook(e.clientX-lastX,e.clientY-lastY);lastX=e.clientX;lastY=e.clientY;});
 const endLook=(e:PointerEvent)=>{if(e.pointerId===lookPointer)lookPointer=null;};
 look.addEventListener('pointerup',endLook);look.addEventListener('pointercancel',endLook);look.addEventListener('lostpointercapture',endLook);
 const held=new Set<MobileAction>();
 const menu=root.querySelector<HTMLElement>('#mobile-menu')!;
 const menuButtons=root.querySelectorAll<HTMLButtonElement>('[data-action=menu]');
 const setMenu=(open:boolean)=>{menu.hidden=!open;root.classList.toggle('menu-open',open);menuButtons.forEach(b=>b.setAttribute('aria-expanded',String(open)));resetAll();if(open){const close=menu.querySelector<HTMLButtonElement>('.mobile-menu-head button');close?.focus({preventScroll:true});}else if(menu.contains(document.activeElement)){(root.querySelector<HTMLButtonElement>('.mobile-top [data-action=menu]'))?.focus({preventScroll:true});}};
 const resetAll=()=>{joystickPointer=null;lookPointer=null;move={x:0,y:0};held.clear();knob.style.transform='translate(0,0)';};
 const onVisibility=()=>{if(document.hidden){resetAll();setMenu(false);}};const onKeyDown=(e:KeyboardEvent)=>{if(e.code==='Escape'&&!menu.hidden){e.preventDefault();setMenu(false);}};window.addEventListener('blur',resetAll);document.addEventListener('visibilitychange',onVisibility);document.addEventListener('keydown',onKeyDown);
 const updateFullscreen=()=>{const full=!!document.fullscreenElement;root.querySelectorAll<HTMLButtonElement>('[data-action=fullscreen]').forEach(b=>{b.textContent=b.closest('.mobile-top')?(full?'⛶ Выход':'⛶ Экран'):(full?'⛶ Выйти из полного экрана':'⛶ Полный экран');b.setAttribute('aria-pressed',String(full));});};document.addEventListener('fullscreenchange',updateFullscreen);updateFullscreen();
 root.querySelectorAll<HTMLButtonElement>('button[data-action]').forEach(button=>{
  const action=button.dataset.action as MobileAction;
  if(action==='fire'||action==='jump'){
   button.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();button.setPointerCapture(e.pointerId);held.add(action);});
   for(const name of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(name,()=>held.delete(action));
  }else button.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(action==='menu')setMenu(menu.hidden);else if(action==='fullscreen'){setMenu(false);onAction(action);}else {if(!menu.hidden)setMenu(false);onAction(action);}});
 });
 const spotlightAction=(action:string)=>{
  const target=root.querySelector<HTMLButtonElement>(`button[data-action="${action}"]`);if(!target)return;
  if(target.closest('.mobile-menu')){setMenu(true);target.scrollIntoView({block:'center',behavior:'smooth'});}
  target.classList.add('tutorial-spotlight');setTimeout(()=>target.classList.remove('tutorial-spotlight'),3500);
 };
 return {root,spotlightAction,getMove:()=>move,isHeld:(a:MobileAction)=>held.has(a),setSoundLabel:(label:string)=>{const button=root.querySelector<HTMLButtonElement>('[data-action=sound]');if(button)button.textContent=`🔊 Звук: ${label}`;},setQualityLabel:(label:string)=>{const button=root.querySelector<HTMLButtonElement>('[data-action=quality]');if(button)button.textContent=`⚙ Графика: ${label}`;},setDefenseLabel:(label:string)=>{const button=root.querySelector<HTMLButtonElement>('[data-action=defense]');if(button)button.textContent=`🛡 Построить: ${label}`;},toggleMenu:()=>setMenu(!menu.hidden),isMenuOpen:()=>!menu.hidden,closeMenu:()=>setMenu(false),destroy:()=>{window.removeEventListener('blur',resetAll);document.removeEventListener('visibilitychange',onVisibility);document.removeEventListener('keydown',onKeyDown);document.removeEventListener('fullscreenchange',updateFullscreen);root.remove();}};
}
