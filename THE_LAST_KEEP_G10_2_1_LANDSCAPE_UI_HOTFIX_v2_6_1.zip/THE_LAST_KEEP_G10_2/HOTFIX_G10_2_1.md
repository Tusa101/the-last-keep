# G10.2.1 — Landscape onboarding overlap hotfix (v2.6.1)

## Failure observed

GitHub Actions v2.6.0 passed build, tests, and mobile layout smoke, then failed the onboarding smoke at **568×320**: `Overlaps at 568x320: #tutorial-guide/.mobile-actions`. The production WebGL smoke did not run because the preceding step failed.

## Root cause

The G10.2 tool selector replaced the old four action buttons with a new vertical action column. The onboarding card in short landscape viewports retained its old right boundary (`150px`), leaving insufficient horizontal separation from the right-hand action column.

## Fix

- Increase tutorial card landscape right exclusion from 150px to 165px. At 568×320 this moves its right edge to x=403, while the action column starts around x=408, creating a gap instead of an overlap.
- Improve onboarding smoke failure diagnostics by reporting element rectangles and intersection area.
- Bump package version to 2.6.1. No gameplay logic, balance, controls, or save data changed.

## Validation

This fix is intentionally minimal. Browser layout must pass in GitHub Actions on the complete 11-size matrix, followed by the production WebGL smoke.
