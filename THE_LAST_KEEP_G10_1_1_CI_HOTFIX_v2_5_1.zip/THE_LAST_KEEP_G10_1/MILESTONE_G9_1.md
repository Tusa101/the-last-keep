# THE LAST KEEP — G9.1 / v2.2 Mobile Quality & UI Regression

## Scope

This milestone fixes interaction/layout risks rather than introducing gameplay systems. The game's battle, crafting, worker, architect, excavation, progression and previous G9 audiovisual functionality remain unchanged.

### Mobile controls and layout

- Desktop overlays that previously obscured the small-screen game area are hidden on touch devices. A dedicated **compact resource/status bar** now shows Nexus health, wave and timer, stone, wood and FPS immediately below the top controls. The bar does not intercept clicks.
- Three persistent top buttons are kept in **their own full-width three-column grid**: Menu, Fullscreen, Wave. They cannot overflow each other when Russian text changes the button width.
- Four combat/build buttons stay in a **two-column bottom-right grid**, distinct from the bottom-left analog stick. CSS uses responsive `clamp()` sizes, `dvh`, and viewport safe-area insets.
- The virtual joystick knob is now clamped to its **actual rendered joystick diameter**, not a fixed travel distance. Added a small dead zone to prevent involuntary walking.
- Secondary actions are organized under four headings: **Combat & Defense**, **Building & Development**, **Workers**, and **Settings**. The menu is a bounded scrolling overlay, not a floating panel over other controls.
- Secondary commands now activate on **click/tap release**, not pointer-down, so starting a scroll gesture on a menu button does **not immediately execute** an action (e.g., starting a wave or clearing a queue). Fire and jump remain press-and-hold.
- Opening the menu clears held movement/fire/look state, preventing "stuck" inputs after modal interaction. The menu closes on Escape, moves focus appropriately, and exposes `aria-modal`.
- Fullscreen controls remain present at the top and in Settings. Their labels change on `fullscreenchange` to show exit/enter state. `index.html` includes iOS home-screen standalone metadata as a fallback for browser restrictions.
- On touch devices HUD DOM refreshes about every 180 ms instead of every 100 ms, reducing unnecessary layout/DOM work during a siege.

### Responsive test evidence

The actual **Chromium browser engine** was used with the real `src/ui/style.css` and browser-executed `src/ui/mobile.ts` (transpiled in isolation). The entire game was **not loaded** in these tests.

Checked 11 viewport sizes: 280×653, 320×568, 360×640, 390×844, 430×932, 568×320, 667×375, 740×360, 844×390, 932×430, 1024×600.

For each size:

1. No overlap between top buttons, four gameplay buttons, joystick and status strip.
2. No persistent interactive control outside the viewport.
3. Menu opens, is vertically scrollable, and bottom-of-menu Save command can be tapped and closes the menu.
4. No uncaught errors in this UI-only fixture.

Result: **11 / 11 passed**. Screenshot evidence: `qa/mobile-portrait-controls.png`, `qa/mobile-portrait-menu.png`, `qa/mobile-landscape-controls.png`, `qa/mobile-landscape-menu.png`. These images show the **UI fixture**, not a screenshot of the playable 3D game.

Also verified in Chromium that holding Fire then opening the menu clears the hold state.

### Automated CI

`npm run smoke:ui` executes the standalone browser UI smoke test (`scripts/mobile-layout-smoke.mjs`) in Chromium. This runs as part of the existing GitHub Pages workflow before the game's WebGL smoke test, after dependencies and the Chromium binary are installed.

### Known gaps — not approved as a fully tested mobile release

- Full application Vite build still requires npm dependencies and has not been run locally here (`npm registry: EAI_AGAIN`).
- The full WebGL gameplay has **not been playtested** in Android Chrome or iPhone Safari.
- Responsive verification only covers CSS/browser-emulated touch viewports; physical touch precision, keyboard overlay, browser address bar transitions, and sustained FPS still require device testing.
- Fullscreen API availability depends on browser and installed-app context, especially in iOS Safari.
- Gameplay rebalance and tutorial onboarding are reserved for G9.2.

## Mobile playtest priority

Open latest GitHub Pages deployment on a phone. Try portrait, landscape, Menu, scrolling to Save, going full screen if supported, building, turning camera and running while holding Fire. Take a screenshot with the full phone viewport if any control still overlaps. Also check the War Room, Architect and Development overlays.
