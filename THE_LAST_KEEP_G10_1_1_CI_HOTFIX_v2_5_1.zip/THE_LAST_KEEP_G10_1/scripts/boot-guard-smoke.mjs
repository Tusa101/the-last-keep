/* UI contract for the independent bootstrap error handler.
 * Does not require Three.js or Vite, and works even when the game bundle fails.
 */
import {chromium} from 'playwright';
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const src=readFileSync(new URL('../public/boot-guard.js',import.meta.url),'utf8');
const browser=await chromium.launch({headless:true});
const cases=['success','javascript-error','missing-script','rejection','context-lost','timeout'];
try{
 for(const testCase of cases){
  const page=await browser.newPage({viewport:{width:390,height:844},hasTouch:true});
  await page.setContent('<!doctype html><html lang="ru"><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><main>Игра</main></body></html>');
  if(testCase==='timeout')await page.clock.install();
  await page.addScriptTag({content:src});
  if(testCase==='success'){
   await page.evaluate(()=>window.dispatchEvent(new Event('lastkeep:ready')));
   assert.equal(await page.locator('#last-keep-boot-error').count(),0);
   assert.equal(await page.evaluate(()=>document.documentElement.dataset.gameReady),'true');
   assert.equal(await page.evaluate(()=>window.__lastKeepBootGuard.isReady()),true);
  }else{
   if(testCase==='javascript-error')await page.evaluate(()=>window.dispatchEvent(new ErrorEvent('error',{message:'broken 3D module'})));
   if(testCase==='missing-script')await page.evaluate(()=>{const s=document.createElement('script');document.head.appendChild(s);s.dispatchEvent(new Event('error'));});
   if(testCase==='rejection')await page.evaluate(()=>window.dispatchEvent(new PromiseRejectionEvent('unhandledrejection',{promise:Promise.resolve(),reason:new Error('renderer rejected')})));
   if(testCase==='context-lost')await page.evaluate(()=>window.dispatchEvent(new Event('lastkeep:contextlost')));
   if(testCase==='timeout'){
    // The guard installs its timeout after DOM ready: advancing the virtual
    // clock must not require waiting 25 real seconds in CI.
    await page.clock.fastForward(26000);
   }
   const panel=page.locator('#last-keep-boot-error');
   await panel.waitFor({timeout:3000});
   assert.equal(await page.locator('[data-boot="reload"]').isVisible(),true);
   assert.equal(await page.locator('[data-boot="copy"]').isVisible(),true);
   const rect=await panel.locator('.last-keep-error-card').boundingBox();
   assert(rect && rect.x>=0 && rect.x+rect.width<=391,'Bootstrap error card must fit phone width');
   assert.equal(await page.evaluate(()=>window.__lastKeepBootGuard.isFailed()),true);
   const diagnostic=JSON.parse(await page.evaluate(()=>window.__lastKeepBootGuard.diagnostics()));
   assert(diagnostic.errors.length>0,'Diagnostic should contain actual error');
   // No broken module should hide the recovery buttons; they must remain clickable.
   await panel.locator('details summary').click();
   assert.equal(await panel.locator('pre').isVisible(),true);
  }
  console.log('PASS boot guard:',testCase);
  await page.close();
 }
}finally{await browser.close();}
