/* Small offline verifier for GitHub Pages output, after 'npm run build'.
 * Prevents uploading an empty/wrong-path release even if the dev preview works. */
import {existsSync,readFileSync,readdirSync,statSync} from 'node:fs';
import {join} from 'node:path';
import assert from 'node:assert/strict';
const dist=process.argv[2]||'dist';
const html=readFileSync(join(dist,'index.html'),'utf8');
const receipt=JSON.parse(readFileSync(join(dist,'release.json'),'utf8'));
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const [owner,repo]=(process.env.GITHUB_REPOSITORY||'').split('/');
const base=repo?(repo.toLowerCase()===`${owner.toLowerCase()}.github.io`?'/':`/${repo}/`):'./';
assert.equal(receipt.version,pkg.version);
assert.match(html,/<canvas|<script|<link/i);
assert(existsSync(join(dist,'boot-guard.js')),'Missing error-recovery guard in built assets');
assert(html.includes('boot-guard.js'),'Production HTML does not load error handler');
assert(html.includes('assets/'),'Missing Vite bundles');
const entries=readdirSync(join(dist,'assets'));
assert(entries.some(name=>name.endsWith('.js')),'Missing JS entry chunk');
assert(entries.some(name=>name.endsWith('.css')),'Missing CSS bundle');
const src=[...html.matchAll(/(?:src|href)="([^\"]+)"/g)].map(x=>x[1]);
for(const ref of src){
 if(ref.startsWith('https:')||ref.startsWith('data:')||ref.startsWith('#'))continue;
 // Relative links are safe under a Pages subpath; absolute links must use configured base.
 assert(!ref.startsWith('/')||ref.startsWith(base),`Asset ${ref} would break on Pages base ${base}`);
}
let size=0;for(const name of entries)size+=statSync(join(dist,'assets',name)).size;
assert(size>20000,`Bundles suspiciously small: ${size} bytes`);
console.log(`PASS dist verification: ${pkg.version}, base ${base}, ${entries.length} bundle assets, ${Math.round(size/1024)} KiB`);
