/** Real Chromium responsive/control smoke WITHOUT Three.js or a running Vite server.
 * Runs after `npm install` (TypeScript + Playwright are declared devDependencies).
 * Verify content scrolls/taps correctly even on a small landscape phone.
 */
import fs from 'node:fs';
import ts from 'typescript';
import {chromium} from 'playwright';

const css=fs.readFileSync(new URL('../src/ui/style.css',import.meta.url),'utf8');
const source=fs.readFileSync(new URL('../src/ui/mobile.ts',import.meta.url),'utf8');
const js=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/^export /gm,'');
const sizes=[[280,653],[320,568],[360,640],[390,844],[430,932],[568,320],[667,375],[740,360],[844,390],[932,430]];
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
try {
 for(const [w,h] of sizes){
  const context=await browser.newContext({viewport:{width:w,height:h},hasTouch:true,isMobile:true,deviceScaleFactor:1});
  try {
   const page=await context.newPage();
   const errors=[];page.on('pageerror',e=>errors.push(String(e)));
   await page.setContent(`<!doctype html><html lang="ru"><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>${css}</style></head><body class="touch-mode"><div id="hud"><div class="mobile-status"><span class="mobile-stat danger">◈ 90/100</span><span class="mobile-stat">⚑ 2/3 · 1:40</span><span class="mobile-stat">🪨 14</span><span class="mobile-stat">🪵 25</span><span class="mobile-stat small">60 FPS</span></div></div></body></html>`);
   await page.addScriptTag({content:js+'\nwindow.mobileCalls=[];window.mobileInstance=installMobileControls(()=>{},action=>window.mobileCalls.push(action));'});
   const layout=await page.evaluate(()=>{
    const elements=[...document.querySelectorAll('.mobile-top button,.mobile-actions button,.mobile-joystick,.mobile-status')];
    const boxes=elements.map(e=>{const b=e.getBoundingClientRect();return {text:e.textContent?.trim()||e.className,x:b.left,y:b.top,r:b.right,b:b.bottom};});
    const clashes=[];
    for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){
     const a=boxes[i],b=boxes[j];const dx=Math.max(0,Math.min(a.r,b.r)-Math.max(a.x,b.x));const dy=Math.max(0,Math.min(a.b,b.b)-Math.max(a.y,b.y));
     if(dx*dy>12)clashes.push(`${a.text} / ${b.text}`);
    }
    const offscreen=boxes.filter(b=>b.x<-.5||b.y<-.5||b.r>innerWidth+.5||b.b>innerHeight+.5).map(b=>b.text);
    return {clashes,offscreen,scrollWidth:document.documentElement.scrollWidth,width:innerWidth};
   });
   if(layout.clashes.length||layout.offscreen.length||layout.scrollWidth>layout.width+2)
    throw new Error(`${w}x${h} controls geometry: ${JSON.stringify(layout)}`);
   await page.locator('.mobile-top [data-action=menu]').tap();
   if(await page.locator('#mobile-menu').isHidden())throw new Error('menu did not open');
   const scroll=await page.locator('.mobile-menu-scroll').evaluate(e=>({height:e.clientHeight,scrollHeight:e.scrollHeight}));
   if(scroll.height<60||scroll.scrollHeight<=scroll.height)throw new Error(`${w}x${h} menu scroll surface is broken ${JSON.stringify(scroll)}`);
   await page.locator('.mobile-menu [data-action=save]').tap();
   if(!(await page.locator('#mobile-menu').isHidden()))throw new Error('menu did not close on save');
   const calls=await page.evaluate(()=>window.mobileCalls);
   if(!calls.includes('save'))throw new Error('Save command did not fire');
   // Check Fire press is released on menu opening (no stuck weapon on resumed touch).
   const fire=await page.locator('.mobile-actions [data-action=fire]').boundingBox();
   await page.mouse.move(fire.x+fire.width/2,fire.y+fire.height/2);
   await page.mouse.down();
   if(!(await page.evaluate(()=>window.mobileInstance.isHeld('fire'))))throw new Error('Hold-to-fire did not activate');
   await page.locator('.mobile-top [data-action=menu]').tap();
   const isFiring=await page.evaluate(()=>window.mobileInstance.isHeld('fire'));
   if(isFiring)throw new Error('Fire is stuck after opening menu');
   await page.mouse.up();
   await page.keyboard.press('Escape');
   if(!(await page.locator('#mobile-menu').isHidden()))throw new Error('Escape did not close menu');
   if(errors.length)throw new Error(`JavaScript errors: ${errors.join(' / ')}`);
   console.log(`PASS ${w}×${h} – safe layout, scroll, tap, hold release, escape`);
  }finally{await context.close();}
 }
}finally{await browser.close();}
