/** CI-only end-to-end regression on the BUILT production app, with real WebGL.
 * Generates a valid three-wave save via the same game model used by the app,
 * loads it through the UI, checks the result card and restarts a new run. */
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {seedCastle} from '../src/world/preset.ts';
import {Excavation} from '../src/world/excavation.ts';
import {Siege} from '../src/game/siege.ts';
import {Gathering} from '../src/game/gathering.ts';
import {Defenses} from '../src/game/defenses.ts';
import {Workers} from '../src/game/workers.ts';
import {CampaignJournal} from '../src/game/campaign.ts';
const url=process.env.SMOKE_URL||'http://127.0.0.1:4173/';
const world=new World();seedCastle(world);
const excavation=new Excavation(world),siege=new Siege(world,excavation),gathering=new Gathering(world),defenses=new Defenses(world),workers=new Workers(world,gathering,excavation),campaign=new CampaignJournal();
for(let wave=1;wave<=3;wave++){
 assert.equal(siege.startEarly(),true);
 siege.raiders.forEach(e=>e.alive=false);siege.kills=siege.raiders.length;
 siege.step(1/60);assert.equal(campaign.record(siege,world,defenses),true);
 if(wave<3)assert.equal(siege.next(),true);
}
assert.equal(siege.phase,'VICTORY');
const stored=JSON.stringify({version:5,campaign:campaign.snapshot(),world:world.serialize(),siege:siege.snapshot(),
 gathering:gathering.snapshot(),workers:workers.snapshot(),excavation:excavation.snapshot(),
 defenses:defenses.snapshot(),player:{x:-5,y:0,z:4,vy:0,grounded:true},yaw:1.3,pitch:-.12,weapon:'bolt'});
const browser=await chromium.launch({headless:true,args:['--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 for(const mode of ['desktop','mobile']){
  const ctx=await browser.newContext(mode==='desktop'?{viewport:{width:1280,height:800}}:{viewport:{width:390,height:844},hasTouch:true,isMobile:true});
  const page=await ctx.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(({key,value})=>{localStorage.setItem(key,value);localStorage.setItem('the-last-keep-tutorial-v1',JSON.stringify({version:1,step:8,visible:false}));},
   {key:'the-last-keep-g31-save',value:stored});
  const response=await page.goto(url,{waitUntil:'networkidle',timeout:45000});
  if(!response?.ok())throw Error(`${mode}: HTTP ${response?.status()}`);
  // The hidden tactical minimap is inserted before the WebGL canvas in the DOM.
  // Wait specifically for the rendered game surface, not the first <canvas>.
  await page.locator('#game-canvas:visible').waitFor({timeout:15000});
  await page.waitForFunction(()=>document.documentElement.dataset.gameReady==='true',null,{timeout:20000});
  assert.equal(await page.locator('#last-keep-boot-error').count(),0,'Game must not be in recovery mode');
  if(mode==='desktop')await page.keyboard.press('l');
  else{
   await page.locator('.mobile-top [data-action="menu"]').tap();
   await page.locator('.mobile-menu [data-action="load"]').tap();
  }
  await page.locator('.campaign-scorecard').waitFor({timeout:8000});
  assert.equal(await page.locator('.campaign-row').count(),3,`${mode}: 3 wave results`);
  assert.match(await page.locator('.campaign-total').innerText(),/ЛЕГЕНДА КРЕПОСТИ/);
  assert.match(await page.locator('#hud .centerpanel h1').innerText(),/ПОБЕДА/);
  const button=page.locator('.report-action[data-report-action="restart"]');
  assert.equal(await button.isVisible(),true);
  const stableButton=await button.elementHandle();
  await page.waitForTimeout(400);
  assert.equal(await stableButton.evaluate(element=>element.isConnected),true,`${mode}: report CTA was replaced during tap`);
  await page.screenshot({path:`slice-${mode}-victory.png`});
  await button.click();
  await page.waitForTimeout(450);
  assert.equal(await page.locator('.campaign-scorecard').count(),0,`${mode}: restart clears scorecard`);
  assert.equal(await page.locator('.mobile-status').innerText().then(v=>v.includes('0/3')),true,`${mode}: restart resets wave`);
  if(errors.length)throw Error(`${mode}: ${errors.join(' | ')}`);
  console.log(`PASS ${mode} production save → 3-wave report → restart`);
  await ctx.close();
 }
}finally{await browser.close();}
