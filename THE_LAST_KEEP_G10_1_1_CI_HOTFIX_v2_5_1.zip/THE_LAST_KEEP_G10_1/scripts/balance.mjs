/** Deterministic integration-playtest of the actual game simulation, without WebGL.
 * Run via `npm run check:balance`. These are regression guardrails, not human fun metrics. */
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {seedCastle} from '../src/world/preset.ts';
import {Excavation} from '../src/world/excavation.ts';
import {Siege} from '../src/game/siege.ts';
import {Defenses} from '../src/game/defenses.ts';
import {CampaignJournal} from '../src/game/campaign.ts';

export function simulate(loadout){
 const world=new World();seedCastle(world);
 const excavation=new Excavation(world),siege=new Siege(world,excavation),defenses=new Defenses(world),campaign=new CampaignJournal();
 for(const [slot,kind] of loadout.entries())assert.equal(defenses.install(slot,kind,'PREP'),true,`Can't afford ${kind}`);
 const report=[];
 for(let wave=1;wave<=3;wave++){
  assert.equal(siege.startEarly(),true);
  let ticks=0;
  while(siege.phase==='SIEGE'&&ticks<91*60){
   siege.step(1/60);
   defenses.step(1/60,siege.phase,siege.raiders,siege.events,()=>{siege.kills++;});
   siege.events.length=0;defenses.events.length=0;ticks++;
  }
  assert.notEqual(siege.phase,'SIEGE','Siege did not terminate by its time limit');
  assert.equal(campaign.record(siege,world,defenses),true);
  report.push({wave,phase:siege.phase,seconds:Math.round(ticks/60),nexus:siege.nexus,
   kills:siege.lastReport.kills,score:campaign.records.at(-1).score});
  if(siege.phase==='DEFEAT')break;
  if(wave<3)assert.equal(siege.next(),true);
 }
 return {loadout,report,rating:campaign.rating(),totalScore:campaign.totalScore()};
}
if(process.argv[1]?.endsWith('balance.mjs')){
 const results=[[],['carrotTower'],['carrotTower','cheeseMortar'],['carrotTower','cheeseMortar','syrupSprayer']].map(simulate);
 assert.equal(results[0].report.at(-1).phase,'DEFEAT','Unprotected castle should eventually fall');
 assert.equal(results[2].report.at(-1).phase,'VICTORY','Two complementary emplacements should win');
 assert.equal(results[3].report.at(-1).phase,'VICTORY','Three defense types should win');
 console.log(JSON.stringify({game:'THE LAST KEEP',test:'G10 deterministic full three-wave simulation',results},null,2));
}
