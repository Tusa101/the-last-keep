/* Emit a human-checkable version receipt next to the deployed game's index.html.
 * Accessible at /<repo>/release.json on GitHub Pages, with no secrets. */
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
const folder=process.argv[2] || 'dist';
if(!existsSync(join(folder,'index.html')))throw new Error(`Missing ${folder}/index.html (build first)`);
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const receipt={
 game:'THE LAST KEEP',version:pkg.version,milestone:'G10.1',status:'RELEASE CANDIDATE — device QA pending',
 archive:process.env.RELEASE_ARCHIVE||'local-build',
 gitCommit:process.env.GITHUB_SHA||'local',
 builtAt:new Date().toISOString(),
};
writeFileSync(join(folder,'release.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(`Build receipt: ${folder}/release.json → ${receipt.version}`);
