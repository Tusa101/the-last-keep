/* Production WebGL mobile geometry + touch regression matrix.
 * Runs against the actual Vite preview. Headless Chromium emulates size and
 * touch only; it does NOT certify real Android/iOS FPS or browser fullscreen. */
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const url=process.env.SMOKE_URL||'http://127.0.0.1:4173/';
const sizes=[[320,568],[360,640],[390,844],[430,932],[568,320],[667,375],[844,390]];
const browser=await chromium.launch({headless:true,args:['--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
let failures=0;
try{
 for(const [width,height] of sizes){
  const context=await browser.newContext({viewport:{width,height},isMobile:true,hasTouch:true,deviceScaleFactor:1});
  const page=await context.newPage();
  const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  try{
   const response=await page.goto(url,{waitUntil:'domcontentloaded',timeout:40000});
   assert(response?.ok(),`HTTP ${response?.status()}`);
   await page.waitForFunction(()=>document.documentElement.dataset.gameReady==='true',null,{timeout:25000});
   await page.locator('#mobile-controls').waitFor({timeout:4000});
   assert.equal(await page.locator('#last-keep-boot-error').count(),0);
   const overlaps=await page.evaluate(()=>{
    const nodes=[...document.querySelectorAll('.mobile-top button,.mobile-actions button')];
    const boxes=nodes.filter(e=>e.getClientRects().length).map(e=>({name:e.textContent.trim(),box:e.getBoundingClientRect()}));
    const bad=[];
    for(let i=0;i<boxes.length;i++){
     const a=boxes[i].box;
     if(a.left < -1 || a.right > innerWidth+1 || a.top < -1 || a.bottom > innerHeight+1)bad.push(`${boxes[i].name}: out of viewport`);
     for(let j=0;j<i;j++){
      const b=boxes[j].box;
      if(Math.min(a.right,b.right)-Math.max(a.left,b.left)>3&&Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)>3)
       bad.push(`${boxes[i].name} overlaps ${boxes[j].name}`);
     }
    }
    return bad;
   });
   assert.deepEqual(overlaps,[],`Touch controls (${width}x${height})`);
   const menu=page.locator('.mobile-top [data-action="menu"]');
   await menu.tap();
   assert.equal(await page.locator('#mobile-menu').isVisible(),true);
   await page.locator('.mobile-menu-head [data-action="menu"]').tap();
   assert.equal(await page.locator('#mobile-menu').isVisible(),false);
   // Use a real touch action, not synthetic JS 'click', to exercise controls.
   await page.locator('.mobile-actions [data-action="jump"]').tap();
   await page.locator('.mobile-actions [data-action="fire"]').tap();
   await page.waitForTimeout(180);
   assert.deepEqual(errors,[],`JS runtime errors ${width}x${height}`);
   await page.screenshot({path:`smoke-device-${width}x${height}.png`});
   console.log(`PASS real-WebGL browser touch ${width}x${height}`);
  }catch(error){
   failures++;
   await page.screenshot({path:`smoke-device-FAIL-${width}x${height}.png`}).catch(()=>{});
   console.error(`FAIL ${width}x${height}: ${error?.message||error}`);
  }finally{await context.close();}
 }
}finally{await browser.close();}
if(failures)process.exitCode=1;
