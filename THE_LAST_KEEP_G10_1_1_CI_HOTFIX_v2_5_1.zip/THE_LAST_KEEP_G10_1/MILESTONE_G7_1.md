# G7.1 — Absurd Defenses (v1.8)

Three **fixed, physical emplacements** can be built during PREP/RESULT. Desktop `V` or mobile menu `🛡 Оборонительное орудие` installs the next available emplacement in this order:

1. Carrot turret at (-11,-6): costs 9 wood / 3 stone, 8-cell range, 19 single-target damage every 1.25 seconds.
2. Cheese mortar at (-11,6): costs 6 wood / 12 stone, 7-cell range, 32 area damage in a 2.2-cell radius every 3.2 seconds.
3. Syrup sprayer at (1,-11): costs 12 wood / 4 stone, 4-cell range, 1.1-second stun every 2.4 seconds, no damage.

Defenses are disabled outside SIEGE, require sufficient stockpile resources, and cannot be built on obstructed ground. Kills count toward siege research rewards. Save payload includes defenses and loads older saves without them. Three stylized 3D emplacements are visible in the world.

**Known limitations:** Fixed positions rather than free placement; no targeting UI, upgrade tree, projectile arcs or chicken tower yet. Mobile positioning remains unverified on a physical device. Full Vite build/browser smoke not verified locally without npm dependencies.

**QA:** `npm test`; `npm run typecheck:core`; GitHub Actions performs full build and browser smoke when configured.
