/* THE LAST KEEP bootstrap watchdog. Dependency-free and executed before Vite's module.
 * This is intentionally a static JS asset so syntax errors in the game bundle are
 * still visible to players. It never touches saved game state.
 */
(() => {
  'use strict';
  const startedAt = Date.now();
  const errors = [];
  const MAX_ERRORS = 6;
  const TIMEOUT_MS = 25000;
  const MAX_MESSAGE = 420;
  let ready = false;
  let failed = false;
  let timeoutId = 0;

  function scrub(message) {
    return String(message || 'Неизвестная ошибка').replace(/https?:\/\/[^\s)]+/g, '<url>').slice(0, MAX_MESSAGE);
  }
  function record(category, message) {
    if (errors.length < MAX_ERRORS) errors.push(`${category}: ${scrub(message)}`);
    if (!ready) showFailure('Игра не смогла запуститься.');
    else showFailure('Во время игры произошла ошибка.');
  }
  function report() {
    const info = {
      game: 'THE LAST KEEP', release: 'v2.5 RC',
      url: `${location.origin}${location.pathname}`,
      online: navigator.onLine,
      language: navigator.language,
      screen: `${innerWidth}x${innerHeight}`,
      ready,
      elapsedSeconds: Math.round((Date.now() - startedAt) / 1000),
      errors: errors.slice(0, MAX_ERRORS),
    };
    return JSON.stringify(info, null, 2);
  }
  function showFailure(heading) {
    if (failed) return;
    failed = true;
    clearTimeout(timeoutId);
    const panel = document.createElement('section');
    panel.id = 'last-keep-boot-error';
    panel.setAttribute('role', 'alertdialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-labelledby', 'last-keep-error-title');
    panel.innerHTML = `
      <div class="last-keep-error-card">
        <span class="last-keep-error-mark">⚠ THE LAST KEEP</span>
        <h1 id="last-keep-error-title"></h1>
        <p>Нажми «Перезапустить». Если проблема повторяется, скопируй диагностику и пришли её разработчику. Сохранение при перезапуске не удаляется.</p>
        <div class="last-keep-error-actions">
          <button type="button" data-boot="reload">↻ Перезапустить</button>
          <button type="button" data-boot="copy">⎘ Скопировать диагностику</button>
        </div>
        <p class="last-keep-copy-status" aria-live="polite"></p>
        <details><summary>Технические сведения</summary><pre></pre></details>
      </div>`;
    const style = document.createElement('style');
    style.textContent = `
      #last-keep-boot-error{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;overflow:auto;padding:calc(14px + env(safe-area-inset-top)) calc(14px + env(safe-area-inset-right)) calc(14px + env(safe-area-inset-bottom)) calc(14px + env(safe-area-inset-left));background:rgba(13,25,22,.96);color:#f5e6c7;font:15px/1.5 system-ui,sans-serif;box-sizing:border-box;touch-action:pan-y}
      #last-keep-boot-error *{box-sizing:border-box}
      .last-keep-error-card{max-width:560px;width:100%;max-height:100%;overflow:auto;padding:clamp(16px,4vw,28px);border:2px solid #d6a76e;border-radius:12px;background:#263b30;box-shadow:0 12px 48px #0009}
      .last-keep-error-mark{color:#f5d39d;font-size:12px;font-weight:800;letter-spacing:1.4px}
      .last-keep-error-card h1{font:bold clamp(20px,6vw,29px)/1.15 Georgia,serif;color:#ffe3a7;margin:12px 0}
      .last-keep-error-card p{font-size:13px}
      .last-keep-error-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:18px}
      .last-keep-error-actions button{min-height:48px;flex:1 1 180px;background:#49634b;border:1px solid #e6c38d;border-radius:9px;color:#fff2d9;padding:11px;font:700 14px system-ui,sans-serif;cursor:pointer}
      .last-keep-error-card details{margin-top:12px;color:#e5dbbf;font-size:12px}
      .last-keep-error-card pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:180px;overflow:auto;background:#14241c;padding:10px;border-radius:6px;color:#bde8d0;font-size:11px}
      .last-keep-copy-status{min-height:18px;color:#e5d7a8}`;
    document.head.appendChild(style);
    (document.body || document.documentElement).appendChild(panel);
    panel.querySelector('h1').textContent = heading;
    panel.querySelector('pre').textContent = report();
    panel.querySelector('[data-boot="reload"]').addEventListener('click', () => location.reload());
    panel.querySelector('[data-boot="copy"]').addEventListener('click', async () => {
      const label = panel.querySelector('.last-keep-copy-status');
      try {
        if (!navigator.clipboard?.writeText) throw new Error('clipboard unavailable');
        await navigator.clipboard.writeText(report());
        label.textContent = 'Диагностика скопирована.';
      } catch {
        label.textContent = 'Копирование недоступно. Раскрой технические сведения и скопируй их вручную.';
        panel.querySelector('details').open = true;
      }
    });
  }
  function onReady() {
    if (failed) return;
    ready = true;
    clearTimeout(timeoutId);
    document.documentElement.dataset.gameReady = 'true';
  }
  window.addEventListener('lastkeep:ready', onReady, {once:true});
  window.addEventListener('error', event => {
    // Only global errors (including module loading failures), not images/fonts.
    if (event instanceof ErrorEvent) record('error', event.message || event.error?.message);
    else if (event.target instanceof HTMLScriptElement) record('script', `Не загрузился ${event.target.src}`);
  }, true);
  window.addEventListener('unhandledrejection', event => record('promise', event.reason?.message || event.reason));
  window.addEventListener('lastkeep:contextlost', () => record('webgl', 'Видеоконтекст потерян. Перезапусти игру.'), {once:true});
  const startWatchdog = () => { timeoutId = setTimeout(() => {
    if (!ready) record('timeout', `Нет первого кадра через ${TIMEOUT_MS/1000} секунд`);
  }, TIMEOUT_MS); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startWatchdog, {once:true});
  else startWatchdog();
  window.__lastKeepBootGuard = Object.freeze({diagnostics: report, isReady: () => ready, isFailed: () => failed});
})();
