# Validation report — THE LAST KEEP G8.1 (v2.0)

## Verified locally
- `npm test`: 130 passes, 0 fails (test runner Node.js 22.16.0).
- `npm run typecheck:core`: passes with global TypeScript compiler.
- `node --check scripts/smoke.mjs`: JavaScript syntax valid.
- ZIP CRC and GitHub selector extraction: recorded in release checks.

## Unverified
- Full TypeScript/Vite compile: `npm view three@0.180.0 ...` was blocked by npm registry DNS `EAI_AGAIN`.
- Playwright browser test: browser packages and Vite runtime not installed here.
- Any physical Android/iOS performance or touch input checks.

## Browser test cases, once on GitHub Actions
1. Load in WebGL-enabled desktop Chromium; no exceptions.
2. `U` shows the progression modal and closes it.
3. `R` shows War Room with readiness checks, all 3 real slots and 3 choices; install cheese mortar at slot #3; confirm material spending and slot assignment.
4. `Escape` exits briefing.
5. On touch 390×844, no principal mobile buttons overlap; menu opens progression and briefing. War Room content fits horizontally, scrolls vertically and closes via a touch button.
6. On device, inspect safe-area notches/ browser fullscreen and validate landscape separately (browser smoke currently checks portrait only).

## Known limitations
- Readiness score is advisory and cannot predict outcomes under physics/collision/navigation variations.
- Only 3 predefined turret sites; no fully free defense placement or relocatable machines.
- No recording or simulation harness for whole-run economic tuning yet. Existing three-wave content is unchanged.
