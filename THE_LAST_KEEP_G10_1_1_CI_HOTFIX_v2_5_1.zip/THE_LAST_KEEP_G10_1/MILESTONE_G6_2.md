# G6.2 — Shallow Excavation (v1.5)

Implemented: deterministic 1–3 depth earthworks, immutable depth limit justified by ancient foundation, small stone returns, protected central areas, visual earth cells, mobile menu Dig action, Z key, save migration, optional terrain-cost hook in A*.

**Known limits (important):** Earthworks are currently tactical terrain markers with recessed-looking visual tiles, **not actual mesh subtraction or player physics**. Enemy and worker routing do not yet pass the excavation object to A*, so trenches do **not yet slow active enemies**. Workers cannot excavate automatically. No underground deposits or true subterranean strata. These features require integrating terrain height into physics and all agent route planners.

Run `npm test` and `npm run build` in CI before deployment. Browser/mobile playtest required.
