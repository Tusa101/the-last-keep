# G9.1 validation report — v2.2

| Check | Result |
|---|---|
| Node unit tests | **138 passed / 0 failed** (`npm test`) |
| Game core TypeScript | PASS (`npm run typecheck:core`) |
| Standalone `mobile.ts` TypeScript | PASS (`tsc --strict --lib ES2022,DOM`) |
| Actual Chromium UI layout across 11 screen sizes | **11/11 passed** with no persistent-control clashes or elements outside viewport |
| Scroll menu, tap Save, close menu | 11/11 passed |
| JavaScript page errors in UI-only browser fixture | 0 reported |
| Held Fire reset on menu opening | PASS in Chromium UI fixture |
| `scripts/mobile-layout-smoke.mjs` syntax | PASS (`node --check`) |
| Full TypeScript app compilation | **Not confirmed**: missing Three.js dependency/declarations; `npm install` unavailable (`EAI_AGAIN`) |
| Vite production build | **Not run** |
| Full-game WebGL browser smoke | **Not run** |
| GitHub Actions CI execution | **Not run in this environment** |
| Physical Android / iOS | **Not tested** |

UI regression harness uses Chromium with the real mobile controls module transpiled by global TypeScript and CSS, but does NOT instantiate the full 3D world. Screenshot evidence is stored in `qa/`.

**Deployment:** Put this `*_v2_2.zip` archive into the repository root beside the existing Pages starter files. The pipeline's `scripts/select_latest.py` will select v2.2 over v2.1. Deploy only when CI tests and Vite build succeed.
