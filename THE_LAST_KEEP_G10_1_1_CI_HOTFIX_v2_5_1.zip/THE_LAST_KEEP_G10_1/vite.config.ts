import {defineConfig} from 'vite';
/** Project Pages lives at /repo/. A repository named OWNER.github.io is
 * a user/org site at /, and local preview builds use relative asset paths. */
const [owner,repo]=(process.env.GITHUB_REPOSITORY??'').split('/');
const base=repo?(repo.toLowerCase()===`${owner.toLowerCase()}.github.io`?'/':`/${repo}/`):'./';
export default defineConfig({base});
