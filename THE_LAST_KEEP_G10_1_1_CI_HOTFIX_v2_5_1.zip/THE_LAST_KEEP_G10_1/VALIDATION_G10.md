# G10 Validation Record — THE LAST KEEP v2.4

## Automated tests

| Test / check | Result | Meaning |
|---|---|---|
| `npm test` | **PASS: 152/152** | Core, AI, terrain, workers, battle, defenses, scorecard and save tests. |
| `npm run typecheck:core` | **PASS** | Type checks offline engine (does not cover renderer). |
| `npm run check:balance` | **PASS** | Real deterministic simulation across three assaults for 4 defense loadouts. |
| Chromium CSS-only result UI, 7 viewport sizes | **PASS** | Victory panel and CTA accessible, correct z-index and scrolling. |
| ZIP integrity / latest-archive selector | **PASS** | 122 source files; CRC valid; v2_4 chosen over v2_3; extraction contains Vite project and CI files. |
| `npm run build` | **NOT RUN / BLOCKED** | `three`/`vite` absent; npm registry DNS `EAI_AGAIN`. |
| Production WebGL smoke / vertical-slice E2E | **NOT RUN / BLOCKED** | Requires build, Playwright and online npm install. Workflow is prepared. |
| Physical Android / iOS | **NOT RUN** | Needs user device. |

## Deterministic progression baseline (no player shots or new construction)

The following is a *balance regression fixture*, not a measurement of fun, difficulty for a human player, or phone FPS:

| Defense loadout (installed at fixed slots before wave 1) | W1 result | W2 result | W3 result | Outcome |
|---|---|---|---|---|
| None | 70 Nexus HP, 2 kills | Defeat, 2 kills | — | Defeat wave 2 |
| Carrot turret | 100 HP, 4 kills | 85 HP, 6 kills | Defeat | Defeat wave 3 |
| Carrot turret + cheese mortar | 100 HP, 4 kills | 100 HP, 7 kills | Victory, 15 HP, 5 kills | Victory |
| Carrot turret + cheese mortar + syrup sprayer | 100 HP, 4 kills | 100 HP, 7 kills | Victory, 30 HP, 6 kills | Victory |

These runs use existing starting material budgets and all actual enemy pathfinding. **They are not claims of a fully tuned economy**. Notably, two emplacements can beat the current waves without firing player weapons — a known balance issue to evaluate during human testing.

## Known limits

- Only 3 authored assaults, no new procedural wave system.
- End-of-run ranks are a feedback system, not persisted server leaderboards or matchmaking.
- Existing automated weapons still spawn at three fixed positions.
- Browser-accurate mobile UI checks cover the result screen, but **full 3D scene interaction still needs verification**.
- Existing Vite and Three.js integration errors might be discovered by CI and are **not hidden** by these checks.

The production smoke additionally asserts that the victory report's **New run** button remains DOM-stable over 400 ms; this still needs a successful CI run to be verified in the full game.
