# THE LAST KEEP — G10.1 / v2.5: Demo Release Candidate

**Status: RELEASE CANDIDATE, not an independently verified production demo.**

## Scope

G10.1 is a release engineering and runtime recovery milestone. It does **not** add another enemy, tower, building recipe, or wave. The G10 three-wave campaign, War Room, architect, trenches, workers, goofy defenses, tutorial, mobile controls, save compatibility and deterministic game rules remain as before.

### Changes to the playable application

1. **Pre-module startup monitor** (`public/boot-guard.js`, included in `index.html` before the Vite bundle): catches JavaScript and module loading errors, rejected promises, WebGL context loss and failure to display a first frame after 25 seconds. It works even if the Three.js bundle fails to load or initialize.
2. **First-frame confirmation:** `src/main.ts` now reports `lastkeep:ready` only **after the first successful call to WebGL rendering**. The monitor writes `data-game-ready="true"` on the root HTML element. Canvas existence alone is not considered success.
3. **Friendly recovery screen:** touch-sized buttons to reload and copy sanitized debug information. Debug data contains release/version, screen dimensions, online state, the page URL without query parameters, the error message and elapsed start time. It does **not** erase local save data.
4. **Real WebGL loss handling:** if graphics context is lost, the renderer's event is surfaced to the recovery screen so the player is not stuck with an unexplained blank canvas. Recovery is reload-based; automatic context restoration is not promised.
5. **Correct Pages asset URLs:** boot guard loads via a relative URL; user/org repos `OWNER.github.io` deploy to `/`, normal project repos to `/<repo>/`.

### CI/deployment hardening

- The GitHub Pages workflow still unpacks **the highest semantic ZIP** in the repository root. The game's ZIP alone will not change the workflow already checked into a repository; a separate updated Starter is provided.
- Add `npm run typecheck:core`, `npm run smoke:boot`, `npm run write:release`, `npm run verify:dist`, and `npm run smoke:devices` to CI.
- **Bootstrap smoke** exercises six cases in Chromium: happy first-frame, script failure, JavaScript error, unhandled promise, WebGL context lost, timeout. These tests do not require starting the game.
- **Release receipt:** production CI writes `release.json` into the published site, containing the actual package version and ZIP archive name. Access via `<GitHub Pages URL>/release.json` to ensure the latest ZIP is deployed.
- **Production device matrix:** real Vite production preview is loaded and the WebGL scene initialized at 320×568, 360×640, 390×844, 430×932, 568×320, 667×375, and 844×390. The test probes touch action buttons, menu and visual controls overlap, and saves screenshots on failure. CI must pass before deployment. This is **browser viewport emulation**, not testing physical phones.
- `scripts/verify-dist.mjs` checks built output, receipt, asset presence, and the Pages path. It intentionally fails a build missing assets rather than uploading empty or broken content.

## Installation and local commands

```bash
npm install
npm test
npm run check:balance
npm run dev

# With dependencies and Playwright Chromium installed:
npm run build
npm run write:release
npm run verify:dist
npm run preview
npm run smoke:boot
npm run smoke:ui
npm run smoke:tutorial
npm run smoke
npm run smoke:slice
npm run smoke:devices
```

**CI must run the browser smoke against the built production preview, not only against Vite dev mode.**

## Release acceptance criteria

To promote v2.5 RC to **Demo Release**, all of these must be documented:

1. Full `npm install` and Vite production build succeed on GitHub Actions.
2. The production browser tests boot a **real WebGL scene** and check the actual Pages subpath (not only a CSS fixture).
3. Real desktop player completes a normal three-wave run, using combat and construction, with no critical gameplay defects.
4. Android Chrome physical-device player checks thumb controls, fullscreen button, safe areas, landscape/portrait, audio permissions, FPS in wave 3.
5. iOS Safari or iOS home-screen mode is tested if iPhone support is in scope. Unsupported native fullscreen must be communicated, not falsely promised.
6. The deployed URL returns `release.json` with version `2.5.0`, and the game works after reloading with a saved game.
7. Issues, screenshots and device/test versions are attached to the acceptance note.

If any of these fail, the product remains **Release Candidate** and needs an additional bugfix iteration. It is not accurate to call this independently verified MVP before that evidence exists.

## Non-goals

- No real Android or iOS device testing in this environment.
- No claim of 60 FPS or proven performance on a phone.
- No new content (more waves/enemies/progression beyond G10).
- No `node_modules` in the ZIP; GitHub Actions installs dependencies online.
