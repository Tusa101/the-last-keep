# G6.1 — Mobile UX Hotfix (v1.4)

## Scope
- Added fullscreen button on mobile top bar and in menu, using browser Fullscreen API with explicit fallback guidance when unavailable (notably iOS Safari).
- Replaced overlapping mobile-tools toolbar with an accessible modal-like action panel.
- Simplified permanent on-screen buttons to movement, camera, fire, jump, build, remove; other commands in menu.
- Separated safe-area-aware top and bottom zones and simplified HUD on touch devices.
- Mobile menu automatically closes after a command; joystick resets when menu opens.
- No gameplay/terrain mechanics added in this hotfix; underground excavation deferred until mobile playtest.

## Test
1. Android Chrome portrait/landscape: no buttons should overlap, open menu, try fullscreen.
2. iOS Safari: fullscreen API may be unavailable; use Add to Home Screen fallback.
3. Hold joystick and fire simultaneously, then open menu; movement must reset.
4. Test 320x568 and 740x360 CSS viewports.
5. Confirm GitHub Actions deploy and test actual device.

Browser/device testing is not claimed unless explicitly performed.
