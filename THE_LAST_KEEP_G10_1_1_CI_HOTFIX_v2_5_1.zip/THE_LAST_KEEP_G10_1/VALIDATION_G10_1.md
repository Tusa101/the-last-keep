# G10.1 Verification Record — v2.5 Release Candidate

## Proven locally on 2026-10-10

| Check | Result | Limit |
|---|---|---|
| Existing Node game tests | PASS: **152/152** | Core functions, not Three.js runtime |
| Three-wave balance simulation | PASS: **4 loadouts** | Simulation, not human-play difficulty |
| TypeScript core | PASS | Graphics needs full Vite deps |
| Standalone Chromium boot recovery (390×844) | PASS: **6/6 scenarios** | No game bundle required |
| Browser-only mobile tutorial/controls matrix | PASS: **11 viewport layouts**, no overlaps among tested primary controls | Browser fixture, not actual game |
| `node --check` added/edited JavaScript | PASS | Syntax only |
| ZIP test and selector | See packaged final validation | Checks archive integrity, not WebGL |
| `npm install` | **BLOCKED: EAI_AGAIN** | Registry DNS/network unavailable |
| `npm run build`, dist verification | NOT RUN | Needs dependencies |
| Full production WebGL E2E and device matrix | NOT RUN | CI configured to execute online |
| Real Android Chrome / iPhone Safari | NOT RUN | Requires actual device |
| GitHub Pages actual publish | NOT RUN | Requires repo/user to push |

### New watchdog verification

All six scenarios run in installed Chromium via an independent Python Playwright harness using the **actual** `public/boot-guard.js`:

- Simulated first successful frame: no false error overlay.
- JavaScript runtime error: visible recovery UI.
- Failed script load: visible recovery UI.
- Unhandled Promise rejection: visible recovery UI.
- Simulated WebGL context loss: visible recovery UI.
- Startup hanging for 26 virtual seconds: timeout and visible recovery UI.

On a touch emulated 390×844 screen, reload and copy-diagnostics actions are present, recovery panel fits the width, diagnostic details remain accessible.

### No misleading certification

The current infrastructure cannot resolve `registry.npmjs.org`, so Three.js, Vite and Node Playwright are not installed in this workspace. The browser-only watchdog and mobile CSS checks **are not evidence of successful game bootstrap**. A published demo is not certified until external CI and actual playtesting succeed.
