# G10.1.1 — GitHub Actions smoke-test hotfix (v2.5.1)

## Diagnosed from CI log
`vertical-slice-smoke.mjs` used `page.locator('canvas').first().waitFor()` to detect the main game canvas. However the first canvas is `#minimap`, hidden by the HUD on the victory screen. Playwright timed out waiting for that *hidden minimap* to become visible. The prior production smoke had already passed desktop and mobile WebGL startup.

## Fix
- Give the WebGL renderer canvas the stable ID `game-canvas`.
- Wait for `#game-canvas:visible` rather than the first canvas.
- Bump version to `2.5.1` for reliable release receipt and archive selection.

## Validation
- Static check of the selector and its DOM target completed.
- Full CI and actual 3-wave browser smoke must rerun on GitHub Actions.
- No game balance or gameplay changes.

## Deployment
Upload this ZIP in the repository root. The existing version-selecting pipeline should pick 2.5.1 over 2.5.0. No workflow change required.
