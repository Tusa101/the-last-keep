# G9.2 — Tutorial & Player Experience (v2.3)

## Goal
Make the game understandable in a first session without a blocking instruction modal, and let a phone player get from the first tutorial objective through the results screen without a keyboard. Preserve G9.1 control positioning and pre-existing saves.

## Delivered in code

### Eight event-driven onboarding steps

1. **Move around** using joystick/WASD and camera swipe/mouse. Requires actual ~2 m accumulated movement, not a tap.
2. **Gather** wood or stone. Requires a successful resource harvest; a failed attempt does not count.
3. **Build** one block. Requires a successful world build call, including resource spending and collision rules.
4. **Install** an absurd defense weapon. Also recognizes installation via the War Room.
5. **Start** a siege. Recognizes timer-triggered waves as well as early starts.
6. **Survive** the first siege. Completes on an actual RESULT/VICTORY phase, not on button press.
7. **Hire** the first worker. A worker already hired through a previous action is recognized.
8. **Open** the top-down architect planner.

Achievements can occur out of order: the controller remembers evidence and catches up automatically after prerequisites are completed. No tutorial stage can lock building, combat, waves, saves, or worker orders. Completing the guide automatically hides it.

### Helpful navigation on touch

The persistent compact card shows one objective and the correct control for the device. The **Показать управление** action highlights the relevant button (and opens/scrolls the secondary menu if necessary). This spotlight **only shows the UI**; it cannot silently start a wave or spend resources.

The card is a separate DOM node, not repainted with the HUD every ~180 ms. It is hidden while the architect, research panel, War Room, or mobile secondary menu is open. The card does not overlap touch controls in the tested viewport sizes.

### Repeatable and optional

`✕` dismisses the guide without disabling gameplay or erasing evidence. Desktop `F1` toggles guide visibility, `Shift+F1` restarts it. Mobile `☰ → ⚙ Настройки → ⚑ Обучение заново` restarts from the beginning. The tutorial uses a separate, validated `localStorage` key (`the-last-keep-tutorial-v1`), intentionally leaving the game-save envelope version 4 untouched. Malformed guide state is safely ignored.

### Finishing a wave

The existing result panel now has a true clickable/tappable **Следующая подготовка** or **Новый забег** button, so mobile players are no longer dependent on the N/H keyboard shortcuts or finding the menu continuation action.

### Integration

Changes: `src/game/tutorial.ts`, `src/ui/tutorial.ts`, `src/ui/mobile.ts`, `src/ui/style.css`, `src/main.ts`, `tests/tutorial.test.mjs`, `scripts/tutorial-layout-smoke.mjs`, GitHub workflow, package and documentation.

## Known limitations

- The tutorial does not contain custom voiceover, animated arrows on 3D objects, or scripted camera control. It guides real gameplay rather than playing a scripted fake scenario.
- Successful **manual** block placement counts towards the construction objective; queued worker construction alone does not. Other events (defense installation via War Room, auto wave starts) are recognized.
- The 11 Chromium tests use CSS and UI module fixtures, not the whole game. The full Vite build and WebGL scene are still unverified in this environment due to npm registry DNS failures.
- Mobile Fullscreen API support varies by browser, especially on iPhone Safari; the G9.1 limitation remains.

## Manual playtest suggestions

Fresh localStorage: move > 2 m, harvest from a nearby deposit, place a block, install defense, start/complete the first wave, hire the first worker, enter architect. After each real action the guide should advance. Test failed harvesting/insufficient-cost build (must not count), dismiss/reopen/restart, refresh persistence, save/load, opening the War Room during an active guide, and continuing from wave results using the newly tappable button.
