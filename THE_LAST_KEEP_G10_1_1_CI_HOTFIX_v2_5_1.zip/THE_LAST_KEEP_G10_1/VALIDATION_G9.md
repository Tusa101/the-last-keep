# G9 — Validation record

## Run in this execution environment

- `npm test`: **138 passed / 0 failed**, Node.js 22.16.0. (v2.0 had 130.)
- `npm run typecheck:core`: **passed** (includes game simulation and new VFX recipe + block-feedback modules).
- `node --experimental-strip-types --check` on updated TS files: **passed** (syntax only).
- `python3 scripts/select_latest.py` on a two-archive staged repository: verify separately during packaging.
- ZIP CRC and expected files: verify separately during packaging.

## Not verified

- `npm install`: **failed** with DNS `EAI_AGAIN` connecting to registry.npmjs.org.
- `npm run build` / full application typecheck: **not passing**, because `three` and its type declarations are not installed. Full TypeScript check reports missing `three` declarations and cascading implicit-any errors in existing Three-based files. Do not interpret the core typecheck as a complete Vite build.
- Chromium/WebGL/Playwright smoke: **not executed**, even though Chromium is installed, because browser-ready dependencies are missing.
- Android Chrome, iOS Safari, headset audio and live FPS: **not tested**.

## Automated test additions

- `tests/vfx.test.mjs`: recipe validity, bounded budgets, deterministic repeatability, no global RNG calls.
- `tests/audio.test.mjs`: Web Audio user gesture gate, mute and throttle, missing AudioContext fallback.
- `tests/worldFeedback.test.mjs`: new blocks, changing HP, removed masonry, load suppression, mass-collapse cap.

To validate the full project after install, run:

```bash
npm ci    # when a package-lock is present; otherwise npm install
npm test
npm run typecheck
npm run build
npm run dev -- --host 0.0.0.0
npm run smoke   # while Vite is running, with Chromium installed via npx playwright install chromium
```

CI should reject publication on failures. Do not report a real mobile FPS until it has been measured on physical devices.
