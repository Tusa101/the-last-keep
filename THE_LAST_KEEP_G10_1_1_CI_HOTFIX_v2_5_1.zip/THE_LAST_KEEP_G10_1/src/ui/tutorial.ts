import {Tutorial,type TutorialStep} from '../game/tutorial.ts';
export type TutorialPresentation={refresh:()=>void;setSuppressed:(value:boolean)=>void;destroy:()=>void};
/** An unobtrusive HUD card, separate from the constantly repainted combat HUD. */
export function installTutorialGuide(tutorial:Tutorial,opts:{mobile:boolean;onChange:()=>void;onShowAction:(step:TutorialStep)=>void}):TutorialPresentation{
 const el=document.createElement('aside');el.id='tutorial-guide';el.setAttribute('aria-label','Интерактивное обучение');
 document.body.append(el);
 const escape=(s:string)=>s.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]??ch));
 let signature='';let suppressed=false;
 const refresh=()=>{
  const hidden=suppressed||!tutorial.enabled||tutorial.complete;
  if(hidden){el.hidden=true;signature='';return;}
  const step=tutorial.step!;
  const key=`${tutorial.index}:${opts.mobile}`;
  if(key===signature&&el.hidden===false)return;
  signature=key;el.hidden=false;
  const count=tutorial.progress;
  el.innerHTML=`<div class="tutorial-heading"><span>⚑ ПЕРВЫЕ ШАГИ · ${count.current}/${count.total}</span><button type="button" data-tutorial="hide" aria-label="Скрыть обучение" title="Скрыть обучение">✕</button></div>
   <strong>${escape(step.title)}</strong><p>${escape(step.description)}</p>
   <small>${escape(opts.mobile?step.mobile:step.desktop)}</small>
   <div class="tutorial-footer"><span>Задание завершится автоматически</span>${opts.mobile&&step.action?'<button type="button" data-tutorial="show">Показать управление →</button>':''}</div>`;
 };
 el.addEventListener('click',event=>{
  const button=(event.target as HTMLElement).closest<HTMLButtonElement>('button[data-tutorial]');
  if(!button)return;
  if(button.dataset.tutorial==='hide'){tutorial.toggle();opts.onChange();refresh();}
  if(button.dataset.tutorial==='show'&&tutorial.step)opts.onShowAction(tutorial.step);
 });
 refresh();
 return {refresh,setSuppressed:(value:boolean)=>{if(value!==suppressed){suppressed=value;refresh();}},destroy:()=>el.remove()};
}
