import {BRANCHES,DEVELOPMENT,type DevelopmentBranch,type Progression} from '../game/progression.ts';
import type {Siege} from '../game/siege.ts';

/** Focusable progression modal with explicit individual choices; no automatic spending on mobile. */
export function installProgression(progression:Progression,siege:Siege,onMessage:(message:string)=>void,onBought:()=>void){
 const root=document.createElement('section');root.id='development';root.hidden=true;root.setAttribute('role','dialog');
 root.setAttribute('aria-modal','true');root.setAttribute('aria-label','Развитие крепости');
 root.innerHTML=`<div class="development-panel"><header><div><h2>⚒ Развитие крепости</h2><p>Исследования и материалы общие с остальной экономикой. Выбирай, чем пожертвовать ради следующей осады.</p></div><button class="dev-close" type="button">✕ Закрыть</button></header><div id="development-wallet"></div><div id="development-branches"></div><p class="dev-footnote">I — выбрать орудие · O — построить · U — открыть/закрыть развитие. Улучшения доступны только между волнами.</p></div>`;
 document.body.append(root);
 let focusReturn:HTMLElement|null=null;
 const render=()=>{
  if(root.hidden)return;
  const wallet=root.querySelector<HTMLElement>('#development-wallet')!;
  wallet.textContent=`Знания: ${siege.research}  ·  Камень: ${Math.floor(progression.world.resources.stone)}  ·  Дерево: ${Math.floor(progression.world.resources.wood)}  ·  Волна: ${siege.wave}/3`;
  const branchContainer=root.querySelector<HTMLElement>('#development-branches')!;
  branchContainer.innerHTML=BRANCHES.map(b=>{
   const spec=DEVELOPMENT[b],level=progression.level(b),cost=progression.cost(b),check=progression.canBuy(b,siege.phase,siege.wave);
   const costText=cost?`${cost.research} знаний · ${cost.stone} камня · ${cost.wood} дерева`:'Все уровни открыты';
   const next=level<2?spec.levels[level]:'Все эффекты активированы';
   return `<article class="development-card"><div><h3>${spec.name} <span>${level}/2</span></h3><p>${spec.description}</p><p class="dev-effect">Следующий уровень: ${next}</p><p class="dev-cost">${costText}</p></div><button type="button" data-dev="${b}" ${check.ok?'':'disabled'}>${cost?`Изучить уровень ${level+1}`:'Максимум'}</button><small>${check.ok?'Можно приобрести':check.reason}</small></article>`;
  }).join('');
  branchContainer.querySelectorAll<HTMLButtonElement>('button[data-dev]').forEach(button=>button.addEventListener('click',()=>{
   const b=button.dataset.dev as DevelopmentBranch;
   const result=progression.buy(b,siege.phase,siege.wave);
   onMessage(result.ok?`✓ ${result.reason}`:`Ошибка: ${result.reason}`);
   if(result.ok)onBought();render();
  }));
 };
 const close=()=>{if(root.hidden)return;root.hidden=true;focusReturn?.focus();};
 const open=()=>{if(!root.hidden)return;focusReturn=document.activeElement instanceof HTMLElement?document.activeElement:null;root.hidden=false;render();root.querySelector<HTMLButtonElement>('.dev-close')?.focus();};
 root.querySelector('.dev-close')?.addEventListener('click',close);
 root.addEventListener('pointerdown',e=>{if(e.target===root)close();});
 return {open,close,toggle:()=>root.hidden?open():close(),isOpen:()=>!root.hidden,refresh:render};
}
