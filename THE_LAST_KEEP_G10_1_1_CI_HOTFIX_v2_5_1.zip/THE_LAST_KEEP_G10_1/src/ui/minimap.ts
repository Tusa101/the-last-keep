import type {World} from '../world/model.ts';
import type {Excavation} from '../world/excavation.ts';
import type {Worker} from '../game/workers.ts';
import {STOCKPILE} from '../game/workers.ts';
import type {Raider} from '../game/siege.ts';
import type {Intel} from '../game/encounters.ts';
/** Small top-down tactical map. Uses the real world blocks, never a fabricated level image. */
export function drawMinimap(canvas:HTMLCanvasElement,world:World,player:{x:number;z:number},yaw:number,
 raiders:readonly Raider[],intel:Intel|null,announceFronts:boolean,workers:readonly Worker[]=[],excavation?:Excavation){
 const ctx=canvas.getContext('2d');if(!ctx)return;
 const w=canvas.width,h=canvas.height,scale=w/48;
 const sx=(x:number)=>w/2+x*scale,sy=(z:number)=>h/2+z*scale;
 ctx.clearRect(0,0,w,h);ctx.fillStyle='#293e38';ctx.fillRect(0,0,w,h);
 // Ground + readable courtyard footprint.
 ctx.fillStyle='#556450';ctx.fillRect(sx(-22),sy(-22),44*scale,44*scale);
 ctx.fillStyle='#998d70';ctx.fillRect(sx(-10),sy(-8),22*scale,16*scale);
 ctx.strokeStyle='#b2a184';ctx.lineWidth=1.2;ctx.strokeRect(sx(-10),sy(-8),22*scale,16*scale);
 // Tactical trenches in depth-coded brown before masonry is drawn.
 for(const p of excavation?.cells()??[]){ctx.fillStyle=['','#92775c','#6f5947','#3d302d'][p.depth];ctx.fillRect(sx(p.x)-scale*.49,sy(p.z)-scale*.49,scale*.98,scale*.98);}
 for(const [id,b] of world.blocks){const [x,y,z]=id.split(',').map(Number);
  if(y>1)continue;
  ctx.fillStyle=b.material==='stone'?'#ded4b8':'#b88b63';
  ctx.globalAlpha=b.hp<40?.5:.88;ctx.fillRect(sx(x)-scale*.47,sy(z)-scale*.47,scale*.94,scale*.94);
 }
 ctx.globalAlpha=1;
 // Known future assault axes are marked before the attackers physically arrive.
 if(announceFronts&&intel){
  ctx.lineWidth=2;ctx.strokeStyle='#eb9a72';ctx.fillStyle='#eb9a72';
  for(const front of intel.fronts){
   ctx.beginPath();if(front==='west'){
    ctx.moveTo(sx(-20),sy(-4));ctx.lineTo(sx(-13),sy(-4));ctx.lineTo(sx(-15),sy(-5.5));ctx.moveTo(sx(-13),sy(-4));ctx.lineTo(sx(-15),sy(-2.5));
   }else{ctx.moveTo(sx(0),sy(-20));ctx.lineTo(sx(0),sy(-13));ctx.lineTo(sx(-1.5),sy(-15));ctx.moveTo(sx(0),sy(-13));ctx.lineTo(sx(1.5),sy(-15));}
   ctx.stroke();
  }
 }
 // Nexus beacon.
 ctx.fillStyle='#81ead5';ctx.shadowColor='#81ead5';ctx.shadowBlur=9;
 ctx.beginPath();ctx.moveTo(sx(9),sy(0)-7);ctx.lineTo(sx(9)+6,sy(0));ctx.lineTo(sx(9),sy(0)+7);ctx.lineTo(sx(9)-6,sy(0));ctx.closePath();ctx.fill();ctx.shadowBlur=0;
 for(const r of raiders)if(r.alive&&r.spawnIn<=0){
  ctx.beginPath();ctx.fillStyle=({brute:'#ffb462',jelly:'#ffa1d1',hopper:'#8be2b4',bombardier:'#caa7ff'} as const)[r.kind];
  ctx.arc(sx(r.brain.x),sy(r.brain.z),r.kind==='brute'?4.9:r.kind==='bombardier'?4.3:3.1,0,Math.PI*2);ctx.fill();
  if(r.kind==='brute'||r.kind==='bombardier'){ctx.lineWidth=1.3;ctx.strokeStyle='#402b2b';ctx.stroke();}
 }
 // Storage and workers have distinct markers from the attacking forces.
 ctx.fillStyle='#f1d28c';ctx.fillRect(sx(STOCKPILE.x)-3.5,sy(STOCKPILE.z)-3.5,7,7);
 for(const w of workers){ctx.fillStyle='#7de2b6';ctx.beginPath();ctx.arc(sx(w.x),sy(w.z),3.4,0,Math.PI*2);ctx.fill();}
 // Player heading points the same way as FPS forward (-sin(yaw),-cos(yaw)).
 ctx.save();ctx.translate(sx(player.x),sy(player.z));ctx.rotate(-yaw-Math.PI/2);
 ctx.beginPath();ctx.moveTo(10,0);ctx.lineTo(-6,-5);ctx.lineTo(-3,0);ctx.lineTo(-6,5);ctx.closePath();
 ctx.fillStyle='#fff4d3';ctx.strokeStyle='#25352f';ctx.lineWidth=1.3;ctx.fill();ctx.stroke();ctx.restore();
 // Camera framing.
 ctx.strokeStyle='rgba(223,209,171,.65)';ctx.lineWidth=2;ctx.strokeRect(.5,.5,w-1,h-1);
}
