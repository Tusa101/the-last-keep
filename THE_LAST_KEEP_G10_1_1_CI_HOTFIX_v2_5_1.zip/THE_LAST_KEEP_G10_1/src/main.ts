import './ui/style.css';
import {installArchitect} from './ui/architect.ts';
import {installMobileControls,isTouchDevice,type MobileAction} from './ui/mobile.ts';
import {drawMinimap} from './ui/minimap.ts';
import {waveIntel,nextIntel,clockLabel,phaseLabel} from './game/encounters.ts';
import * as THREE from 'three';
import {Excavation} from './world/excavation.ts';
import {World,type Cell,type Material,type Shape,type Orientation} from './world/model.ts';
import {SHAPES} from './world/shapes.ts';
import {seedCastle} from './world/preset.ts';
import {Defenses,DEFENSE_COSTS,type DefenseKind} from './game/defenses.ts';
import {Progression,BRANCHES,DEVELOPMENT} from './game/progression.ts';
import {installProgression} from './ui/progression.ts';
import {installWarRoom} from './ui/warroom.ts';
import {Siege,UPGRADES,type Weapon,type Upgrade} from './game/siege.ts';
import {Gathering} from './game/gathering.ts';
import {Workers,type WorkMode} from './game/workers.ts';
import {Sfx} from './game/audio.ts';
import {Tutorial} from './game/tutorial.ts';
import {CampaignJournal,ratingNames} from './game/campaign.ts';
import {installTutorialGuide} from './ui/tutorial.ts';
import {AdaptiveQuality,type QualityMode} from './game/performance.ts';
import {makeScene} from './render/scene.ts';
import {stepPlayer,intersectsPlayer,type Player} from './physics/player.ts';

const world=new World();
seedCastle(world);
const excavation=new Excavation(world);
const initialWorld=world.serialize();
const defenses=new Defenses(world);
const view=makeScene(world,excavation),siege=new Siege(world,excavation),gathering=new Gathering(world),workers=new Workers(world,gathering,excavation),keys=new Set<string>(),sfx=new Sfx();
const progression=new Progression(world,siege);
const campaign=new CampaignJournal();
function applyDevelopment(){siege.masonryLevel=progression.level('masonry');workers.masonryLevel=siege.masonryLevel;workers.logisticsLevel=progression.level('logistics');defenses.ordnanceLevel=progression.level('ordnance');}
applyDevelopment();
view.setDeposits(gathering.deposits);
let player:Player={x:-5,y:0,z:4,vy:0,grounded:true};
let yaw=1.3,pitch=-.12,paused=true,material:Material='stone',shape:Shape='full',dir:Orientation=0,sequence=0;
let lineMode=false,verticalMode=false,start:Cell|null=null,columnHeight=3;
let shotCooldown=0,weapon:Weapon='bolt';
let previousPhase=siege.phase;
view.setWeapon(weapon);
let announcement='Восстанови стены крепости. Враг идёт к Нексусу.',noticeUntil=0;
let previewResult='';
const hud=document.getElementById('hud')!;
hud.addEventListener('click',event=>{
 const button=(event.target as HTMLElement).closest<HTMLButtonElement>('button[data-report-action]');
 if(!button)return;event.preventDefault();
 if(button.dataset.reportAction==='next')mobileKey('KeyN');
 if(button.dataset.reportAction==='restart')mobileKey('KeyH');
});
const SK='the-last-keep-g31-save'; // preserve compatibility with existing G3.1/G4 saves
const TUTORIAL_KEY='the-last-keep-tutorial-v1';
const tutorial=new Tutorial();
try{const stored=localStorage.getItem(TUTORIAL_KEY);if(stored)tutorial.restore(JSON.parse(stored));}catch{/* unavailable storage must never block the game */}
function persistTutorial(){try{localStorage.setItem(TUTORIAL_KEY,JSON.stringify(tutorial.snapshot()));}catch{/* private mode */}}
function recordTutorial(event:import('./game/tutorial.ts').TutorialEvent){if(tutorial.mark(event)){persistTutorial();guide.refresh();}}
let showHelp=false,phaseChangedAt=performance.now();
const mobileEnabled=isTouchDevice();
const quality=new AdaptiveQuality();
if(mobileEnabled)view.setResolutionScale(quality.setMode('auto'));
let frameCounter=0,displayFps=0,fpsClock=performance.now();
let mobile:ReturnType<typeof installMobileControls>|null=null;
const guide=installTutorialGuide(tutorial,{mobile:mobileEnabled,onChange:persistTutorial,onShowAction:step=>mobile?.spotlightAction(step.action!)});
let guideDistance=0;
let lastMobileShot=0;
let architectOpen=false;
const architect=installArchitect(world,workers,msg=>announce(msg),opened=>{architectOpen=opened;keys.clear();if(opened){recordTutorial('architectOpened');if(document.pointerLockElement)document.exitPointerLock();}});
const announce=(msg:string)=>{announcement=msg;noticeUntil=performance.now()+3500;};
const development=installProgression(progression,siege,announce,applyDevelopment);
let selectedDefense:DefenseKind='carrotTower';
const defenseKinds:DefenseKind[]=['carrotTower','cheeseMortar','syrupSprayer'];
const warRoom=installWarRoom(world,siege,defenses,gathering,workers,announce,
 ()=>{if(siege.startEarly())announce('⚔ Осада началась!');},
 ()=>{if(siege.next())announce('Новая подготовка: повреждения сохраняются');},
 ()=>development.open(),
 kind=>{selectedDefense=kind;mobile?.setDefenseLabel(DEFENSE_COSTS[kind].label);});
function selectDefense(){selectedDefense=defenseKinds[(defenseKinds.indexOf(selectedDefense)+1)%defenseKinds.length];const c=DEFENSE_COSTS[selectedDefense];announce(`Выбрано: ${c.label} · ${c.wood} дерева, ${c.stone} камня`);mobile?.setDefenseLabel(c.label);}
const id=()=>`g22-${Date.now()}-${sequence++}`;
function buildValid(cells:Cell[]){
 const result=world.checkBuild(cells,material);
 if(!result.ok)return result;
 if(cells.some(c=>c.y===0&&excavation.depth(c.x,c.z)>0))return {ok:false,reason:'Для кладки нужен ровный грунт. Не строй над рвом.',cost:cells.length};
 if(cells.some(c=>intersectsPlayer(c,shape,player,dir)))return {ok:false,reason:'Нельзя строить внутри игрока',cost:cells.length};
 if(cells.some(c=>siege.raiders.some(e=>e.alive&&Math.abs(c.x-e.brain.x)<2&&Math.abs(c.z-e.brain.z)<2&&c.y<=1)))return {ok:false,reason:'Противник находится в зоне стройки',cost:cells.length};
 // Keep the Nexus accessible for this minimal demo rather than allow deletion through placement.
 if(cells.some(c=>Math.abs(c.x-9)<=1&&Math.abs(c.z)<=1&&c.y<=1))return {ok:false,reason:'Нексус: запрещена застройка центра',cost:cells.length};
 return result;
}
function projectedEndpoint(raw:Cell,startCell:Cell){
 const dx=raw.x-startCell.x,dz=raw.z-startCell.z;
 if(Math.abs(dx)>=Math.abs(dz))return {x:raw.x,y:startCell.y,z:startCell.z};
 return {x:startCell.x,y:startCell.y,z:raw.z};
}
function currentPlan(){
 const target=view.aim().place;
 if(!lineMode){return target?[target]:[];}
 if(!start)return target?[target]:[];
 if(verticalMode){return World.line(start,{...start,y:start.y+columnHeight-1});}
 if(!target)return [start];
 return World.line(start,projectedEndpoint(target,start));
}
function preview(){
 if(paused||architectOpen){view.showPreview([],true,shape,dir);previewResult='';return;}
 const cells=currentPlan();
 const check=buildValid(cells);previewResult=check.reason;
 view.showPreview(cells,check.ok,shape,dir);
}
function escapeText(s:string){return s.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]??ch));}
let lastResultHudSignature='';
function drawHUD(){
 const aim=view.aim(),looking=aim.hit?`${aim.hit.x}, ${aim.hit.y}, ${aim.hit.z}`:'—';
 const weaponName=weapon==='carrot'?'Морковомёт':'Арбалет';
 const shapeNames:Record<Shape,string>={full:'Куб',slab:'Плита ½',stair:'Лестница',battlement:'Зубцы',arrowSlit:'Бойница'};
 const intel=siege.phase==='SIEGE'?waveIntel(siege.wave):nextIntel(siege.wave);
 const when=siege.phase==='SIEGE'?'СЕЙЧАС':'СЛЕДУЮЩАЯ ОСАДА';
 const frontline=intel?.fronts.map(f=>f==='west'?'ЗАПАД':'СЕВЕР').join(' + ')??'—';
 const enemyCount=siege.raiders.filter(e=>e.alive&&e.spawnIn<=0).length;
 const queuedCount=siege.raiders.filter(e=>e.alive&&e.spawnIn>0).length;
 const artillery=siege.raiders.filter(e=>e.alive&&e.kind==='bombardier'&&e.spawnIn<=0).length;
 const vaults=siege.raiders.filter(e=>e.alive&&e.kind==='hopper'&&e.spawnIn<=0).length;
 const nearby=gathering.nearest(player.x,player.z);
 const gatherHint=nearby?`<div class="gather-hint">⛏ <b>X</b> ДОБЫТЬ ${nearby.material==='stone'?'КАМЕНЬ':'ДРЕВЕСИНУ'} · осталось ${nearby.remaining}</div>`:'';
 const modeNames:Record<WorkMode,string>={balanced:'Авто',gather:'Добыча',build:'Стройка',repair:'Ремонт'};
 const defenseStatus=defenses.placed.map(d=>DEFENSE_COSTS[d.kind].label).join(' · ')||'не установлены';
 const chosenCost=DEFENSE_COSTS[selectedDefense];
 const developStatus=BRANCHES.map(b=>`${DEVELOPMENT[b].name}: ${progression.level(b)}/2`).join(' · ');
 const workerStatus=workers.workers.map(w=>`<div class="worker-line">👷 ${w.id}: ${escapeText(w.status)}${w.cargo?` · 🎒 ${w.amount} ${w.cargo==='wood'?'древ.':'кам.'}`:''}</div>`).join('');
 const phaseClass=siege.phase==='WARNING'?'warning':siege.phase==='SIEGE'?'siege':'';
 const phasePopup=(siege.phase==='WARNING'||siege.phase==='SIEGE')&&performance.now()-phaseChangedAt<3000;
 const resultMessage=siege.phase==='RESULT'||siege.phase==='VICTORY'||siege.phase==='DEFEAT';
 document.body.classList.toggle('game-result',resultMessage);
 // Do not recreate the report button every 100–180 ms. A long mobile tap on a
 // replaced DOM button loses its click before pointerup. Battles keep live HUD updates.
 const resultSignature=resultMessage?`${siege.phase}/${siege.wave}/${siege.nexus}/${campaign.snapshot()}`:'';
 if(resultMessage&&resultSignature===lastResultHudSignature)return;
 lastResultHudSignature=resultSignature;
 const shapes=`${lineMode?(verticalMode?`Вертикаль ↑${columnHeight}`:'Линия'):'Один блок'} · ${shapeNames[shape]} · ${['+X','+Z','−X','−Z'][dir]}`;
 const upgrades=(Object.keys(UPGRADES) as Upgrade[]).map((u,i)=>{
  const done=siege.unlocked.has(u);
  return `<div class="researchitem ${done?'done':''}"><b>${i+5}</b> · ${UPGRADES[u].title}<br>${done?'✓ Открыто':`${UPGRADES[u].cost} знаний`}</div>`;
 }).join('');
 const pausedOverlay=paused&&!architectOpen&&!mobileEnabled&&!resultMessage?`<div class="centerpanel"><h1>THE LAST KEEP</h1><p>Древний замок — настоящие каменные стены. Гости — совершенно не те, кого приглашали.</p><p>Защити Нексус от армии ошибочной алхимии. Почини проломы, строй стены, выстреливай из бойниц.</p><div class="start">КЛИК ПО ИГРЕ — ВЕРНУТЬСЯ</div><p style="margin-top:10px;font-size:11px">WASD · мышь · G ранняя осада · Tab полное управление</p></div>`:'';
 const campaignRows=campaign.records.map(r=>`<div class="campaign-row"><span>⚑ ${r.wave}/3 · ${r.outcome==='held'?'ОТБИТО':'ПОРАЖЕНИЕ'}</span><b>${r.score}/100</b><small>◈ ${r.nexus} HP · ${r.kills}/${r.enemies} противников</small></div>`).join('');
 const campaignSummary=campaign.records.length?`<div class="campaign-scorecard" aria-label="Итоги трёх осад">${campaignRows}<div class="campaign-total">${siege.phase==='VICTORY'?ratingNames[campaign.rating()]:'СУММА ОЧКОВ'} · ${campaign.totalScore()}/${campaign.records.length*100}</div></div>`:'';
 const reportOverlay=resultMessage?`<div class="centerpanel"><h1>${siege.phase==='DEFEAT'?'КРЕПОСТЬ ПАЛА':siege.phase==='VICTORY'?'ПОБЕДА!':'ОСАДА ОТБИТА'}</h1><p>${siege.phase==='DEFEAT'?'Нексус уничтожен. Перестрой оборону и попробуй снова.':'Победа не стирает трещины: следующая осада встретит именно этот замок.'}</p><div class="ending">Устранено врагов: ${siege.lastReport.kills} · Потери Нексуса: ${siege.lastReport.nexusLost}<br>Знания за оборону: +${siege.lastReport.researchEarned}</div>${campaignSummary}<button type="button" class="start report-action" data-report-action="${siege.phase==='RESULT'?'next':'restart'}">${siege.phase==='RESULT'?'→ СЛЕДУЮЩАЯ ПОДГОТОВКА':'↻ НОВЫЙ ЗАБЕГ'}</button><p>Исследования: 5 / 6 / 7 · K — сохранить</p></div>`:'';
 hud.innerHTML=`
 <div class="mobile-status" aria-label="Состояние крепости"><span class="mobile-stat danger">◈ ${siege.nexus}/100</span><span class="mobile-stat">⚑ ${siege.wave}/3 · ${clockLabel(siege.time)}</span><span class="mobile-stat">🪨 ${Math.floor(world.resources.stone)}</span><span class="mobile-stat">🪵 ${Math.floor(world.resources.wood)}</span><span class="mobile-stat small">${displayFps||'…'} FPS</span></div>
 <div class="topbar"><div class="brand"><strong>THE LAST KEEP</strong><small>ОСАДНЫЙ ЗАМОК · v2.4 / G10</small></div>
 <div class="phasebox ${phaseClass}"><div><small>${phaseLabel(siege.phase)}</small><b>ВОЛНА ${siege.wave}/3</b></div><div class="clock">${clockLabel(siege.time)}</div></div></div>
 <div class="intel"><strong>${when} · ${intel?.title??'ЗАБЕГ ЗАВЕРШЁН'} <em>↗ ${frontline}</em></strong><span>${intel?.brief??'Приказы более не поступают.'}</span></div>
 <div id="radarWrap"><div class="radarlabel">ОБЗОР ПОДСТУПОВ <span>↑ СЕВЕР</span></div><canvas id="minimap" width="224" height="224" aria-label="Тактическая миникарта"></canvas></div>
 <div class="rightstats"><div class="statline"><span>◈ НЕКСУС</span><b>${siege.nexus} / 100</b></div><div class="life"><span style="width:${siege.nexus}%"></span></div>
 <div class="statline"><span>Атакующие</span><b>${enemyCount} + ${queuedCount} в пути</b></div><div class="statline"><span>Прыгуны / Артиллерия</span><b>${vaults} / ${artillery}</b></div><div class="statline"><span>Ловушка</span><b>${siege.trapCharges} зарядов</b></div><div class="statline"><span>Знания</span><b>${siege.research}</b></div><div class="statline"><span>Рабочие</span><b>${workers.workers.length}/${2}</b></div><div class="statline"><span>FPS</span><b>${displayFps||'…'} · ${Math.round(quality.scale*100)}%</b></div></div>
 <div class="leftbottom"><h3>⚒ МАСТЕРСКАЯ СМОТРИТЕЛЯ</h3><div class="gridstats"><div>Камень<strong>${Math.floor(world.resources.stone*10)/10}</strong></div><div>Дерево<strong>${Math.floor(world.resources.wood*10)/10}</strong></div><div>Оружие<strong style="font-size:12px">${weaponName}</strong></div></div>
 <div class="smallline"><b>Стройка:</b> ${shapes}<br><b>Материал:</b> ${material==='stone'?'Камень':'Дерево'} · <b>Прицел:</b> ${looking}<br><b>Превью:</b> ${escapeText(previewResult)}</div>
 <div class="workerspanel"><div>🛡 Оборона: ${escapeText(defenseStatus)}<br>Выбрано: ${escapeText(chosenCost.label)} (${chosenCost.wood} дерева / ${chosenCost.stone} камня) · I выбор / O постройка</div><div class="workers-title">👷 РАБОЧИЕ · ${workers.workers.length}/2 · ${modeNames[workers.mode]}</div>
  <div>Чертежи: <b>${workers.orders.length}</b> блоков · раскопки: <b>${workers.digOrders.length}</b> клеток · склад: ◇</div>${workerStatus||'<div>После первой осады нажми J, чтобы нанять помощника.</div>'}
  <div class="worker-shortcuts">J нанять · T чертёж · P архитектор · Y приоритет · C отмена</div></div>
 <div class="research">${upgrades}</div><div class="development-summary">⚑ Военный совет · R открыть<br>⚒ Развитие · U открыть<br>${escapeText(developStatus)}</div><div class="tip">Материалы от рабочих поступают на склад только после доставки. Исследования не превращаются в камень.</div></div>
 <div class="rightbottom"><b>КРАТКОЕ УПРАВЛЕНИЕ · TAB — ПОДРОБНЕЕ</b><br><kbd>WASD</kbd> ходьба · <kbd>Space</kbd> прыжок<br><kbd>Shift + ЛКМ</kbd> выстрел · <kbd>E</kbd> оружие<br><kbd>ПКМ</kbd> строить · <kbd>ЛКМ</kbd> разобрать<br><kbd>G</kbd> вызвать волну · <kbd>N</kbd> следующая<br><kbd>F</kbd> ремонт · <kbd>X</kbd> добыча · <kbd>1–4</kbd> формы<br><kbd>J</kbd> нанять · <kbd>T</kbd> чертёж · <kbd>Y</kbd> задачи · <kbd>C</kbd> отменить<br><kbd>U</kbd> развитие · <kbd>I</kbd> выбор орудия · <kbd>O</kbd> установить<br><kbd>R</kbd> военный совет и позиции орудий</div>
 ${performance.now()<noticeUntil?`<div class="notice ${announcement.startsWith('Ошибка')?'err':''}">${escapeText(announcement)}</div>`:''}
 ${phasePopup?`<div class="alert ${phaseClass}"><h2>${siege.phase==='WARNING'?'ВРАГ У ВОРОТ':'ЗАМОК ПОД ОСАДОЙ'}</h2><p>${intel?.brief??''}</p></div>`:''}
 ${showHelp?`<div class="help"><b>УПРАВЛЕНИЕ · TAB закрыть</b><br>WASD движение, Space прыжок<br>ЛКМ разобрать, ПКМ построить<br>1/2 камень/дерево · 3 форма · 4 лестница · Q поворот<br>B строить линию · V вертикальный режим · колёсико высота<br>I выбор оборонительного орудия · O установка · U развитие замка · R военный совет<br>F ремонт · X добыть · Z копать ров · Shift+Z поручить копать рабочим · Shift+ЛКМ стрелять · E оружие<br>G начать волну · N следующая · 5/6/7 исследования<br>J нанять (после волны 1), T построить по чертежу, Y режим, C отмена<br>K/L сохранение и загрузка · H сбросить<br>M звук · F1 показать/скрыть обучение · Shift+F1 начать его заново · Esc курсор</div>`:''}
 ${gatherHint}${pausedOverlay}${reportOverlay}`;
 const map=document.getElementById('minimap') as HTMLCanvasElement|null;
 if(map)drawMinimap(map,world,player,yaw,siege.raiders,intel,siege.phase==='PREP'||siege.phase==='WARNING',workers.workers,excavation);
}
function place(cells:Cell[]){
 const check=buildValid(cells);
 if(!check.ok){announce(`Ошибка: ${check.reason}`);return;}
 const result=world.build(id(),cells,material,shape,dir);
 announce(result.ok?`Построено ${cells.length} блок(а), потрачено ${result.cost}`:`Ошибка: ${result.reason}`);
 if(result.ok)recordTutorial('built');
}
function save(quiet=false){
 try{localStorage.setItem(SK,JSON.stringify({version:5,campaign:campaign.snapshot(),world:world.serialize(),siege:siege.snapshot(),gathering:gathering.snapshot(),workers:workers.snapshot(),excavation:excavation.snapshot(),player,yaw,pitch,weapon,defenses:defenses.snapshot(),progression:progression.snapshot()}));if(!quiet)announce('Весь забег, ресурсы, враги и исследования сохранены');}
 catch(e){announce(`Ошибка сохранения: ${String(e)}`);}
}
function load(){
 try{
  const text=localStorage.getItem(SK);if(!text)throw Error('Сохранение не найдено');
  const raw=JSON.parse(text) as {version:number;world:string;siege:string;gathering?:string;workers?:string;excavation?:string;campaign?:string;player:Player;yaw:number;pitch:number;weapon:Weapon;defenses?:string;progression?:string};
  if(![2,3,4,5].includes(raw.version)||raw.version>=3&&typeof raw.gathering!=='string'||raw.version>=4&&typeof raw.workers!=='string'||raw.version===5&&typeof raw.campaign!=='string'||typeof raw.world!=='string'||typeof raw.siege!=='string'||
   !raw.player||![raw.player.x,raw.player.y,raw.player.z].every(Number.isFinite)||
   ![raw.yaw,raw.pitch].every(Number.isFinite)||!['bolt','carrot'].includes(raw.weapon))throw Error('Неверная версия/формат');
  // Test both save payloads against disposable instances BEFORE changing live state.
  const sandbox=new World();sandbox.restore(raw.world);const sandboxExcavation=new Excavation(sandbox);
  if(raw.excavation!==undefined)sandboxExcavation.restore(raw.excavation);
  new Siege(sandbox,sandboxExcavation).restore(raw.siege);
  if(raw.defenses!==undefined)new Defenses(sandbox).restore(raw.defenses);
  if(raw.progression!==undefined)new Progression(sandbox,new Siege(sandbox,sandboxExcavation)).restore(raw.progression);
  const sandboxGathering=new Gathering(sandbox);if(raw.version>=3)sandboxGathering.restore(raw.gathering!);
  if(raw.version>=4)new Workers(sandbox,sandboxGathering,sandboxExcavation).restore(raw.workers!);
  if(raw.version===5)new CampaignJournal().restore(raw.campaign!);
  world.restore(raw.world);siege.restore(raw.siege);
  if(raw.defenses!==undefined)defenses.restore(raw.defenses);else defenses.reset();
  if(raw.version>=3)gathering.restore(raw.gathering!);else gathering.reset();
  if(raw.excavation!==undefined)excavation.restore(raw.excavation);else excavation.reset();
  if(raw.version>=4)workers.restore(raw.workers!);else workers.reset();
  if(raw.version===5)campaign.restore(raw.campaign!);else campaign.reset();
  if(raw.progression!==undefined)progression.restore(raw.progression);else progression.reset();
  applyDevelopment();development.refresh();
  player={x:raw.player.x,y:raw.player.y,z:raw.player.z,vy:0,grounded:false};yaw=raw.yaw;pitch=raw.pitch;
  weapon=raw.weapon==='carrot'&&siege.unlocked.has('carrot')?'carrot':'bolt';syncLook();
  view.setWeapon(weapon);previousPhase=siege.phase;phaseChangedAt=performance.now();view.setPhase(siege.phase);start=null;guideDistance=0;warRoom.refresh();announce('Сохранение успешно восстановлено');
 }catch(e){announce(`Ошибка загрузки: ${String(e)}`);}
}
const syncLook=()=>{view.camera.rotation.order='YXZ';view.camera.rotation.set(pitch,yaw,0);};
syncLook();
view.renderer.domElement.addEventListener('click',()=>{
 if(!mobileEnabled&&document.pointerLockElement!==view.renderer.domElement)view.renderer.domElement.requestPointerLock();
});
document.addEventListener('pointerlockchange',()=>{if(mobileEnabled)return;paused=document.pointerLockElement!==view.renderer.domElement;if(paused)keys.clear();drawHUD();});
document.addEventListener('mousemove',e=>{if(paused)return;
 yaw-=e.movementX*.0024;pitch=Math.max(-1.4,Math.min(1.4,pitch-e.movementY*.0024));syncLook();
});
document.addEventListener('keydown',e=>{
 if(!e.repeat)sfx.unlock();
 if(e.code==='F1'){e.preventDefault();if(e.shiftKey||tutorial.complete)tutorial.reset();else tutorial.toggle();persistTutorial();guide.refresh();return;}
 if(['Space','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();
 keys.add(e.code);if(e.repeat)return;
 if(e.code==='KeyR'){
  if(architectOpen){announce('Сначала закрой режим архитектора');return;}
  if(development.isOpen())development.close();
  warRoom.toggle();keys.clear();
  if(warRoom.isOpen()&&document.pointerLockElement)document.exitPointerLock();
  drawHUD();return;
 }
 if(e.code==='Escape'&&warRoom.isOpen()){warRoom.close();keys.clear();return;}
 if(warRoom.isOpen())return;
 if(e.code==='KeyU'){if(architectOpen){announce('Сначала закрой режим архитектора');return;}development.toggle();keys.clear();if(development.isOpen()&&document.pointerLockElement)document.exitPointerLock();drawHUD();return;}
 if(e.code==='Escape'&&development.isOpen()){development.close();return;}
 if(development.isOpen())return;
 if(e.code==='KeyP'&&!e.repeat){architect.toggle();drawHUD();return;}
 if(architectOpen)return;
 if(e.code==='Tab'){e.preventDefault();showHelp=!showHelp;}
 if(e.code==='KeyZ'&&!paused){
  const target=view.aim().place;const c=target??{x:Math.round(player.x-Math.sin(yaw)*2),y:0,z:Math.round(player.z-Math.cos(yaw)*2)};
  if(e.shiftKey){const order=workers.queueDig([{x:c.x,z:c.z}]);announce(order.message);}
  else{const result=excavation.dig(c.x,c.z);announce(result.ok?`Ров: глубина ${result.depth}/3 (${Math.round(-excavation.groundY(c.x,c.z)*100)} см) · +${result.stone} камня`:`Ошибка: ${result.reason}`);}
 }
 if(e.code==='KeyX'&&!paused){const result=gathering.harvest(player.x,player.z,performance.now()/1000);
  if(result.ok)recordTutorial('harvested');
  announce(result.ok?`Добыто ${result.amount} ед. ${result.material==='stone'?'камня':'дерева'} · ресурс конечен`:`Ошибка: ${result.reason}`);}
 if(e.code==='KeyJ'&&!paused){const result=workers.hire(siege.phase,siege.wave);if(result.ok)recordTutorial('workerHired');announce(result.message);}
 if(e.code==='KeyT'&&!paused){
  if(siege.phase==='SIEGE'||siege.phase==='WARNING')announce('Ошибка: рабочие укрываются во время осады');
  else{const result=workers.queueBuild(currentPlan(),material,shape,dir);announce(result.message);if(result.ok)start=null;}
 }
 if(e.code==='KeyY'&&!paused){const mode=workers.cycleMode();announce(`Приоритет рабочих: ${{balanced:'авто',gather:'добыча',build:'стройка',repair:'ремонт'}[mode]}`);}
 if(e.code==='KeyC'&&!paused){const cancelled=workers.clearOrders();start=null;announce(`Отменено поручений: ${cancelled}`);}
 if(e.code==='KeyM'){sfx.enabled=!sfx.enabled;if(sfx.enabled)sfx.unlock();mobile?.setSoundLabel(sfx.enabled?'вкл':'выкл');announce(sfx.enabled?'Звук включён':'Звук выключен');}
 if(e.code==='Digit1')material='stone';
 if(e.code==='Digit2')material='wood';
 if(e.code==='Digit3')shape=SHAPES[(SHAPES.indexOf(shape)+1)%SHAPES.length];
 if(e.code==='Digit4')shape='stair';
 if(e.code==='KeyQ')dir=((dir+1)%4) as Orientation;
 if(e.code==='KeyB'){if(lineMode&&!verticalMode){lineMode=false;}else{lineMode=true;verticalMode=false;}start=null;}
 if(e.code==='KeyV'){if(lineMode&&verticalMode){lineMode=false;verticalMode=false;}else{lineMode=true;verticalMode=true;}start=null;}
 if(e.code==='KeyG'){if(siege.startEarly()){recordTutorial('waveStarted');phaseChangedAt=performance.now();view.setPhase('SIEGE');announce('Армия наступает!');}}
 if(e.code==='KeyN'){if(siege.next())announce('Новая подготовка: повреждения сохраняются');}
 if(['Digit5','Digit6','Digit7'].includes(e.code)){
  const index=Number(e.code.slice(-1))-5;const upgrade=(Object.keys(UPGRADES) as Upgrade[])[index];
  announce(siege.unlock(upgrade)?`Исследовано: ${UPGRADES[upgrade].title}`:'Невозможно исследовать: проверь фазу/очки/открытие');
 }
 if(e.code==='KeyI'&&!paused){selectDefense();}
 if(e.code==='KeyO'&&!paused){installNextDefense();}
 if(e.code==='KeyE'){
  if(!siege.unlocked.has('carrot'))announce('Сначала открой Морковомёт: исследование 5');
  else{weapon=weapon==='bolt'?'carrot':'bolt';view.setWeapon(weapon);announce(`Оружие: ${weapon==='carrot'?'Морковомёт':'Арбалет'}`);}
 }
  if(e.code==='KeyF'&&!paused){const hit=view.aim().hit;if(hit)announce(world.repair(id(),hit,siege.repairStrength())?'Блок отремонтирован':'Ошибка: ремонт невозможен');}
 if(e.code==='KeyK')save();if(e.code==='KeyL')load();
 if(e.code==='KeyH'){world.restore(initialWorld);campaign.reset();siege.reset();defenses.reset();gathering.reset();workers.reset();excavation.reset();progression.reset();applyDevelopment();development.refresh();warRoom.refresh();previousPhase=siege.phase;phaseChangedAt=performance.now();view.setPhase(siege.phase);weapon='bolt';view.setWeapon(weapon);player={x:-5,y:0,z:4,vy:0,grounded:true};start=null;guideDistance=0;announce('Замок восстановлен до первоначального состояния');}
 drawHUD();
});
document.addEventListener('keyup',e=>keys.delete(e.code));
view.renderer.domElement.addEventListener('contextmenu',(e:MouseEvent)=>e.preventDefault());
view.renderer.domElement.addEventListener('wheel',(e:WheelEvent)=>{
 if(paused||!lineMode||!verticalMode)return;
 e.preventDefault();columnHeight=Math.max(1,Math.min(10,columnHeight+(e.deltaY<0?1:-1)));
},{passive:false});
function performPointerAction(button:number,shiftKey=false){
 if(paused||architectOpen)return;
 const aim=view.aim();
 if(button===0&&shiftKey){if(shotCooldown<=0){
  const direction=new THREE.Vector3();view.camera.getWorldDirection(direction);
  const origin={x:view.camera.position.x,y:view.camera.position.y,z:view.camera.position.z};
  const shot=siege.shoot(origin,{x:direction.x,y:direction.y,z:direction.z},weapon);
  if(shot.kind!=='inactive'&&shot.kind!=='locked'){
   view.playShot(origin,shot.point,weapon);view.fireWeapon();sfx.play(weapon);
   if(shot.kind==='enemy'){const cross=document.getElementById('cross');cross?.classList.add('hit');setTimeout(()=>cross?.classList.remove('hit'),135);}shotCooldown=weapon==='carrot'?.7:.35;
   announce(shot.kind==='enemy'?`${weapon==='carrot'?'Морковь':'Болт'}: −${shot.damage} HP${shot.knockback?' · отброшен':''}`:
    shot.kind==='wall'?'Выстрел заблокирован стеной':'Промах');
  }else announce(shot.kind==='locked'?'Сначала открой Морковомёт':'Сражение ещё не началось');
 }return;}
 if(button===0){if(aim.hit)announce(world.remove(id(),aim.hit)?'Блок разобран (возврат 0.5 материала)':'Ошибка: разобрать нельзя');start=null;return;}
 if(button!==2)return;
 if(!lineMode){if(aim.place)place([aim.place]);return;}
 if(!start){if(!aim.place){announce('Ошибка: выберите начальный блок');return;}
  start=aim.place;announce(verticalMode?'Колонна: колёсико — высота, ПКМ — установить':'Линия: наведите на конец и нажмите ПКМ');return;}
 const cells=currentPlan();place(cells);start=null;
}
view.renderer.domElement.addEventListener('mousedown',(e:MouseEvent)=>{sfx.unlock();performPointerAction(e.button,e.shiftKey);});
window.addEventListener('pointerdown',()=>sfx.unlock(),{capture:true,once:true});
function installNextDefense(){
 const slot=[0,1,2].find(index=>!defenses.placed.some(d=>d.slot===index));
 if(slot===undefined){announce('Все три оборонительные позиции заняты');return;}
 const kind=selectedDefense;const cost=DEFENSE_COSTS[kind];
 const installed=defenses.install(slot,kind,siege.phase);
 if(installed)recordTutorial('defense');
 announce(installed?`Установлено: ${cost.label} · позиция ${slot+1}`:
  `Нужны ${cost.wood} дерева и ${cost.stone} камня; строительство только в подготовке, свободная позиция обязательна`);
}
function mobileKey(code:string){document.dispatchEvent(new KeyboardEvent('keydown',{code,bubbles:true}));document.dispatchEvent(new KeyboardEvent('keyup',{code,bubbles:true}));}
async function toggleFullscreen(){
 const root=document.documentElement;
 try{
  if(document.fullscreenElement){await document.exitFullscreen();announce('Полный экран выключен');}
  else if(root.requestFullscreen){await root.requestFullscreen({navigationUI:'hide'});announce('Полный экран включён');}
  else announce('Браузер не поддерживает полноэкранный режим. В Chrome открой меню ⋮ → Добавить на главный экран, затем запусти игру с ярлыка.');
 }catch{announce('Браузер заблокировал полный экран. Открой игру с ярлыка на главном экране.');}
}
if(mobileEnabled){
 paused=false;document.body.classList.add('touch-mode');
 const actions:Record<MobileAction,()=>void>={
 defense:()=>installNextDefense(),defenseSelect:()=>selectDefense(),progression:()=>{development.open();},briefing:()=>{warRoom.open();},architect:()=>{architect.toggle();},fullscreen:()=>{void toggleFullscreen();},fire:()=>performPointerAction(0,true),build:()=>performPointerAction(2),remove:()=>performPointerAction(0),
 repair:()=>mobileKey('KeyF'),gather:()=>mobileKey('KeyX'),dig:()=>mobileKey('KeyZ'),digOrder:()=>{document.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyZ',shiftKey:true,bubbles:true}));document.dispatchEvent(new KeyboardEvent('keyup',{code:'KeyZ',bubbles:true}));},jump:()=>{},weapon:()=>mobileKey('KeyE'),
 material:()=>mobileKey(material==='stone'?'Digit2':'Digit1'),shape:()=>mobileKey('Digit3'),rotate:()=>mobileKey('KeyQ'),
 line:()=>mobileKey('KeyB'),worker:()=>mobileKey('KeyJ'),order:()=>mobileKey('KeyT'),priority:()=>mobileKey('KeyY'),cancel:()=>mobileKey('KeyC'),wave:()=>mobileKey('KeyG'),next:()=>mobileKey('KeyN'),
 research:()=>{const options=(Object.keys(UPGRADES) as Upgrade[]);const candidate=options.find(u=>!siege.unlocked.has(u)&&siege.research>=UPGRADES[u].cost);if(candidate)announce(siege.unlock(candidate)?`Исследовано: ${UPGRADES[candidate].title}`:'Исследование недоступно');else announce('Недостаточно знаний или всё открыто');},
 sound:()=>mobileKey('KeyM'),
 tutorial:()=>{tutorial.reset();persistTutorial();guide.refresh();announce('Обучение запущено заново');},
 quality:()=>{const modes:QualityMode[]=['auto','battery','quality'];const mode=modes[(modes.indexOf(quality.mode)+1)%modes.length];view.setResolutionScale(quality.setMode(mode));mobile?.setQualityLabel(({auto:'авто',battery:'экономия',quality:'качество'} as const)[mode]);announce(`Графика: ${mode==='auto'?'авто':mode==='battery'?'экономия батареи':'качество'}`);},
 help:()=>{showHelp=!showHelp;announce('Справка переключена');},
 save:()=>save(),load:()=>load(),menu:()=>mobile?.toggleMenu()
 };
 mobile=installMobileControls((dx,dy)=>{yaw-=dx*.004;pitch=Math.max(-1.4,Math.min(1.4,pitch-dy*.004));syncLook();},a=>{sfx.unlock();actions[a]();});
 mobile.setDefenseLabel(DEFENSE_COSTS[selectedDefense].label);
}
// The very first successful WebGL frame is the release health signal. Do not
// report readiness on module evaluation or merely after creating a canvas.
let firstFrameRendered=false;
view.renderer.domElement.addEventListener('webglcontextlost',event=>{
 event.preventDefault();
 window.dispatchEvent(new Event('lastkeep:contextlost'));
});
let previous=performance.now(),acc=0,ui=0;
function frame(now:number){
 const elapsed=(now-previous)/1000;const dt=Math.min(.05,elapsed);previous=now;
 if(quality.observe(elapsed))view.setResolutionScale(quality.scale);
 frameCounter++;if(now-fpsClock>=1000){displayFps=Math.round(frameCounter*1000/(now-fpsClock));frameCounter=0;fpsClock=now;}
 if(!development.isOpen()&&!warRoom.isOpen()&&!['RESULT','VICTORY','DEFEAT'].includes(siege.phase)&&(!paused||architectOpen)){
  const joystick=mobile?.getMove();
  const forward=architectOpen?0:joystick?-joystick.y:Number(keys.has('KeyW'))-Number(keys.has('KeyS'));
  const side=architectOpen?0:joystick?joystick.x:Number(keys.has('KeyD'))-Number(keys.has('KeyA'));
  const dx=-Math.sin(yaw)*forward+Math.cos(yaw)*side;
  const dz=-Math.cos(yaw)*forward-Math.sin(yaw)*side;
  const wasX=player.x,wasZ=player.z;
  player=stepPlayer(world,player,{dx,dz,jump:!architectOpen&&(keys.has('Space')||!!mobile?.isHeld('jump'))},dt,excavation);
  if(!architectOpen){const distance=Math.hypot(player.x-wasX,player.z-wasZ);if(distance<.7)guideDistance+=distance;if(guideDistance>=2)recordTutorial('moved');}
  shotCooldown=Math.max(0,shotCooldown-dt);
  if(!architectOpen&&mobile?.isHeld('fire')&&shotCooldown<=0&&now-lastMobileShot>100){lastMobileShot=now;performPointerAction(0,true);}
  acc+=dt;while(acc>=1/60){siege.step(1/60);defenses.step(1/60,siege.phase,siege.raiders,siege.events,()=>{siege.kills++;});workers.step(1/60,siege.phase,player);acc-=1/60;}
  if(defenses.placed.length)recordTutorial('defense');
  if(workers.workers.length)recordTutorial('workerHired');
  if(siege.wave>=1)recordTutorial('waveStarted');
  if(siege.wave>=1&&(siege.phase==='RESULT'||siege.phase==='VICTORY'))recordTutorial('waveWon');
  if(siege.phase!==previousPhase){
   // Record exactly once per completed assault before autosaving.
   if(siege.phase==='RESULT'||siege.phase==='VICTORY'||siege.phase==='DEFEAT')campaign.record(siege,world,defenses);
   warRoom.refresh();
   phaseChangedAt=now;view.setPhase(siege.phase);
   if(siege.phase==='WARNING'){announce('⚠ Разведчики: враги уже у ворот!');sfx.play('alarm');}
   else if(siege.phase==='RESULT'||siege.phase==='VICTORY'){
    announce(`Осада отбита! +${siege.lastReport.researchEarned} знаний · ${siege.lastReport.kills} убийств. Исследования: 5/6/7`);
    save(true);
   }else if(siege.phase==='DEFEAT')announce('Нексус пал — забег окончен. H — начать заново.');
   previousPhase=siege.phase;
  }
  for(const evt of siege.events.splice(0)){
   if(evt.kind==='pudding'&&evt.from){view.playPudding(evt.from,evt.point);sfx.play('carrot');}
   else view.playImpact(evt.point,evt.kind);
   if(evt.kind==='trap')sfx.play('trap');else if(evt.kind==='hit')sfx.play('hit');
   else if(evt.kind==='kill')sfx.play('kill');else if(evt.kind==='nexus'){sfx.play('nexus');view.flashNexus();}
   else if(evt.kind==='breach')sfx.play('breach');
  }
  // Consume defense presentation events once; do not allow unbounded accumulation between waves.
  for(const evt of defenses.events.splice(0)){
   view.playDefense(evt.kind,{x:evt.x,y:1.05,z:evt.z},{x:evt.targetX,y:.8,z:evt.targetZ});
   sfx.play(evt.kind==='cheeseMortar'?'cheese':evt.kind==='syrupSprayer'?'syrup':'turret');
  }
 }
 view.camera.position.set(player.x,player.y+1.58,player.z);
 view.syncDefenses(defenses.placed);view.syncTrenches(excavation.cells(),excavation.revision);view.syncOrders(workers.orders);view.syncRaiders(siege.raiders,now);view.syncWorkers(workers.workers,now);view.syncDeposits(gathering.deposits,now);view.tickEffects(dt);view.tickFeedback(dt,siege.nexus);view.animateWeapon(dt,now);
 if(now-ui>(mobileEnabled?180:100)){preview();drawHUD();guide.setSuppressed(architectOpen||development.isOpen()||warRoom.isOpen()||!!mobile?.isMenuOpen()||siege.phase==='RESULT'||siege.phase==='DEFEAT'||siege.phase==='VICTORY');ui=now;}
 view.render(now);
 if(!firstFrameRendered){
  firstFrameRendered=true;
  window.dispatchEvent(new Event('lastkeep:ready'));
 }
 requestAnimationFrame(frame);
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){keys.clear();}previous=performance.now();acc=0;quality.reset();});
drawHUD();requestAnimationFrame(frame);
