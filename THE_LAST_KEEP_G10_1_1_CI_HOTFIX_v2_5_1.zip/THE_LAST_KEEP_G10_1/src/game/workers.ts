import {World,inBounds,key,maxHP,type Cell,type Material,type Shape,type Orientation} from '../world/model.ts';
import {isShape,isOrientation} from '../world/shapes.ts';
import type {Phase} from './siege.ts';
import type {Deposit} from './gathering.ts';
import {Gathering} from './gathering.ts';
import {findWorkerRoute} from '../ai/workerNavigation.ts';
import type {Excavation} from '../world/excavation.ts';
import type {Waypoint} from '../ai/navigation.ts';

export const STOCKPILE={x:4,z:3} as const;
export const MAX_WORKERS=2;
export type WorkMode='balanced'|'gather'|'build'|'repair';
export const WORK_MODES:readonly WorkMode[]=['balanced','gather','build','repair'];
export type Job='gather'|'deliver'|'build'|'repair'|'retreat'|'dig';
export type DigOrder={id:number;x:number;z:number};
export type Order={id:number;cell:Cell;material:Material;shape:Shape;dir:Orientation};
export type Worker={
 id:number;x:number;z:number;job:Job|null;targetId:string|null;
 cargo:Material|null;amount:number;status:string;
 workTime:number;retry:number;route:Waypoint[];routeRevision:number;site:Waypoint|null;
};
export type WorkerReport={ok:boolean;message:string;count?:number};
type SavedWorker=Omit<Worker,'route'|'routeRevision'|'site'>;
type WorkerSave={version:1|2;mode:WorkMode;seq:number;orderSeq:number;workers:SavedWorker[];orders:Order[];digOrders?:DigOrder[]};

/** Minimal explicit labor simulation: physical deposits -> carried cargo -> stockpile,
 * repair consumes stock, queued masonry consumes stock when actually placed.
 * No resource is credited on pickup; no materials are created by research.
 */
export class Workers{
 readonly world:World;readonly gathering:Gathering;readonly excavation?:Excavation;
 workers:Worker[]=[];orders:Order[]=[];digOrders:DigOrder[]=[];mode:WorkMode='balanced';
 /** Derived from progression, not saved with each actor. */
 logisticsLevel=0;masonryLevel=0;
 private seq=0;private orderSeq=0;
 constructor(world:World,gathering:Gathering,excavation?:Excavation){this.world=world;this.gathering=gathering;this.excavation=excavation;}
 reset(){this.workers=[];this.orders=[];this.digOrders=[];this.mode='balanced';this.seq=0;this.orderSeq=0;}
 hire(phase:Phase,wave:number):WorkerReport{
  if(phase==='SIEGE'||phase==='WARNING'||phase==='DEFEAT'||phase==='VICTORY')return {ok:false,message:'Нельзя нанимать во время опасности'};
  if(wave<1)return {ok:false,message:'Первый рабочий доступен после первой осады'};
  if(this.workers.length>=MAX_WORKERS)return {ok:false,message:'Предел: два рабочих'};
  const fee=this.workers.length===0?0:10;
  if(this.world.resources.wood<fee)return {ok:false,message:`Второй рабочий требует ${fee} дерева`};
  this.world.resources.wood-=fee;
  const w:Worker={id:++this.seq,x:STOCKPILE.x+(this.workers.length?1:0),z:STOCKPILE.z,
   job:null,targetId:null,cargo:null,amount:0,status:'Ожидает приказов',workTime:0,retry:0,route:[],routeRevision:-1,site:null};
  this.workers.push(w);
  return {ok:true,message:fee?'Нанят второй рабочий (−10 дерева)':'К отряду присоединился первый рабочий'};
 }
 setMode(mode:WorkMode){if(!WORK_MODES.includes(mode))return false;this.mode=mode;
  for(const worker of this.workers)if(worker.job!=='deliver'&&worker.job!=='retreat')this.release(worker);
  return true;
 }
 cycleMode():WorkMode{const next=WORK_MODES[(WORK_MODES.indexOf(this.mode)+1)%WORK_MODES.length];this.setMode(next);return next;}
 /** Order is NOT an instant building purchase: deposits must supply enough stone/wood.
  * Partial lines are accepted as separate atomic, idempotent single-block jobs.
  * Shape support is rechecked at execution, so unsupported blocks must wait.
  */
 queueBuild(cells:Cell[],material:Material,shape:Shape,dir:Orientation):WorkerReport{
  if(!this.workers.length)return {ok:false,message:'Сначала найми рабочего (J)'};
  if(!Array.isArray(cells)||!cells.length||cells.length>24||!['stone','wood'].includes(material)||!isShape(shape)||!isOrientation(dir))
   return {ok:false,message:'Недопустимый чертёж'};
  const seen=new Set<string>();
  for(const c of cells){if(!inBounds(c))return {ok:false,message:'Чертёж за пределами мира'};
   const k=key(c.x,c.y,c.z);
   if((c.y===0&&(this.excavation?.depth(c.x,c.z)??0)>0)||seen.has(k)||this.world.get(c.x,c.y,c.z)||this.orders.some(o=>key(o.cell.x,o.cell.y,o.cell.z)===k))
    return {ok:false,message:'Чертёж пересекается с существующим блоком или заданием'};
   if(Math.abs(c.x-9)<=1&&Math.abs(c.z)<=1&&c.y<=1)return {ok:false,message:'Нельзя застроить Нексус'};
   seen.add(k);
  }
  if(this.orders.length+cells.length>60)return {ok:false,message:'Очередь ограничена 60 блоками'};
  const sorted=[...cells].sort((a,b)=>a.y-b.y);
  for(const c of sorted)this.orders.push({id:++this.orderSeq,cell:{...c},material,shape,dir});
  return {ok:true,message:`Чертёж добавлен: ${cells.length} блок(а). Материалы спишутся при постройке.`,count:cells.length};
 }
 /** Queue dig operations: no instant reward, no work during siege. */
 queueDig(cells:{x:number;z:number}[]):WorkerReport{
  if(!this.excavation)return {ok:false,message:'Земляные работы недоступны'};
  if(!this.workers.length)return {ok:false,message:'Нужен хотя бы один рабочий'};
  if(!Array.isArray(cells)||!cells.length||cells.length>12||this.digOrders.length+cells.length>40)
   return {ok:false,message:'Очередь земляных работ: до 12 за раз, 40 всего'};
  const seen=new Set<string>();
  for(const c of cells){if(!c||!this.excavation.canDig(c.x,c.z).ok||seen.has(`${c.x},${c.z}`)||
   this.digOrders.some(o=>o.x===c.x&&o.z===c.z))return {ok:false,message:'Клетка недоступна или уже запланирована'};
   seen.add(`${c.x},${c.z}`);
  }
  for(const c of cells)this.digOrders.push({id:++this.orderSeq,x:c.x,z:c.z});
  return {ok:true,message:`Рабочие получили ${cells.length} поручений на раскопки`,count:cells.length};
 }
 clearOrders(){const removed=this.orders.length+this.digOrders.length;this.orders=[];this.digOrders=[];
  for(const w of this.workers)if(w.job==='build'||w.job==='dig')this.release(w);
  return removed;
 }
 /** Keep a worker's cargo through an interrupted retreat or save/load. */
 private release(w:Worker){w.job=null;w.targetId=null;w.status='Ожидает приказов';w.workTime=0;w.route=[];w.routeRevision=-1;w.retry=0;w.site=null;}
 private dispatch(w:Worker,job:Job,targetId:string|null,status:string){
  w.job=job;w.targetId=targetId;w.status=status;w.route=[];w.routeRevision=-1;w.retry=0;w.site=null;w.workTime=0;
 }
 private assigned(job:Job,id:string){return this.workers.some(w=>w.job===job&&w.targetId===id);}
 private needs(material:Material){
  return this.world.resources[material]<(material==='stone'?110:58)
   ||this.orders.filter(o=>o.material===material).length>this.world.resources[material];
 }
 private selectDeposit(w:Worker):Deposit|null{
  const viable=this.gathering.deposits.filter(d=>d.remaining>0&&!this.assigned('gather',d.id));
  if(!viable.length)return null;
  const preferred=viable.filter(d=>this.needs(d.material));
  const options=this.mode==='gather'?viable:preferred;
  if(!options.length)return null;
  return [...options].sort((a,b)=>{
   const priority=(d:Deposit)=>(this.needs(d.material)?-40:0)+Math.hypot(w.x-d.x,w.z-d.z);
   return priority(a)-priority(b);
  })[0];
 }
 private choose(w:Worker){
  if(w.cargo&&w.amount>0){this.dispatch(w,'deliver',null,'Доставляет материалы');return;}
  if(this.mode==='balanced'||this.mode==='build'){
   const dig=this.digOrders.find(o=>!this.assigned('dig',String(o.id))&&this.excavation?.canDig(o.x,o.z).ok);
   if(dig){this.dispatch(w,'dig',String(dig.id),'Идёт копать ров');return;}
   const order=this.orders.find(o=>!this.assigned('build',String(o.id))&&this.world.resources[o.material]>=1&&
    this.world.checkBuild([o.cell],o.material).ok);
   if(order){this.dispatch(w,'build',String(order.id),'Строит по чертежу');return;}
  }
  if(this.mode==='balanced'||this.mode==='repair'){
   const candidates=[...this.world.blocks].filter(([k,b])=>{
    const [,y]=k.split(',').map(Number);
    return y<=2&&b.hp<maxHP(b.material)&&this.world.resources[b.material]>=1&&!this.assigned('repair',k);
   });
   candidates.sort((a,b)=>{
    const [ax,,az]=a[0].split(',').map(Number),[bx,,bz]=b[0].split(',').map(Number);
    return Math.hypot(w.x-ax,w.z-az)-Math.hypot(w.x-bx,w.z-bz);
   });
   if(candidates.length){this.dispatch(w,'repair',candidates[0][0],'Ремонтирует укрепления');return;}
  }
  if(this.mode==='balanced'||this.mode==='gather'){
   const d=this.selectDeposit(w);
   if(d){this.dispatch(w,'gather',d.id,'Идёт к месторождению');return;}
  }
  w.status=this.mode==='build'&&(this.orders.length||this.digOrders.length)?'Ждёт материалы, опору или доступ к рву':
   this.mode==='gather'?'Нет подходящих месторождений':'Нет заданий';
 }
 private travel(w:Worker,goal:Waypoint,reach:number,dt:number){
  if(Math.hypot(w.x-goal.x,w.z-goal.z)<=reach)return 'arrived' as const;
  w.retry=Math.max(0,w.retry-dt);
  if(w.retry>0)return 'blocked' as const;
  const terrainRevision=this.world.revision*10000+(this.excavation?.revision??0);
  if(w.routeRevision!==terrainRevision||!w.route.length){
   const route=findWorkerRoute(this.world,{x:w.x,z:w.z},goal,reach,this.excavation);
   w.routeRevision=terrainRevision;w.route=route??[];
   if(route===null){w.status='⛔ Нет прохода — нужен свободный путь';w.retry=1.8;return 'blocked' as const;}
  }
  while(w.route.length&&Math.hypot(w.x-w.route[0].x,w.z-w.route[0].z)<.07)w.route.shift();
  if(!w.route.length){
   // BFS ends at grid-cell centres, but the agent may still be ~0.1 m
   // outside interaction reach. Close this small gap rather than deadlocking.
   const d=Math.hypot(w.x-goal.x,w.z-goal.z);
   if(d<=reach)return 'arrived' as const;
   const step=Math.min(2.35*dt,d-reach+.015);
   const nx=w.x+(goal.x-w.x)/d*step,nz=w.z+(goal.z-w.z)/d*step;
   if(this.world.groundObstructions(Math.round(nx),Math.round(nz)).length||(this.excavation?.depth(Math.round(nx),Math.round(nz))??0)>=2){w.retry=1.8;w.status='⛔ Путь загорожен';return 'blocked' as const;}
   w.x=nx;w.z=nz;w.routeRevision=-1;
   return Math.hypot(w.x-goal.x,w.z-goal.z)<=reach?'arrived' as const:'approaching' as const;
  }
  const p=w.route[0];
  if(this.world.groundObstructions(p.x,p.z).length||(this.excavation?.depth(p.x,p.z)??0)>=2){w.routeRevision=-1;w.route=[];return 'approaching' as const;}
  const dx=p.x-w.x,dz=p.z-w.z,length=Math.hypot(dx,dz),speed=Math.min(length,2.35*dt/(1+(this.excavation?.depth(Math.round(w.x),Math.round(w.z))??0)*.7));
  if(length>0){w.x+=dx/length*speed;w.z+=dz/length*speed;}
  return Math.hypot(w.x-goal.x,w.z-goal.z)<=reach?'arrived' as const:'approaching' as const;
 }
 private workSite(w:Worker,c:Cell):Waypoint|null{
  const sites=[{x:c.x+1,z:c.z},{x:c.x-1,z:c.z},{x:c.x,z:c.z+1},{x:c.x,z:c.z-1}];
  const routes=sites.filter(p=>inBounds({x:p.x,y:0,z:p.z})&&!this.world.groundObstructions(p.x,p.z).length&&(this.excavation?.depth(p.x,p.z)??0)<2)
   .map(p=>({p,route:findWorkerRoute(this.world,w,p,.15,this.excavation)}))
   .filter((r):r is {p:Waypoint;route:Waypoint[]}=>r.route!==null);
  routes.sort((a,b)=>a.route.length-b.route.length);
  return routes[0]?.p??null;
 }
 private deliver(w:Worker,dt:number){
  const status=this.travel(w,STOCKPILE,1.05,dt);
  if(status!=='arrived')return;
  if(w.cargo&&w.amount>0)this.world.resources[w.cargo]+=w.amount;
  w.cargo=null;w.amount=0;this.release(w);
 }
 /** Step after Siege.step; paused phases stop worker actions. */
 step(dt:number,phase:Phase,player?:{x:number;y:number;z:number}){
  if(!Number.isFinite(dt)||dt<=0)return;dt=Math.min(dt,.1);
  for(const w of this.workers){
   if(phase==='SIEGE'||phase==='WARNING'){
    if(w.job!=='retreat'){this.dispatch(w,'retreat',null,'Отступает на склад');}
    this.deliver(w,dt);
    // During a wave a worker must never resume harvesting/repairing.
    if(w.job===null)w.status='В укрытии';
    continue;
   }
   if(phase==='DEFEAT'||phase==='VICTORY'||phase==='RESULT'){
    w.status='Ждёт новой подготовки';continue;
   }
   if(!w.job)this.choose(w);
   if(!w.job)continue;
   if(w.job==='deliver'||w.job==='retreat'){this.deliver(w,dt);continue;}
   if(w.job==='gather'){
    const d=this.gathering.deposits.find(p=>p.id===w.targetId);
    if(!d||d.remaining<=0){this.release(w);continue;}
    const status=this.travel(w,d,1.4,dt);
    if(status==='arrived'){
     w.status='⛏ Добывает';w.workTime+=dt;
     if(w.workTime>=(this.logisticsLevel>=2?1.2:1.6)){const amount=Math.min(d.material==='stone'?8+2*this.logisticsLevel:6+2*this.logisticsLevel,d.remaining);
      d.remaining-=amount;w.cargo=d.material;w.amount=amount;
      this.dispatch(w,'deliver',null,'Несёт добычу на склад');
     }
    }else if(status==='approaching')w.status='Идёт к месторождению';
    continue;
   }
   if(w.job==='dig'){
    const order=this.digOrders.find(o=>String(o.id)===w.targetId);
    if(!order||!this.excavation?.canDig(order.x,order.z).ok){
     this.digOrders=this.digOrders.filter(o=>o.id!==order?.id);this.release(w);continue;
    }
    if(!w.site)w.site=this.workSite(w,{x:order.x,y:0,z:order.z});
    if(!w.site){w.status='⛔ Нет подхода к месту раскопок';continue;}
    const status=this.travel(w,w.site,.17,dt);
    if(status==='arrived'){
     w.status='⛏ Копает траншею';w.workTime+=dt;
     if(w.workTime>=(this.logisticsLevel>=2?1.4:1.8)){const result=this.excavation.dig(order.x,order.z,false);
      this.digOrders=this.digOrders.filter(o=>o.id!==order.id);
      if(result.ok){w.cargo='stone';w.amount=result.stone;this.dispatch(w,'deliver',null,'Несёт камень из рва');}
      else this.release(w);
     }
    }else if(status==='approaching')w.status='Подходит к раскопкам';
    continue;
   }
   if(w.job==='build'){
    const order=this.orders.find(o=>String(o.id)===w.targetId);
    if(!order||this.world.get(order.cell.x,order.cell.y,order.cell.z)||
     (order.cell.y===0&&(this.excavation?.depth(order.cell.x,order.cell.z)??0)>0)){this.orders=this.orders.filter(o=>o.id!==order?.id);this.release(w);continue;}
    if(this.world.resources[order.material]<1){this.release(w);continue;}
    // A delayed worker order must never enclose the player's body.
    if(player&&Math.abs(player.x-order.cell.x)<.85&&Math.abs(player.z-order.cell.z)<.85&&
     order.cell.y<player.y+1.8&&order.cell.y+1>player.y){
     w.status='Подожди: игрок стоит в месте строительства';continue;
    }
    if(!w.site)w.site=this.workSite(w,order.cell);
    if(!w.site){w.status='⛔ Нет прохода к чертежу';continue;}
    const status=this.travel(w,w.site,.17,dt);
    if(status==='arrived'){
     w.status='⚒ Кладёт блок';w.workTime+=dt;
     if(w.workTime>=(this.logisticsLevel>=2?.85:1.1)){const result=this.world.build(`worker-build-${w.id}-${order.id}`, [order.cell],order.material,order.shape,order.dir);
      if(result.ok)this.orders=this.orders.filter(o=>o.id!==order.id);
      this.release(w);
     }
    }else if(status==='approaching')w.status='Идёт к чертежу';
    continue;
   }
   if(w.job==='repair'){
    const coords=w.targetId?.split(',').map(Number);
    if(!coords||coords.length!==3){this.release(w);continue;}
    const [x,y,z]=coords,b=this.world.get(x,y,z);
    if(!b||b.hp>=maxHP(b.material)||this.world.resources[b.material]<1){this.release(w);continue;}
    if(!w.site)w.site=this.workSite(w,{x,y,z});
    if(!w.site){w.status='⛔ Нет прохода к ремонту';continue;}
    const status=this.travel(w,w.site,.17,dt);
    if(status==='arrived'){
     w.status='🔨 Чинит каменную кладку';w.workTime+=dt;
     if(w.workTime>=1.4){this.world.repair(`worker-repair-${w.id}-${this.orderSeq++}`,{x,y,z},30+15*this.masonryLevel);this.release(w);}
    }else if(status==='approaching')w.status='Идёт чинить';
   }
  }
 }
 snapshot():string{
  return JSON.stringify({version:2,mode:this.mode,seq:this.seq,orderSeq:this.orderSeq,
   workers:this.workers.map(({route,routeRevision,site,...rest})=>rest),orders:this.orders,digOrders:this.digOrders} satisfies WorkerSave);
 }
 /** All-or-nothing restore. Workers retain in-flight cargo, never create it twice.
  * Routes are recomputed using the restored world and the restored deposits. */
 restore(json:string){
  const raw=JSON.parse(json) as WorkerSave;
  if(![1,2].includes(raw.version)||!WORK_MODES.includes(raw.mode)||!Number.isSafeInteger(raw.seq)||raw.seq<0||
   !Number.isSafeInteger(raw.orderSeq)||raw.orderSeq<0||!Array.isArray(raw.workers)||raw.workers.length>MAX_WORKERS||
   !Array.isArray(raw.orders)||raw.orders.length>60)throw Error('Invalid worker save');
  const ids=new Set<number>(),orderIds=new Set<number>(),positions=new Set<string>();
  const orders:Order[]=raw.orders.map(o=>{
   if(!o||!Number.isSafeInteger(o.id)||o.id<1||o.id>raw.orderSeq||orderIds.has(o.id)||!o.cell||!inBounds(o.cell)||
    !['stone','wood'].includes(o.material)||!isShape(o.shape)||!isOrientation(o.dir)||
    this.world.get(o.cell.x,o.cell.y,o.cell.z)||positions.has(key(o.cell.x,o.cell.y,o.cell.z)))throw Error('Invalid worker orders');
   orderIds.add(o.id);positions.add(key(o.cell.x,o.cell.y,o.cell.z));return {...o,cell:{...o.cell}};
  });
  const digs=raw.version===2?raw.digOrders:[];
  if(!Array.isArray(digs)||digs.length>40)throw Error('Invalid dig orders');
  const digIds=new Set<number>(),digKeys=new Set<string>();
  const digOrders:DigOrder[]=digs.map(d=>{
   if(!this.excavation||!d||!Number.isSafeInteger(d.id)||d.id<1||d.id>raw.orderSeq||
    digIds.has(d.id)||orderIds.has(d.id)||!Number.isInteger(d.x)||!Number.isInteger(d.z)||
    !this.excavation.canDig(d.x,d.z).ok||digKeys.has(`${d.x},${d.z}`))throw Error('Invalid dig orders');
   digIds.add(d.id);digKeys.add(`${d.x},${d.z}`);return {...d};
  });
  const jobs:(Job|null)[]=[null,'gather','deliver','build','repair','retreat','dig'];
  const people:Worker[]=raw.workers.map(p=>{
   if(!p||!Number.isSafeInteger(p.id)||p.id<1||p.id>raw.seq||ids.has(p.id)||
    ![p.x,p.z,p.workTime,p.retry,p.amount].every(Number.isFinite)||Math.abs(p.x)>22||Math.abs(p.z)>22||
    p.amount<0||p.amount>12||!Number.isInteger(p.amount)||p.workTime<0||p.workTime>2||p.retry<0||p.retry>2||
    !jobs.includes(p.job)||!['stone','wood',null].includes(p.cargo)||
    ((p.cargo===null)!==(p.amount===0))||typeof p.status!=='string'||p.status.length>100||
    !(p.targetId===null||typeof p.targetId==='string'&&p.targetId.length<=60))throw Error('Invalid worker actor');
   if(p.job==='dig'&&!digOrders.some(o=>String(o.id)===p.targetId))throw Error('Missing dig order');
   if(p.job==='build'&&!orders.some(o=>String(o.id)===p.targetId))throw Error('Missing building order');
   if(p.job==='gather'&&!this.gathering.deposits.some(d=>d.id===p.targetId))throw Error('Missing deposit');
   ids.add(p.id);
   return {...p,route:[],routeRevision:-1,site:null};
  });
  this.mode=raw.mode;this.seq=raw.seq;this.orderSeq=raw.orderSeq;this.orders=orders;this.digOrders=digOrders;this.workers=people;
 }
}
