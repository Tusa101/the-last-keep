/** THE LAST KEEP vertical slice: a three-wave run has an auditable scorecard.
 * The journal never changes gameplay resources or siege results. */
import type {Siege,Phase} from './siege.ts';
import type {Defenses} from './defenses.ts';
import type {World} from '../world/model.ts';

export type WaveOutcome='held'|'fallen';
export type WaveRecord={wave:1|2|3;outcome:WaveOutcome;kills:number;enemies:number;
 nexus:number;nexusLost:number;timeRemaining:number;defenses:number;standingBlocks:number;score:number};
export type CampaignRating='legend'|'veteran'|'recruit'|'fallen';
const integer=(v:unknown,a:number,b:number):v is number=>Number.isInteger(v)&&Number(v)>=a&&Number(v)<=b;
const number=(v:unknown,a:number,b:number):v is number=>typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b;
const clamp=(v:number,a:number,b:number)=>Math.min(b,Math.max(a,v));

/** Victory requires three successful waves; an individual defeat is never credited as victory. */
export function waveScore(outcome:WaveOutcome,nexus:number,kills:number,enemies:number):number{
 if(outcome==='fallen')return 0;
 // 40 pts for holding, 40 for surviving Nexus HP, 20 for eliminating enemies.
 // Surviving the timer is a valid tactic: escaped enemies lower both HP and kill score.
 return Math.round(clamp(40+40*clamp(nexus,0,100)/100+20*clamp(kills/Math.max(1,enemies),0,1),0,100));
}
export class CampaignJournal{
 readonly records:WaveRecord[]=[];
 record(siege:Siege,world:World,defenses:Defenses):boolean{
  if(!['RESULT','VICTORY','DEFEAT'].includes(siege.phase)||siege.wave<1||siege.wave>3)return false;
  if(this.records.some(r=>r.wave===siege.wave))return false;
  const report=siege.lastReport;
  const outcome:WaveOutcome=siege.phase==='DEFEAT'?'fallen':'held';
  const enemies=siege.raiders.length;
  const kills=clamp(report.kills,0,enemies);
  const nexusLost=clamp(report.nexusLost,0,100);
  this.records.push({wave:siege.wave as 1|2|3,outcome,kills,enemies,
   nexus:siege.nexus,nexusLost,timeRemaining:Math.max(0,Math.round(siege.time)),
   defenses:defenses.placed.length,standingBlocks:world.blocks.size,
   score:waveScore(outcome,siege.nexus,kills,enemies)});
  return true;
 }
 rating():CampaignRating{
  if(this.records.some(r=>r.outcome==='fallen'))return 'fallen';
  if(this.records.length!==3||this.records[2]?.wave!==3)return 'recruit';
  const mean=this.records.reduce((sum,r)=>sum+r.score,0)/3;
  return mean>=90?'legend':mean>=75?'veteran':'recruit';
 }
 totalScore():number{return this.records.reduce((s,r)=>s+r.score,0);}
 reset(){this.records.length=0;}
 snapshot():string{return JSON.stringify({version:1,records:this.records});}
 /** Strict validation before mutating current run. Old saves may omit this journal entirely. */
 restore(json:string){const s=JSON.parse(json) as {version:number;records:WaveRecord[]};
  if(s.version!==1||!Array.isArray(s.records)||s.records.length>3)throw Error('Invalid campaign journal');
  const fresh:WaveRecord[]=[];
  for(const r of s.records){
   if(!r||!integer(r.wave,1,3)||r.wave!==fresh.length+1||!['held','fallen'].includes(r.outcome)||
    !integer(r.kills,0,30)||!integer(r.enemies,0,30)||r.kills>r.enemies||
    !integer(r.nexus,0,100)||!integer(r.nexusLost,0,100)||!integer(r.timeRemaining,0,100)||
    !integer(r.defenses,0,3)||!integer(r.standingBlocks,0,30000)||!integer(r.score,0,100)||
    r.score!==waveScore(r.outcome,r.nexus,r.kills,r.enemies)||
    (r.outcome==='fallen'&&r.nexus!==0)||
    (fresh.some(p=>p.outcome==='fallen'))
   )throw Error('Invalid campaign record');
   fresh.push({...r});
  }
  this.records.splice(0,this.records.length,...fresh);
 }
}
export const ratingNames:Record<CampaignRating,string>={
 legend:'ЛЕГЕНДА КРЕПОСТИ',veteran:'ОПЫТНЫЙ КОМЕНДАНТ',recruit:'СТОЙКИЙ ЗАЩИТНИК',fallen:'КРЕПОСТЬ ПАЛА'
};
