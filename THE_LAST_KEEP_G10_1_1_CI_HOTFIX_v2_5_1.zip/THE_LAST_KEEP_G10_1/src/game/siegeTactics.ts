import {World,type Cell} from '../world/model.ts';
import {normalize,traceShot} from './combat.ts';
/** A pudding bombardier requires actual line-of-sight to the first masonry cell.
 * This is intentionally direct-fire artillery: castle blocks shield each other.
 * Stable distance/key ordering makes attacks reproducible and testable. */
export function bombardmentTarget(world:World,x:number,z:number,range=5.5):Cell|null{
 const options:{cell:Cell;d:number}[]=[];
 for(const [id] of world.blocks){
  const [bx,y,bz]=id.split(',').map(Number);
  if(y>1)continue;const d=Math.hypot(bx-x,bz-z);
  if(d>=1.3&&d<=range)options.push({cell:{x:bx,y,z:bz},d});
 }
 options.sort((a,b)=>a.d-b.d||a.cell.x-b.cell.x||a.cell.z-b.cell.z||a.cell.y-b.cell.y);
 const origin={x,y:1.25,z};
 for(const {cell} of options){
  const center={x:cell.x,y:cell.y+.55,z:cell.z};
  const dir=normalize({x:center.x-origin.x,y:center.y-origin.y,z:center.z-origin.z});
  if(!dir)continue;
  const hit=traceShot(world,origin,dir,[],range+1);
  if(hit.kind==='wall'&&hit.cell?.x===cell.x&&hit.cell?.y===cell.y&&hit.cell?.z===cell.z)return cell;
 }
 return null;
}
