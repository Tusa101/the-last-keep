/** Three authored attacks with readable counters, rather than random enemy spam.
 * Wave one teaches the crossbow. Wave two introduces trench-vaulting scouts.
 * Wave three forces the player to defend both fronts against siege artillery. */
export type AssaultFront='west'|'north';
export type Intel={wave:1|2|3;title:string;brief:string;fronts:AssaultFront[];
 jellies:number;brutes:number;hoppers:number;bombardiers:number};
export const ENCOUNTERS:readonly Intel[]=[
 {wave:1,title:'ПРОБА ВОРОТ',brief:'Четыре желейных рекрута с запада. Восстанови пролом и пристреляйся.',fronts:['west'],jellies:4,brutes:0,hoppers:0,bombardiers:0},
 {wave:2,title:'ПРЫГУНЫ С КАЗЁННОЙ ПЕЧАТЬЮ',brief:'Запад: карамельный таран и трое пружинных гонцов! Прыгуны не боятся рвов — встречай их огнём.',fronts:['west'],jellies:3,brutes:1,hoppers:3,bombardiers:0},
 {wave:3,title:'ПУДИНГОВЫЙ ОБСТРЕЛ',brief:'Запад и север! Два пудинговых артиллериста стреляют по стенам. Отстреливай артиллерию прежде, чем откроется пролом.',fronts:['west','north'],jellies:4,brutes:1,hoppers:3,bombardiers:2}
];
export function waveIntel(wave:number):Intel{return ENCOUNTERS[Math.max(0,Math.min(2,Math.floor(wave)-1))];}
export function nextIntel(currentWave:number):Intel|null{return currentWave>=3?null:waveIntel(currentWave+1);}
/** All spawn cells are outside the curtain walls; wave three attacks on two axes. */
export function raiderSpawn(wave:number,index:number,count:number):{x:number;z:number;front:AssaultFront}{
 if(wave>=3&&index>=Math.ceil(count/2)){
  const lane=index-Math.ceil(count/2);
  return {x:-3+lane%4*2,z:-17-Math.floor(lane/4),front:'north'};
 }
 return {x:-17-Math.floor(index/3),z:(index%3-1)*2,front:'west'};
}
export function clockLabel(seconds:number){const n=Math.max(0,Math.ceil(Number.isFinite(seconds)?seconds:0));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;}
export function phaseLabel(phase:string):string{return ({PREP:'ПОДГОТОВКА',WARNING:'АРМИЯ БЛИЗКО',SIEGE:'ОСАДА',RESULT:'ОТБИТО',VICTORY:'ПОБЕДА',DEFEAT:'НЕКСУС ПАЛ'} as Record<string,string>)[phase]??phase;}
