import type {VfxKind} from './vfx.ts';
export type WorldFlash={x:number;y:number;z:number;kind:VfxKind};
/** Compare authoritative snapshots; no mutation and no visual on loading a saved world.
 * All visual work is bounded even if a long unsupported wall chain collapses.
 */
export function blockFeedback(before:ReadonlyMap<string,number>,after:ReadonlyMap<string,number>,reason:string,limit=9):WorldFlash[]{
 const result:WorldFlash[]=[];
 if(reason==='load'||!['build','damage','repair','remove'].includes(reason))return result;
 const budget=Math.max(0,Math.min(30,Math.floor(Number.isFinite(limit)?limit:0)));
 const emit=(id:string,kind:VfxKind)=>{
  if(result.length>=budget)return;
  const parts=id.split(',').map(Number);
  if(parts.length!==3||parts.some(n=>!Number.isFinite(n)))return;
  result.push({x:parts[0],y:parts[1]+.5,z:parts[2],kind});
 };
 for(const [id,hp] of after){
  if(result.length>=budget)break;
  if(!before.has(id)&&reason==='build')emit(id,'build');
  else if(before.has(id)&&hp!==before.get(id))emit(id,hp>before.get(id)!?'repair':'hit');
 }
 for(const id of before.keys()){
  if(result.length>=budget)break;
  if(!after.has(id))emit(id,'breach');
 }
 return result;
}
