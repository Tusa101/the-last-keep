import {waveIntel,raiderSpawn} from './encounters.ts';
import {bombardmentTarget} from './siegeTactics.ts';
import {World,inBounds} from '../world/model.ts';
import {Enemy} from '../ai/breach.ts';
import type {Excavation} from '../world/excavation.ts';
import {traceShot,normalize,type Hit,type Vec3} from './combat.ts';
export type Phase='PREP'|'WARNING'|'SIEGE'|'RESULT'|'VICTORY'|'DEFEAT';
export type RaiderKind='jelly'|'brute'|'hopper'|'bombardier';
export type Weapon='bolt'|'carrot';
export type Upgrade='carrot'|'trap'|'repair';
export const UPGRADES:Record<Upgrade,{title:string;description:string;cost:number}>={
 carrot:{title:'Пружинный морковомёт',description:'Слабый урон, отталкивание и оглушение',cost:20},
 trap:{title:'Усиленная ловушка',description:'5 зарядов вместо 2 на каждую осаду',cost:20},
 repair:{title:'Полевой ремонт',description:'Ремонт восстанавливает 55 HP вместо 30',cost:20},
};
export type Raider={id:number;kind:RaiderKind;brain:Enemy;hp:number;maxHp:number;alive:boolean;stun:number;spawnIn:number;specialClock:number};
export type Shot={kind:Hit['kind']|'inactive'|'locked';point:Vec3;targetId?:number;damage:number;knockback:number};
export type BattleEvent={kind:'trap'|'breach'|'kill'|'hit'|'nexus'|'pudding';point:Vec3;from?:Vec3};
export type Report={kills:number;nexusLost:number;researchEarned:number};
type RaiderSave={id:number;kind:RaiderKind;hp:number;maxHp:number;alive:boolean;stun:number;spawnIn?:number;specialClock?:number;x:number;z:number};
type SavedSiege={version:2;phase:Phase;wave:number;time:number;nexus:number;research:number;kills:number;
 trapCharges:number;trapClock:number;waveStartNexus:number;seq:number;unlocked:Upgrade[];raiders:RaiderSave[];lastReport:Report};
const phases:Phase[]=['PREP','WARNING','SIEGE','RESULT','VICTORY','DEFEAT'];
const upgrades:Upgrade[]=['carrot','trap','repair'];
const finite=(n:unknown,min:number,max:number)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;
export class Siege{
 phase:Phase='PREP';wave=0;time=90;nexus=100;research=0;kills=0;raiders:Raider[]=[];trapCharges=2;
 unlocked=new Set<Upgrade>();lastReport:Report={kills:0,nexusLost:0,researchEarned:0};
 events:BattleEvent[]=[];
 private seq=0;private trapClock=0;private waveStartNexus=100;
 /** Derived from progression: not serialized; reset/reload recomputes it. */
 masonryLevel=0;
 readonly world:World;readonly terrain?:Excavation;
 constructor(world:World,terrain?:Excavation){this.world=world;this.terrain=terrain;}
 reset(){this.phase='PREP';this.wave=0;this.time=90;this.nexus=100;this.research=0;this.kills=0;
  this.raiders=[];this.trapCharges=2;this.unlocked.clear();this.seq=0;this.trapClock=0;this.waveStartNexus=100;
  this.events=[];this.lastReport={kills:0,nexusLost:0,researchEarned:0};}
 private configure(brain:Enemy,kind:RaiderKind){
  const stats:Record<RaiderKind,[number,number,number]>={
   jelly:[1.55,13,.9],brute:[1.02,37,.48],hopper:[2.1,9,1.15],bombardier:[.94,10,1.4]};
  [brain.speed,brain.attackDamage,brain.attackInterval]=stats[kind];
  brain.vaultTrenches=kind==='hopper';
 }
 startEarly(){if(this.phase!=='PREP'&&this.phase!=='WARNING')return false;
  this.phase='SIEGE';this.time=90;this.spawn();return true;}
 private spawn(){this.wave++;this.kills=0;this.trapClock=0;this.waveStartNexus=this.nexus;
  this.trapCharges=this.unlocked.has('trap')?5:2;this.raiders=[];
  const plan=waveIntel(this.wave);
  const kinds:RaiderKind[]=[...Array<RaiderKind>(plan.jellies).fill('jelly'),
   ...Array<RaiderKind>(plan.hoppers).fill('hopper'),...Array<RaiderKind>(plan.brutes).fill('brute'),
   ...Array<RaiderKind>(plan.bombardiers).fill('bombardier')];
  const hp:Record<RaiderKind,number>={jelly:55,hopper:42,brute:130,bombardier:78};
  kinds.forEach((kind,i)=>{
   const brain=new Enemy(this.world,this.terrain);const spawn=raiderSpawn(this.wave,i,kinds.length);
   brain.x=spawn.x;brain.z=spawn.z;this.configure(brain,kind);
   this.raiders.push({id:++this.seq,kind,brain,hp:hp[kind],maxHp:hp[kind],alive:true,stun:0,
    specialClock:0,spawnIn:i*(this.wave===1?2.7:1.8)});
  });
 }
 unlock(upgrade:Upgrade){if(!(upgrade in UPGRADES)||this.unlocked.has(upgrade)||(this.phase!=='PREP'&&this.phase!=='RESULT')||this.research<UPGRADES[upgrade].cost)return false;
  this.research-=UPGRADES[upgrade].cost;this.unlocked.add(upgrade);return true;}
 repairStrength(){return (this.unlocked.has('repair')?55:30)+15*this.masonryLevel;}
 private nexusDamage(amount:number){return Math.max(0,Math.round(amount*(this.masonryLevel>=2?.85:1)));}
 /** Weapon choice is authoritative; carrot requires research. Wall occlusion applies to BOTH. */
 shoot(origin:Vec3,direction:Vec3,weapon:Weapon='bolt'):Shot{
  const noShot={kind:'inactive' as const,point:{...origin},damage:0,knockback:0};
  if(this.phase!=='SIEGE')return noShot;
  if(weapon==='carrot'&&!this.unlocked.has('carrot'))return {...noShot,kind:'locked'};
  const ray=normalize(direction);if(!ray)return {...noShot,kind:'miss'};
  const targets=this.raiders.filter(r=>r.alive&&r.spawnIn<=0).map(r=>({id:r.id,
   radius:r.kind==='brute'?.81:r.kind==='bombardier'?.70:.56,
   position:{x:r.brain.x,y:r.kind==='brute'?.97:r.kind==='bombardier'?.9:.72,z:r.brain.z}}));
  const hit=traceShot(this.world,origin,ray,targets,22);
  const shot:Shot={kind:hit.kind,point:hit.point,targetId:hit.targetId,damage:0,knockback:0};
  if(hit.kind!=='enemy')return shot;
  const enemy=this.raiders.find(r=>r.id===hit.targetId&&r.alive);if(!enemy)return {...shot,kind:'miss'};
  const amount=weapon==='carrot'?14:35;enemy.hp=Math.max(0,enemy.hp-amount);shot.damage=amount;
  this.events.push({kind:'hit',point:hit.point});
  if(enemy.hp<=0){enemy.alive=false;this.kills++;this.events.push({kind:'kill',point:hit.point});return shot;}
  if(weapon==='carrot'){
   const distance=enemy.kind==='brute'?.65:enemy.kind==='bombardier'?1.15:2.25;
   // Push incrementally: never teleport a unit through masonry or outside map.
   for(let traveled=0;traveled<distance;traveled+=.25){
    const step=Math.min(.25,distance-traveled),x=enemy.brain.x+ray.x*step,z=enemy.brain.z+ray.z*step;
    if(!inBounds({x:Math.round(x),y:0,z:Math.round(z)})||this.world.groundObstructions(Math.round(x),Math.round(z)).length)break;
    enemy.brain.x=x;enemy.brain.z=z;shot.knockback+=step;
   }
   enemy.brain.forceRepath();enemy.stun=enemy.kind==='brute'?.16:enemy.kind==='bombardier'?.42:.75;
  }
  return shot;
 }
 private fail(){
  // G10: losing during the current assault must not display the previous wave's report.
  this.lastReport={kills:this.kills,nexusLost:Math.max(0,this.waveStartNexus-this.nexus),researchEarned:0};
  this.phase='DEFEAT';
 }
 private finish(){
  this.lastReport={kills:this.kills,nexusLost:this.waveStartNexus-this.nexus,researchEarned:20+this.kills*3};
  this.research+=this.lastReport.researchEarned;
  this.phase=this.wave>=3?'VICTORY':'RESULT';
 }
 step(dt:number){if(!Number.isFinite(dt)||dt<=0||this.phase==='RESULT'||this.phase==='VICTORY'||this.phase==='DEFEAT')return;
  this.time=Math.max(0,this.time-dt);
  if(this.phase==='PREP'&&this.time<=0){this.phase='WARNING';this.time=15;return;}
  if(this.phase==='WARNING'&&this.time<=0){this.startEarly();return;}
  if(this.phase!=='SIEGE')return;
  this.trapClock+=dt;
  if(this.trapClock>=1){this.trapClock=0;
   if(this.trapCharges>0){const nearby=this.raiders.find(e=>e.alive&&e.spawnIn<=0&&Math.hypot(e.brain.x-7,e.brain.z)<2.6);
    if(nearby){nearby.hp-=60;this.trapCharges--;this.events.push({kind:'trap',point:{x:nearby.brain.x,y:.9,z:nearby.brain.z}});
     if(nearby.hp<=0){nearby.alive=false;this.kills++;this.events.push({kind:'kill',point:{x:nearby.brain.x,y:1,z:nearby.brain.z}});}}}}
  for(const e of this.raiders){if(!e.alive)continue;
   if(e.spawnIn>0){e.spawnIn=Math.max(0,e.spawnIn-dt);if(e.spawnIn>0)continue;}
   if(e.stun>0){e.stun=Math.max(0,e.stun-dt);continue;}
   // Royal pudding artillery fires only at visible, existing wall cells inside range.
   // Unlike ordinary raiders it halts while a target is available.
   if(e.kind==='bombardier'){
    const target=bombardmentTarget(this.world,e.brain.x,e.brain.z);
    if(target){
     e.brain.state='BOMBARDING';e.specialClock+=dt;
     if(e.specialClock>=2.8){
      e.specialClock-=2.8;
      if(this.world.damage(target,22))this.events.push({kind:'pudding',point:{x:target.x,y:target.y+.55,z:target.z},
       from:{x:e.brain.x,y:1.65,z:e.brain.z}});
     }
     continue;
    }
    // Out of range: do not store a fully charged shot for instant firing on arrival.
    e.specialClock=0;
   }
   const before=e.brain.state;e.brain.step(dt);
   if(before!=='ATTACKING_BLOCK'&&e.brain.state==='ATTACKING_BLOCK')this.events.push({kind:'breach',point:{x:e.brain.x,y:1,z:e.brain.z}});
   if(e.brain.state==='ARRIVED'){e.alive=false;this.nexus=Math.max(0,this.nexus-this.nexusDamage(e.kind==='brute'?35:15));this.events.push({kind:'nexus',point:{x:9,y:1.6,z:0}});}
  }
  if(this.nexus<=0){this.fail();return;}
  if(this.raiders.every(e=>!e.alive)||this.time<=0){
   if(this.time<=0)for(const e of this.raiders)if(e.alive){e.alive=false;this.nexus=Math.max(0,this.nexus-this.nexusDamage(10));}
   if(this.nexus<=0){this.fail();return;}this.finish();
  }
 }
 next(){if(this.phase!=='RESULT')return false;this.phase='PREP';this.time=90;return true;}
 snapshot():string{
  const s:SavedSiege={version:2,phase:this.phase,wave:this.wave,time:this.time,nexus:this.nexus,
   research:this.research,kills:this.kills,trapCharges:this.trapCharges,trapClock:this.trapClock,
   seq:this.seq,waveStartNexus:this.waveStartNexus,unlocked:[...this.unlocked],lastReport:{...this.lastReport},raiders:this.raiders.map(r=>({id:r.id,kind:r.kind,
    hp:r.hp,maxHp:r.maxHp,alive:r.alive,stun:r.stun,spawnIn:r.spawnIn,specialClock:r.specialClock,x:r.brain.x,z:r.brain.z}))};
  return JSON.stringify(s);
 }
 /** Pre-validates all persisted state before modifying the live siege. */
 restore(data:string){const s=JSON.parse(data) as SavedSiege;
  if(s.version!==2||!phases.includes(s.phase)||!Number.isInteger(s.wave)||s.wave<0||s.wave>3||
   !finite(s.time,0,100)||!finite(s.nexus,0,100)||!finite(s.research,0,100000)||!finite(s.kills,0,100)||
   !finite(s.trapCharges,0,5)||!finite(s.trapClock,0,100)||!finite(s.seq,0,100000)||
   !finite(s.waveStartNexus,0,100)||
   !Array.isArray(s.unlocked)||s.unlocked.some(v=>!upgrades.includes(v))||new Set(s.unlocked).size!==s.unlocked.length||
   !Array.isArray(s.raiders)||s.raiders.length>20||!s.lastReport||
   !finite(s.lastReport.kills,0,100)||!finite(s.lastReport.nexusLost,0,100)||!finite(s.lastReport.researchEarned,0,500))throw Error('Invalid siege save');
  const ids=new Set<number>();const ready:Raider[]=[];
  for(const r of s.raiders){
   if(!Number.isInteger(r.id)||r.id<1||r.id>s.seq||ids.has(r.id)||!['jelly','brute','hopper','bombardier'].includes(r.kind)||
    !finite(r.maxHp,1,200)||!finite(r.hp,0,r.maxHp)||typeof r.alive!=='boolean'||!finite(r.stun,0,5)||
    !finite(r.x,-22,22)||!finite(r.z,-22,22)||!(r.spawnIn===undefined||finite(r.spawnIn,0,40))||
    !(r.specialClock===undefined||finite(r.specialClock,0,3)))throw Error('Invalid raider save');
   ids.add(r.id);const brain=new Enemy(this.world,this.terrain);brain.x=r.x;brain.z=r.z;this.configure(brain,r.kind);
   ready.push({id:r.id,kind:r.kind,brain,hp:r.hp,maxHp:r.maxHp,alive:r.alive,stun:r.stun,spawnIn:r.spawnIn??0,specialClock:r.specialClock??0});
  }
  this.phase=s.phase;this.wave=s.wave;this.time=s.time;this.nexus=s.nexus;this.research=s.research;
  this.kills=s.kills;this.trapCharges=s.trapCharges;this.trapClock=s.trapClock;this.seq=s.seq;
  this.unlocked=new Set(s.unlocked);this.lastReport={...s.lastReport};this.raiders=ready;
  this.waveStartNexus=s.waveStartNexus;this.events=[];
 }
}
