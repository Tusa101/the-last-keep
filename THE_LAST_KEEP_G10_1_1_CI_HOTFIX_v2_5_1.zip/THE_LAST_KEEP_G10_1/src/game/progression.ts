import type {World} from '../world/model.ts';
import type {Phase} from './siege.ts';

export type DevelopmentBranch='masonry'|'logistics'|'ordnance';
export const BRANCHES:readonly DevelopmentBranch[]=['masonry','logistics','ordnance'];
export type DevelopmentCost={research:number;stone:number;wood:number};
export type DevelopmentSpec={name:string;description:string;levels:readonly [string,string];costs:readonly [DevelopmentCost,DevelopmentCost]};
export const DEVELOPMENT:Record<DevelopmentBranch,DevelopmentSpec>={
 masonry:{name:'Каменщики',description:'Укрепление стен и защита Нексуса',
  levels:['Ремонт игрока и рабочих: +15 HP за операцию','Ещё +15 HP ремонта; Нексус получает на 15% меньше урона'],
  costs:[{research:12,stone:18,wood:0},{research:22,stone:28,wood:4}]},
 logistics:{name:'Логистика',description:'Быстрее перенос материалов и выполнение поручений',
  levels:['Рабочие переносят 10 камня / 8 дерева за рейс','12 камня / 10 дерева за рейс; на 25% быстрее добыча и строительство'],
  costs:[{research:12,stone:0,wood:14},{research:22,stone:7,wood:20}]},
 ordnance:{name:'Алхимическая артиллерия',description:'Улучшения автоматических оборонительных машин',
  levels:['+25% урона турелей и мортир; сироп действует дольше','+50% урона; дополнительное ускорение перезарядки'],
  costs:[{research:18,stone:10,wood:8},{research:28,stone:18,wood:14}]}
};
export type ProgressionWallet={research:number};
export type PurchaseResult={ok:boolean;reason:string;branch:DevelopmentBranch;level:number};

/** A small, finite upgrade economy: neither knowledge nor physical materials appear out of thin air.
 * Research is earned by defending waves; stone and wood are spent from the same World wallet
 * used by repairs, walls and turrets. Save only levels, derive bonuses at runtime.
 */
export class Progression{
 private levels:Record<DevelopmentBranch,number>={masonry:0,logistics:0,ordnance:0};
 readonly world:World;readonly wallet:ProgressionWallet;
 constructor(world:World,wallet:ProgressionWallet){this.world=world;this.wallet=wallet;}
 level(branch:DevelopmentBranch){return this.levels[branch]??0;}
 reset(){for(const b of BRANCHES)this.levels[b]=0;}
 cost(branch:DevelopmentBranch):DevelopmentCost|null{
  const spec=DEVELOPMENT[branch];if(!spec)return null;
  return spec.costs[this.level(branch)]??null;
 }
 canBuy(branch:DevelopmentBranch,phase:Phase,wave:number):PurchaseResult{
  if(!BRANCHES.includes(branch))return {ok:false,reason:'Неизвестная ветка развития',branch,level:0};
  const level=this.level(branch),price=this.cost(branch);
  if(!price)return {ok:false,reason:'Ветка уже максимально развита',branch,level};
  if(phase!=='PREP'&&phase!=='RESULT')return {ok:false,reason:'Улучшения доступны только во время подготовки',branch,level};
  if(wave<level+1)return {ok:false,reason:`Требуется пережить волну ${level+1}`,branch,level};
  if(this.wallet.research<price.research)return {ok:false,reason:`Не хватает знаний: ${price.research}`,branch,level};
  if(this.world.resources.stone<price.stone||this.world.resources.wood<price.wood)
   return {ok:false,reason:`Не хватает материалов: ${price.stone} камня и ${price.wood} дерева`,branch,level};
  return {ok:true,reason:'Улучшение доступно',branch,level};
 }
 buy(branch:DevelopmentBranch,phase:Phase,wave:number):PurchaseResult{
  const check=this.canBuy(branch,phase,wave);if(!check.ok)return check;
  const price=this.cost(branch)!;
  this.wallet.research-=price.research;
  this.world.resources.stone-=price.stone;
  this.world.resources.wood-=price.wood;
  this.levels[branch]++;
  return {ok:true,reason:`${DEVELOPMENT[branch].name}: уровень ${this.level(branch)}/2`,branch,level:this.level(branch)};
 }
 snapshot():string{return JSON.stringify({version:1,levels:{...this.levels}});}
 /** Validate first, mutate only if all branches are well formed. Supports loading pre-G8 saves through reset(). */
 restore(json:string){
  const raw=JSON.parse(json) as {version:number;levels:Record<string,unknown>};
  if(raw?.version!==1||!raw.levels||typeof raw.levels!=='object'||
   Object.keys(raw.levels).length!==BRANCHES.length||
   BRANCHES.some(branch=>!Number.isInteger(raw.levels[branch])||(raw.levels[branch] as number)<0||(raw.levels[branch] as number)>2))
   throw Error('Invalid progression save');
  this.levels={masonry:raw.levels.masonry as number,logistics:raw.levels.logistics as number,ordnance:raw.levels.ordnance as number};
 }
}
