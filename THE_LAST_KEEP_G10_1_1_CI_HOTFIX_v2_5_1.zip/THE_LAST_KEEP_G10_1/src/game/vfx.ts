/** Presentation-only particle presets. No random global state, resources or gameplay side effects.
 * This module intentionally has no Three.js dependency so it can be tested in Node.
 */
export type VfxKind='hit'|'kill'|'breach'|'trap'|'nexus'|'pudding'|'carrotTower'|'cheeseMortar'|'syrupSprayer'|'build'|'repair';
export type ParticleSpec={vx:number;vy:number;vz:number;life:number;size:number;gravity:number;color:string};
export type VfxRecipe={count:number;speed:number;up:number;life:number;size:number;gravity:number;palette:readonly string[]};
export const VFX_RECIPES:Readonly<Record<VfxKind,VfxRecipe>>={
 hit:{count:7,speed:1.8,up:1.4,life:.37,size:.080,gravity:6.3,palette:['#ffe6a6','#fff5cc','#c88f6c']},
 kill:{count:22,speed:3.5,up:2.5,life:.75,size:.15,gravity:5.2,palette:['#ec8ab7','#ffd0e1','#f5c267']},
 breach:{count:16,speed:2.8,up:2.1,life:.68,size:.13,gravity:8,palette:['#b7a18a','#8d7e6e','#ddd0ab']},
 trap:{count:24,speed:3.8,up:2.5,life:.66,size:.115,gravity:6.2,palette:['#fbc564','#ffe6a4','#d57b3a']},
 nexus:{count:36,speed:4.2,up:3,life:.9,size:.145,gravity:5.6,palette:['#76fbe2','#d7fff6','#edaa89']},
 pudding:{count:17,speed:2.3,up:2.2,life:.64,size:.12,gravity:5.8,palette:['#ca7cf2','#e0b2ff','#9a5bcb']},
 carrotTower:{count:12,speed:2.5,up:2.0,life:.52,size:.10,gravity:4.5,palette:['#ffac43','#ec7b25','#89ba55']},
 cheeseMortar:{count:27,speed:3.7,up:3.0,life:.88,size:.16,gravity:7.4,palette:['#ffe470','#ffb92b','#f9ecaa']},
 syrupSprayer:{count:19,speed:2.1,up:1.6,life:.78,size:.14,gravity:4.7,palette:['#e2ad57','#b97530','#edc67d']},
 build:{count:8,speed:1.3,up:1.1,life:.5,size:.07,gravity:5.5,palette:['#e0cbaa','#b2c1a2','#b9a287']},
 repair:{count:10,speed:1.9,up:1.5,life:.5,size:.07,gravity:5,palette:['#9bdfb0','#dfc686','#f4e7b8']}
};
/** Repeatable pseudo-random sample; no global RNG mutation and no dependence on frame rate. */
function unit(seed:number){let n=(seed>>>0)+0x6d2b79f5;n=Math.imul(n^(n>>>15),n|1);n^=n+Math.imul(n^(n>>>7),n|61);return ((n^(n>>>14))>>>0)/4294967296;}
export function particleBurst(kind:VfxKind,seed:number,maximum=40):ParticleSpec[]{
 const config=VFX_RECIPES[kind];
 const count=Math.max(0,Math.min(config.count,Math.floor(Number.isFinite(maximum)?maximum:0),40));
 const result:ParticleSpec[]=[];
 for(let i=0;i<count;i++){
  const base=(seed>>>0)+i*17;
  const angle=unit(base+1)*Math.PI*2,radial=Math.sqrt(unit(base+2));
  const speed=config.speed*(.35+.65*unit(base+3));
  result.push({vx:Math.cos(angle)*speed*radial,vy:config.up*(.45+unit(base+4)),vz:Math.sin(angle)*speed*radial,
   life:config.life*(.7+.6*unit(base+5)),size:config.size*(.65+.65*unit(base+6)),gravity:config.gravity,
   color:config.palette[Math.floor(unit(base+7)*config.palette.length)]});
 }
 return result;
}
