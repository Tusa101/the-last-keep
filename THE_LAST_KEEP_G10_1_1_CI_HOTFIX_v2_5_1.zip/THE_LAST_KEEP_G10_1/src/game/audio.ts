/** G9 procedural, self-contained sound design. All sounds are short one-shots and
 * only become audible after a user gesture has unlocked AudioContext.
 * Play never affects simulation, and missing Web Audio fails silently.
 */
export type SoundKind='bolt'|'carrot'|'hit'|'trap'|'alarm'|'kill'|'nexus'|'breach'|'turret'|'cheese'|'syrup';
type Tone={start:number;end:number;duration:number;volume:number;wave:OscillatorType};
const PRESETS:Record<SoundKind,Tone>={
 bolt:{start:240,end:95,duration:.105,volume:.085,wave:'sawtooth'},
 carrot:{start:600,end:135,duration:.2,volume:.13,wave:'triangle'},
 hit:{start:185,end:62,duration:.08,volume:.065,wave:'triangle'},
 trap:{start:560,end:115,duration:.3,volume:.13,wave:'square'},
 alarm:{start:330,end:460,duration:.5,volume:.13,wave:'sine'},
 kill:{start:470,end:130,duration:.23,volume:.08,wave:'triangle'},
 nexus:{start:290,end:52,duration:.5,volume:.14,wave:'sawtooth'},
 breach:{start:126,end:43,duration:.25,volume:.11,wave:'sawtooth'},
 turret:{start:440,end:215,duration:.12,volume:.065,wave:'triangle'},
 cheese:{start:100,end:43,duration:.45,volume:.13,wave:'square'},
 syrup:{start:290,end:102,duration:.38,volume:.078,wave:'sine'}
};
export class Sfx{
 private context:AudioContext|null=null;
 private armed=false;
 private last=new Map<SoundKind,number>();
 private live=0;
 enabled=true;
 /** Must be called from a click/touch/key gesture, not on first page paint. */
 unlock(){
  if(!this.enabled||typeof AudioContext==='undefined')return;
  try{this.context??=new AudioContext();this.armed=true;if(this.context.state==='suspended')void this.context.resume().catch(()=>{});}catch{/* optional */}
 }
 play(kind:SoundKind){
  if(!this.enabled||!this.armed||!this.context||this.context.state!=='running'||this.live>=12)return;
  try{
   const context=this.context,t=context.currentTime;
   // Limit repeating hit sounds during multi-target area damage.
   const gap=kind==='hit'?.065:kind==='turret'?.1:kind==='kill'?.07:0;
   if(t-(this.last.get(kind)??-999)<gap)return;
   this.last.set(kind,t);
   const p=PRESETS[kind],osc=context.createOscillator(),envelope=context.createGain();
   const filter=context.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(kind==='cheese'?480:1700,t);
   osc.type=p.wave;osc.frequency.setValueAtTime(p.start,t);
   osc.frequency.exponentialRampToValueAtTime(p.end,t+p.duration);
   envelope.gain.setValueAtTime(.001,t);envelope.gain.linearRampToValueAtTime(p.volume,t+.015);
   envelope.gain.exponentialRampToValueAtTime(.001,t+p.duration);
   osc.connect(filter);filter.connect(envelope);envelope.connect(context.destination);
   this.live++;osc.start(t);osc.stop(t+p.duration+.03);
   osc.addEventListener('ended',()=>{osc.disconnect();filter.disconnect();envelope.disconnect();this.live=Math.max(0,this.live-1);},{once:true});
  }catch{/* browser can revoke sound permissions */}
 }
}
