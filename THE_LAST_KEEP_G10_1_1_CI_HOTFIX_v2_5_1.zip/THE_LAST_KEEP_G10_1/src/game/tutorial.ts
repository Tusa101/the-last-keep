/** Non-blocking, evidence-driven onboarding. Gameplay never depends on this state. */
export type TutorialEvent='moved'|'harvested'|'built'|'defense'|'waveStarted'|'waveWon'|'workerHired'|'architectOpened';
export type TutorialStep={id:TutorialEvent;title:string;description:string;desktop:string;mobile:string;action?:string};
export const TUTORIAL_STEPS:readonly TutorialStep[]=[
 {id:'moved',title:'Осмотрись во дворе',description:'Подойди к стене с проломом. Камера и перемещение работают одновременно.',desktop:'WASD — движение, мышь — обзор.',mobile:'Левый джойстик — движение, свайп справа — обзор.'},
 {id:'harvested',title:'Заготовь материалы',description:'Добывай конечные залежи дерева и камня. Для работы подойди ближе к ресурсу.',desktop:'Подойди к камням или деревьям и нажми X.',mobile:'Подойди к залежи → ☰ Меню → ⛏ Добыть ресурс.',action:'gather'},
 {id:'built',title:'Залатай крепость',description:'Наведи прицел рядом с существующей кладкой и поставь хотя бы один блок.',desktop:'ПКМ — строительство; 1/2 — материал.',mobile:'Свайп справа для прицела → ＋ Строить.',action:'build'},
 {id:'defense',title:'Установи необычное орудие',description:'На подготовке поставь автоматическую оборону. Если не хватает дерева или камня — добудь их.',desktop:'I — тип орудия, O — установить; R — Военный совет.',mobile:'☰ Меню → Бой и оборона → Построить орудие.',action:'defense'},
 {id:'waveStarted',title:'Начни первую осаду',description:'Приготовься защищать Нексус. Волна также начнётся сама по окончании подготовки.',desktop:'G — начать раньше; Shift + ЛКМ — стрелять.',mobile:'⚑ Волна — начать раньше; ⚔ Огонь — стрелять.',action:'wave'},
 {id:'waveWon',title:'Отбей нападение',description:'Защищай Нексус и устрани всех противников. Наблюдай за проломами.',desktop:'WASD — уклонение, Shift + ЛКМ — выстрел.',mobile:'Джойстик — уклонение, ⚔ Огонь — стрельба.',action:'fire'},
 {id:'workerHired',title:'Найми первого рабочего',description:'После первой волны первый помощник бесплатный. Рабочие сами собирают и доставляют материалы.',desktop:'J — нанять рабочего.',mobile:'☰ Меню → Рабочие → 👷 Нанять.',action:'worker'},
 {id:'architectOpened',title:'Открой режим архитектора',description:'Проектируй укрепления сверху. Поручения затем выполняют рабочие.',desktop:'P — открыть карту архитектора; T — поручение.',mobile:'☰ Меню → 🏰 Архитектор.',action:'architect'}
] as const;
const EVENT_IDS=new Set<TutorialEvent>(TUTORIAL_STEPS.map(s=>s.id));
export type TutorialSnapshot={version:1;index:number;enabled:boolean;seen:TutorialEvent[]};
export class Tutorial{
 private seen=new Set<TutorialEvent>();
 index=0;enabled=true;
 get complete(){return this.index>=TUTORIAL_STEPS.length;}
 get step():TutorialStep|null{return TUTORIAL_STEPS[this.index]??null;}
 get progress(){return {current:Math.min(this.index+1,TUTORIAL_STEPS.length),total:TUTORIAL_STEPS.length};}
 /** Records out-of-order accomplishments too: tutorial does not restrict the player. */
 mark(event:TutorialEvent){
  if(!EVENT_IDS.has(event))return false;
  const before=this.index;this.seen.add(event);
  while(this.index<TUTORIAL_STEPS.length&&this.seen.has(TUTORIAL_STEPS[this.index].id))this.index++;
  return before!==this.index;
 }
 toggle(){this.enabled=!this.enabled;return this.enabled;}
 reset(){this.index=0;this.seen.clear();this.enabled=true;}
 snapshot():TutorialSnapshot{return {version:1,index:this.index,enabled:this.enabled,seen:[...this.seen]};}
 restore(raw:unknown){
  if(!raw||typeof raw!=='object')return false;
  const x=raw as Partial<TutorialSnapshot>;
  if(x.version!==1||typeof x.index!=='number'||!Number.isInteger(x.index)||x.index<0||x.index>TUTORIAL_STEPS.length||typeof x.enabled!=='boolean'||!Array.isArray(x.seen)||x.seen.length>TUTORIAL_STEPS.length||x.seen.some(id=>!EVENT_IDS.has(id)))return false;
  const seen=new Set(x.seen);
  if(x.index!==TUTORIAL_STEPS.findIndex(step=>!seen.has(step.id)) && !(x.index===TUTORIAL_STEPS.length&&TUTORIAL_STEPS.every(s=>seen.has(s.id))))return false;
  this.seen=seen;this.index=x.index;this.enabled=x.enabled;return true;
 }
}
