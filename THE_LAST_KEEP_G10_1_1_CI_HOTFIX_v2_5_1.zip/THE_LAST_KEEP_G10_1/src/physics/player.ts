import {World,LIMIT,HEIGHT,type Cell,type Shape,type Orientation} from '../world/model.ts';
import {shapeBoxes,type Box} from '../world/shapes.ts';
import type {Excavation} from '../world/excavation.ts';
export type Player={x:number;y:number;z:number;vy:number;grounded:boolean};
export type Control={dx:number;dz:number;jump:boolean};
const R=.27,H=1.63,G=17,JUMP=7,EPS=.0001,STEP=.64;
type Aabb={x0:number;x1:number;y0:number;y1:number;z0:number;z1:number};
const rangesOverlap=(a0:number,a1:number,b0:number,b1:number)=>a1>b0+EPS&&a0<b1-EPS;
const worldBox=(c:Cell,b:Box):Aabb=>({x0:c.x+b.x0,x1:c.x+b.x1,y0:c.y+b.y0,y1:c.y+b.y1,z0:c.z+b.z0,z1:c.z+b.z1});
const hit=(x:number,y:number,z:number,v:Aabb)=>rangesOverlap(x-R,x+R,v.x0,v.x1)&&rangesOverlap(y,y+H,v.y0,v.y1)&&rangesOverlap(z-R,z+R,v.z0,v.z1);
export function intersectsPlayer(c:Cell,shape:Shape,p:Player,dir:Orientation=0){
 return shapeBoxes(shape,dir).some(b=>hit(p.x,p.y,p.z,worldBox(c,b)));
}
/** Spatially constrained local search (at most ~3×3×12 cells). */
function around(world:World,x:number,z:number,cb:(a:Aabb)=>void){
 for(let cx=Math.floor(x-1);cx<=Math.ceil(x+1);cx++)for(let cz=Math.floor(z-1);cz<=Math.ceil(z+1);cz++){
  for(let y=0;y<=HEIGHT;y++){
   const block=world.get(cx,y,cz);if(!block)continue;
   for(const part of shapeBoxes(block.shape,block.dir))cb(worldBox({x:cx,y,z:cz},part));
  }
 }
}
function collides(world:World,x:number,feet:number,z:number){
 let collision=false;around(world,x,z,b=>{if(!collision&&hit(x,feet,z,b))collision=true;});return collision;
}
function floorHeights(world:World,x:number,z:number,terrain?:Excavation){
 const found=new Set<number>([terrain?.groundY(x,z)??0]);around(world,x,z,b=>{
  if(rangesOverlap(x-R,x+R,b.x0,b.x1)&&rangesOverlap(z-R,z+R,b.z0,b.z1))found.add(b.y1);
 });return [...found];
}
/** Moving across an actual staircase: can mount a half-meter rise while grounded.
 * Still cannot pass through a one-meter wall or a roof above the player's head. */
function moveAxis(world:World,p:Player,x:number,z:number,terrain?:Excavation){
 // A cliff wall is a physical obstacle: entering higher ground needs a .52m
 // step or enough jump height. Deep trench escape requires terraced edges.
 const newFloor=terrain?.groundY(x,z)??0;
 const climb=newFloor>p.y+EPS;
 if(climb&&(!p.grounded||newFloor>p.y+STEP))return;
 const feet=climb?newFloor:p.y;
 if(!collides(world,x,feet,z)){p.x=x;p.z=z;if(climb){p.y=feet;p.vy=0;}return;}
 if(!p.grounded)return;
 const reachable=floorHeights(world,x,z,terrain).filter(y=>y>p.y+EPS&&y<=p.y+STEP).sort((a,b)=>a-b);
 for(const height of reachable){if(!collides(world,x,height,z)){
  p.x=x;p.z=z;p.y=height;p.vy=0;return;
 }}
}
export function stepPlayer(world:World,p:Player,control:Control,dt:number,terrain?:Excavation):Player{
 const n={...p};dt=Math.min(.05,Math.max(0,dt));
 const magnitude=Math.max(1,Math.hypot(control.dx,control.dz));
 const dx=control.dx/magnitude*dt*4.5,dz=control.dz/magnitude*dt*4.5;
 const nx=Math.max(-LIMIT+.5,Math.min(LIMIT-.5,n.x+dx));moveAxis(world,n,nx,n.z,terrain);
 const nz=Math.max(-LIMIT+.5,Math.min(LIMIT-.5,n.z+dz));moveAxis(world,n,n.x,nz,terrain);
 if(control.jump&&n.grounded){n.vy=JUMP;n.grounded=false;}
 n.vy-=G*dt;
 const proposed=Math.max(-2.5,n.y+n.vy*dt);
 if(n.vy>0){
  if(collides(world,n.x,proposed,n.z)){n.vy=0;}else n.y=proposed;
  n.grounded=false;
 }else{
  const supports=floorHeights(world,n.x,n.z,terrain).filter(y=>y<=n.y+EPS&&y>=proposed-EPS).sort((a,b)=>b-a);
  // If the support is a narrow pillar, make sure the standing volume does not intersect another box.
  const landing=supports.find(y=>!collides(world,n.x,y,n.z));
  if(landing!==undefined){n.y=landing;n.vy=0;n.grounded=true;}
  else{n.y=proposed;n.grounded=false;}
 }
 // Resolve the current cell's earth floor even after a mid-air save/load.
 const surface=terrain?.groundY(n.x,n.z)??0;
 if(n.y<=surface&&n.vy<=0){n.y=surface;n.vy=0;n.grounded=true;}
 return n;
}
