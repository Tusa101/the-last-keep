import * as THREE from 'three';
import type {DefenseKind} from '../game/defenses.ts';

/** Three distinct readable silhouettes rather than recolours of the same cone. */
export function makeDefenseModel(kind:DefenseKind){
 const group=new THREE.Group();
 const stone=new THREE.MeshLambertMaterial({color:'#96876e',flatShading:true}),oak=new THREE.MeshLambertMaterial({color:'#765036'});
 const brass=new THREE.MeshStandardMaterial({color:'#c2a05b',metalness:.35,roughness:.62});
 const orange=new THREE.MeshLambertMaterial({color:'#e58a34'}),green=new THREE.MeshLambertMaterial({color:'#60965c'});
 const cheese=new THREE.MeshLambertMaterial({color:'#f5d664',emissive:'#4a2b00',emissiveIntensity:.1});
 const syrup=new THREE.MeshLambertMaterial({color:'#bd873d',transparent:true,opacity:.9});
 function add(geometry:THREE.BufferGeometry,material:THREE.Material,x:number,y:number,z:number){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);group.add(m);return m;}
 add(new THREE.CylinderGeometry(.64,.78,.40,8),stone,0,.2,0);
 const turret=new THREE.Group();turret.position.y=.44;group.add(turret);
 const put=(g:THREE.BufferGeometry,m:THREE.Material,x:number,y:number,z:number)=>{const mesh=new THREE.Mesh(g,m);mesh.position.set(x,y,z);turret.add(mesh);return mesh;};
 if(kind==='carrotTower'){
  // A medieval wooden swivel barrel that happens to load oversized carrots.
  put(new THREE.CylinderGeometry(.42,.44,.32,8),oak,0,.3,0);
  const barrel=put(new THREE.CylinderGeometry(.20,.29,1.0,9),brass,0,.55,-.43);barrel.rotation.x=Math.PI/2;
  const carrot=put(new THREE.ConeGeometry(.17,.68,8),orange,0,.55,-1.0);carrot.rotation.x=-Math.PI/2;
  for(const x of [-.12,0,.12]){const leaf=put(new THREE.ConeGeometry(.06,.32,6),green,x,.73,-.8);leaf.rotation.z=x*2;}
  for(const x of [-.43,.43])put(new THREE.BoxGeometry(.13,.44,.13),oak,x,.26,.12);
 }else if(kind==='cheeseMortar'){
  // Gold-braced angled mortar, with a comically enormous cheesy round in its breech.
  const cradle=put(new THREE.BoxGeometry(.95,.27,.78),oak,0,.27,0);
  const tube=put(new THREE.CylinderGeometry(.31,.38,.84,10),brass,0,.74,-.18);tube.rotation.x=-.54;
  const rim=put(new THREE.TorusGeometry(.31,.065,8,12),stone,0,1.08,-.39);rim.rotation.x=.54;
  const wedge=put(new THREE.ConeGeometry(.31,.46,7),cheese,0,1.12,.21);wedge.rotation.z=.26;
  for(const z of [-.26,.26]){const rivet=put(new THREE.SphereGeometry(.08,5,4),cheese,.42,.35,z);rivet.scale.x=.65;}
  cradle.rotation.y=.04;
 }else{
  // Copper tank, crooked pipe and a hanging sticky nozzle.
  put(new THREE.CylinderGeometry(.40,.44,.89,10),syrup,0,.68,.07);
  put(new THREE.TorusGeometry(.37,.07,7,12),brass,0,1.08,.07);
  const pipe=put(new THREE.CylinderGeometry(.12,.12,.78,7),brass,0,1.03,-.45);pipe.rotation.x=Math.PI/2;
  put(new THREE.ConeGeometry(.26,.25,9),brass,0,1.03,-.89).rotation.x=-Math.PI/2;
  const droplet=put(new THREE.SphereGeometry(.13,7,6),syrup,0,.81,-1.03);droplet.scale.y=1.35;
  for(const x of [-.35,.35])put(new THREE.BoxGeometry(.09,.85,.11),oak,x,.55,.25);
 }
 group.userData.turret=turret;
 return group;
}
