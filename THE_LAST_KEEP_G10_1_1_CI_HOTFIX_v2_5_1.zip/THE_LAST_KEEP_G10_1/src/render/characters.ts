import * as THREE from 'three';
import type {Raider} from '../game/siege.ts';

/** Original "failed royal alchemy" enemy family. Readable from >20 metres:
 * jelly = narrow glassy helmet + wobbling pear body; brute = massive square shoulders,
 * caramel battering club. Geometry is intentionally low-poly and texture-free. */
const jellyColor='#e989bc',jellyShade='#bb5d99',caramel='#98563f',cream='#e6bb73',bronze='#947b55';
const dark=new THREE.MeshLambertMaterial({color:'#2b2430'});
const eyeWhite=new THREE.MeshLambertMaterial({color:'#fff0d9'});
const brass=new THREE.MeshStandardMaterial({color:'#c09a58',metalness:.35,roughness:.55});
const oak=new THREE.MeshLambertMaterial({color:'#70452d'});
const ruby=new THREE.MeshStandardMaterial({color:'#df4d58',roughness:.4});
function addMesh(parent:THREE.Object3D,geometry:THREE.BufferGeometry,material:THREE.Material,x:number,y:number,z:number){
 const mesh=new THREE.Mesh(geometry,material);mesh.position.set(x,y,z);parent.add(mesh);return mesh;
}
function ball(parent:THREE.Object3D,material:THREE.Material,x:number,y:number,z:number,r:number,sy=1){
 const m=addMesh(parent,new THREE.IcosahedronGeometry(r,1),material,x,y,z);m.scale.y=sy;return m;
}
function box(parent:THREE.Object3D,material:THREE.Material,x:number,y:number,z:number,sx:number,sy:number,sz:number){
 return addMesh(parent,new THREE.BoxGeometry(sx,sy,sz),material,x,y,z);
}
function rod(parent:THREE.Object3D,material:THREE.Material,x:number,y:number,z:number,rTop:number,rBottom:number,height:number,sides=7){
 return addMesh(parent,new THREE.CylinderGeometry(rTop,rBottom,height,sides),material,x,y,z);
}
export type RaiderVisual={root:THREE.Group;figure:THREE.Group;meter:THREE.Group;fill:THREE.Mesh;core:THREE.Mesh;
 lastX:number;lastZ:number;heading:number;phase:number;bodyMaterial:THREE.MeshLambertMaterial};
export function makeRaiderVisual(r:Raider):RaiderVisual{
 const root=new THREE.Group(),figure=new THREE.Group();root.add(figure);
 const isBrute=r.kind==='brute',isHopper=r.kind==='hopper',isBomber=r.kind==='bombardier';
 const bodyMaterial=new THREE.MeshLambertMaterial({color:isBrute?caramel:isHopper?'#73bd84':isBomber?'#926bb9':jellyColor,emissive:'#000000',flatShading:true});
 const trim=new THREE.MeshLambertMaterial({color:isBrute?cream:isHopper?'#d9e889':isBomber?'#d4b3ee':jellyShade,flatShading:true});
 let core:THREE.Mesh;
 if(isHopper){
  // Sprinting mint-green court courier with two ridiculous pogo-springs.
  core=ball(figure,bodyMaterial,0,.92,0,.46,1.07);
  for(const z of [-.32,.32]){
   rod(figure,brass,0,.29,z,.13,.13,.30,8);
   for(let i=0;i<3;i++){
    const loop=addMesh(figure,new THREE.TorusGeometry(.17,.032,6,10),trim,0,.24+i*.12,z);
    loop.rotation.x=Math.PI/2;
   }
   box(figure,bodyMaterial,.08,.11,z,.64,.14,.40);
   ball(figure,eyeWhite,.33,1.03,z*.5,.12);
   ball(figure,dark,.42,1.05,z*.5,.064);
  }
  const hat=addMesh(figure,new THREE.ConeGeometry(.34,.56,7),brass,0,1.70,0);
  hat.rotation.z=-.20;
  ball(figure,ruby,-.07,2.03,0,.12);
 }else if(isBomber){
  // Purple pudding cannoneer: tiny cook wearing an enormous brass cauldron.
  core=box(figure,bodyMaterial,-.05,.88,0,.95,1.04,.97);
  for(const z of [-.32,.32]){
   box(figure,bodyMaterial,-.04,.21,z,.30,.48,.29);
   ball(figure,eyeWhite,.48,1.03,z*.62,.15);
   ball(figure,dark,.58,1.04,z*.62,.065);
  }
  const cauldron=rod(figure,brass,-.17,1.52,0,.70,.57,.46,10);
  cauldron.rotation.z=.11;
  rod(figure,dark,-.17,1.79,0,.66,.66,.11,10);
  for(const z of [-.28,.28])ball(figure,trim,-.15,1.91,z,.18,1.2);
  const spoon=rod(figure,oak,.54,.91,-.56,.07,.07,1.12);
  spoon.rotation.z=-.48;
  ball(figure,trim,.32,1.52,-.56,.25);
 }else if(!isBrute){
  // Flat-bottom jelly recruit wearing a very solemn, ill-fitting miniature sallet.
  core=ball(figure,bodyMaterial,0,.68,0,.54,1.18);
  ball(figure,trim,-.07,.30,.42,.30,.55);ball(figure,trim,-.07,.30,-.42,.30,.55);
  for(const z of [-.25,.25]){
   ball(figure,eyeWhite,.47,.89,z,.145,1.1);
   ball(figure,dark,.58,.9,z,.068);
   ball(figure,dark,.40,.25,z,.16,.52);
  }
  // The helmet is purposely too tall, with a wobbling rooster-style pennon.
  rod(figure,brass,-.04,1.31,0,.28,.4,.23,8);
  addMesh(figure,new THREE.ConeGeometry(.24,.42,7),brass,-.06,1.62,0);
  const plume=ball(figure,ruby,-.09,1.82,0,.115,1.5);plume.name='plume';
  box(figure,oak,.15,.66,-.55,.10,.48,.12); // absurd wooden parade shield strap
  box(figure,brass,.21,.66,-.63,.12,.49,.43);
 } else {
  // Caramel breacher: tank-like, legible square silhouette, huge asymmetric ram.
  core=box(figure,bodyMaterial,-.08,.95,0,1.30,1.34,1.3);
  box(figure,trim,.42,1.13,0,.32,.64,1.05);
  for(const z of [-.50,.50]){
   box(figure,bodyMaterial,-.08,.29,z,.51,.63,.47);
   ball(figure,trim,-.09,1.52,z,.47,.5);
   ball(figure,eyeWhite,.61,1.49,z*.47,.13);
   ball(figure,dark,.73,1.50,z*.47,.065);
  }
  // Candy-copper plated horns, banding and hand-held siege ram.
  for(const z of [-.48,.48]){
   const horn=addMesh(figure,new THREE.ConeGeometry(.22,.62,6),trim,-.10,1.98,z);
   horn.rotation.z=-.22;
  }
  box(figure,brass,-.05,.75,.0,.20,.22,1.43);
  rod(figure,oak,.5,.92,-.81,.10,.11,1.48);
  const mallet=box(figure,trim,.66,1.64,-.79,.56,.56,.62);mallet.rotation.z=.24;
  for(const z of [-1.11,-.47])ball(figure,brass,.66,1.64,z,.16);
 }
 const meter=new THREE.Group();meter.position.y=isBrute?2.58:isHopper?2.46:isBomber?2.43:2.14;root.add(meter);
 box(meter,dark,0,0,-.006,1.13,.13,.044);
 const fill=box(meter,new THREE.MeshBasicMaterial({color:isBrute?'#ffd187':isBomber?'#dbc2ff':isHopper?'#c9f092':'#b1f49c'}),0,0,.035,1.04,.073,.043);
 const status=ball(meter,brass,-.65,0,0,.055);status.scale.z=.25;
 return {root,figure,meter,fill,core,lastX:r.brain.x,lastZ:r.brain.z,heading:0,phase:r.id*1.19,bodyMaterial};
}
export function animateRaiderVisual(v:RaiderVisual,r:Raider,now:number,camera:THREE.Camera){
 const dx=r.brain.x-v.lastX,dz=r.brain.z-v.lastZ,travel=Math.hypot(dx,dz);
 if(travel>.001){const target=-Math.atan2(dz,dx);const turn=Math.atan2(Math.sin(target-v.heading),Math.cos(target-v.heading));v.heading+=Math.max(-.14,Math.min(.14,turn));}
 v.lastX=r.brain.x;v.lastZ=r.brain.z;
 v.root.position.set(r.brain.x,r.stun>0?.06:0,r.brain.z);
 v.figure.rotation.y=v.heading;
 const moving=travel>.001;const action=r.brain.state==='ATTACKING_BLOCK'||r.brain.state==='BOMBARDING';
 const speed=r.kind==='brute'?6:r.kind==='hopper'?15:10,w=Math.sin(now*.001*speed+v.phase);
 v.figure.position.y=r.stun>0?.02:(moving?(r.kind==='hopper'?.20:.055)*Math.abs(w): .03*Math.sin(now*.0017+v.phase));
 v.core.scale.x=(r.kind==='brute'||r.kind==='bombardier'?1:.93)+(r.kind==='brute'||r.kind==='bombardier'?0:.08)*Math.sin(now*.003+v.phase);
 v.core.scale.z=(r.kind==='brute'||r.kind==='bombardier'?1:.94)+(r.kind==='brute'||r.kind==='bombardier'?0:.07)*Math.sin(now*.003+v.phase);
 v.figure.rotation.z=action?Math.sin(now*.010+v.phase)*.12:r.stun>0?.17*Math.sin(now*.022):.025*w;
 v.bodyMaterial.emissive.set(r.stun>0?'#7a3516':action?'#431b0b':'#000000');
 v.bodyMaterial.emissiveIntensity=r.stun>0?.55:action?.22:0;
 const ratio=Math.max(0,Math.min(1,r.hp/r.maxHp));v.fill.scale.x=ratio;v.fill.position.x=-(1-ratio)*.52;
 v.meter.lookAt(camera.position);
}
export function removeRaiderVisual(scene:THREE.Scene,v:RaiderVisual){
 scene.remove(v.root);
 v.root.traverse(obj=>{if(obj instanceof THREE.Mesh){obj.geometry.dispose();
  // Singleton materials are intentionally reused across raiders and not disposed here.
  const material=obj.material;if(material===v.bodyMaterial)material.dispose();
 }});
}
