import * as THREE from 'three';
import type {Worker} from '../game/workers.ts';

/** Small recognisable medieval porters. Pure Three.js geometry, no borrowed IP/assets. */
export function workerRenderer(scene:THREE.Scene,groundY:(x:number,z:number)=>number=()=>0){
 const visuals=new Map<number,{root:THREE.Group;cargo:THREE.Mesh;armL:THREE.Group;armR:THREE.Group}>();
 const linen=new THREE.MeshLambertMaterial({color:'#cbbb90'});
 const boots=new THREE.MeshLambertMaterial({color:'#46372e'});
 const stone=new THREE.MeshLambertMaterial({color:'#aaa39b'});
 const wood=new THREE.MeshLambertMaterial({color:'#9c683d'});
 const leather=new THREE.MeshLambertMaterial({color:'#755236'});
 const faces=new THREE.MeshLambertMaterial({color:'#e6b681'});
 const jacket=[new THREE.MeshLambertMaterial({color:'#436a67'}),new THREE.MeshLambertMaterial({color:'#926b42'})];
 function box(parent:THREE.Group,size:[number,number,number],pos:[number,number,number],mat:THREE.Material){
  const m=new THREE.Mesh(new THREE.BoxGeometry(...size),mat);m.position.set(...pos);parent.add(m);return m;
 }
 function add(w:Worker){
  const root=new THREE.Group(),tunic=jacket[(w.id-1)%2];scene.add(root);
  box(root,[.56,.65,.34],[0,.79,0],tunic);
  box(root,[.38,.37,.36],[0,1.28,0],faces);
  const cap=new THREE.Mesh(new THREE.ConeGeometry(.34,.36,7),linen);cap.position.y=1.62;root.add(cap);
  const armL=new THREE.Group(),armR=new THREE.Group();armL.position.set(-.37,1.06,0);armR.position.set(.37,1.06,0);
  box(armL,[.18,.48,.19],[0,-.20,0],tunic);box(armR,[.18,.48,.19],[0,-.20,0],tunic);
  root.add(armL,armR);
  box(root,[.19,.44,.23],[-.15,.24,0],boots);box(root,[.19,.44,.23],[.15,.24,0],boots);
  box(root,[.60,.53,.21],[0,.84,.33],leather);
  const cargo=box(root,[.43,.32,.43],[0,1.07,.36],stone);cargo.visible=false;
  const badge=new THREE.Mesh(new THREE.TorusGeometry(.19,.045,7,16),linen);badge.position.set(0,1.37,-.19);root.add(badge);
  visuals.set(w.id,{root,cargo,armL,armR});
 }
 function sync(workers:readonly Worker[],now:number){
  const live=new Set(workers.map(w=>w.id));
  for(const [id,v] of visuals)if(!live.has(id)){scene.remove(v.root);visuals.delete(id);}
  for(const w of workers){
   if(!visuals.has(w.id))add(w);
   const v=visuals.get(w.id)!;
   v.root.position.set(w.x,groundY(w.x,w.z)+.02+Math.sin(now*.006+w.id)*.018,w.z);
   const carrying=!!w.cargo&&w.amount>0;v.cargo.visible=carrying;
   if(carrying)v.cargo.material=w.cargo==='wood'?wood:stone;
   const pace=w.job&&w.job!=='retreat'?Math.sin(now*.011+w.id):0;
   v.armL.rotation.x=pace*.3;v.armR.rotation.x=-pace*.3;
  }
 }
 return {sync};
}
