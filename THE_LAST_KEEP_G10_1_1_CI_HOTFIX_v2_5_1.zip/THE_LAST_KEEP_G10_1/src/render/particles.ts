import * as THREE from 'three';
import {particleBurst,type VfxKind,type ParticleSpec} from '../game/vfx.ts';

/** Hard capped, one draw-call particle field. Every geometry/material is reused. */
export function createParticles(scene:THREE.Scene,capacity=160){
 type Particle={x:number;y:number;z:number;vx:number;vy:number;vz:number;life:number;ttl:number;size:number;gravity:number;color:string};
 const particles:Particle[]=[];
 const geometry=new THREE.TetrahedronGeometry(1,0);
 const material=new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.88,depthWrite:false,vertexColors:false});
 const mesh=new THREE.InstancedMesh(geometry,material,capacity);mesh.count=0;mesh.frustumCulled=false;mesh.renderOrder=3;scene.add(mesh);
 const dummy=new THREE.Object3D(),tint=new THREE.Color();let serial=0;
 const spawn=(kind:VfxKind,pos:{x:number;y:number;z:number})=>{
  if(!Number.isFinite(pos.x)||!Number.isFinite(pos.y)||!Number.isFinite(pos.z))return;
  const budget=Math.max(0,capacity-particles.length);
  if(!budget)return;
  const specs:ParticleSpec[]=particleBurst(kind,++serial*307,budget);
  for(const p of specs)particles.push({x:pos.x,y:pos.y,z:pos.z,vx:p.vx,vy:p.vy,vz:p.vz,life:p.life,ttl:p.life,size:p.size,gravity:p.gravity,color:p.color});
 };
 const tick=(dt:number)=>{
  const seconds=Math.min(.06,Math.max(0,dt));
  for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.ttl-=seconds;
   if(p.ttl<=0){particles.splice(i,1);continue;}
   p.x+=p.vx*seconds;p.y+=p.vy*seconds;p.z+=p.vz*seconds;p.vy-=p.gravity*seconds;
  }
  for(let i=0;i<particles.length;i++){
   const p=particles[i],fade=Math.max(.02,p.ttl/p.life);
   dummy.position.set(p.x,p.y,p.z);dummy.scale.setScalar(p.size*fade);dummy.rotation.set(p.ttl*3,i*1.2,p.ttl*5);dummy.updateMatrix();
   mesh.setMatrixAt(i,dummy.matrix);tint.set(p.color);mesh.setColorAt(i,tint);
  }
  mesh.count=particles.length;
  if(particles.length){mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;}
 };
 return {spawn,tick,get count(){return particles.length;}};
}
