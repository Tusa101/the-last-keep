import {World} from '../world/model.ts';
import {findRoute,type Waypoint} from './navigation.ts';
import type {Excavation} from '../world/excavation.ts';
export type EnemyState='MOVING'|'ATTACKING_BLOCK'|'REPATHING'|'ARRIVED'|'BOMBARDING';
export class Enemy{
 x=-16;z=0;state:EnemyState='REPATHING';target:Waypoint|null=null;attackTimer=0;
 private route:Waypoint[]=[];private revision=-1;private earthRevision=-1;private repath=0;
 readonly world:World;readonly terrain?:Excavation;speed=2;attackDamage=22;attackInterval=.6;vaultTrenches=false;
 constructor(world:World,terrain?:Excavation){this.world=world;this.terrain=terrain;}
 reset(){this.x=-16;this.z=0;this.state='REPATHING';this.route=[];this.revision=-1;this.earthRevision=-1;this.repath=0;this.attackTimer=0;this.target=null;}
 forceRepath(){this.revision=-1;this.route=[];this.repath=0;this.target=null;this.state='REPATHING';}
 step(dt:number){if(this.state==='ARRIVED')return;const goal={x:9,z:0};if(Math.hypot(this.x-goal.x,this.z-goal.z)<.6){this.state='ARRIVED';return;}
  this.repath-=dt;
  if(this.revision!==this.world.revision||this.earthRevision!==(this.terrain?.revision??-1)||!this.route.length||this.repath<=0){const start={x:Math.round(this.x),z:Math.round(this.z)};
   this.route=findRoute(this.world,start,goal,this.vaultTrenches?undefined:this.terrain)?.cells??[];this.revision=this.world.revision;this.earthRevision=this.terrain?.revision??-1;this.repath=.7;
   if(!this.route.length){this.state='REPATHING';return;}}
  const p=this.route[0];this.target=p;const obs=this.world.groundObstructions(p.x,p.z);
  if(obs.length){this.state='ATTACKING_BLOCK';this.attackTimer+=dt;
   if(this.attackTimer>=this.attackInterval){this.world.damage(obs[0],this.attackDamage);this.attackTimer=0;}return;}
  this.state='MOVING';this.attackTimer=0;
  const dx=p.x-this.x,dz=p.z-this.z,d=Math.hypot(dx,dz),step=Math.min(d,this.speed*dt/(1+(this.vaultTrenches?0:(this.terrain?.depth(Math.round(this.x),Math.round(this.z))??0))*.7));
  if(d>0){this.x+=dx/d*step;this.z+=dz/d*step;}if(d<=step+1e-5)this.route.shift();
 }
}
