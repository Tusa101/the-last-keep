import {LIMIT,type World} from '../world/model.ts';
import type {Waypoint} from './navigation.ts';
import type {Excavation} from '../world/excavation.ts';

const cardinal:readonly [number,number][]=[[1,0],[0,1],[-1,0],[0,-1]];
const key=(x:number,z:number)=>`${x},${z}`;
/** Ground-only friendly movement. Unlike enemy siege pathfinding, workers NEVER
 * enter or break an occupied ground cell. Stop within reach of the work target.
 * Return null when blocked rather than silently teleporting through masonry. */
export function findWorkerRoute(world:World,start:Waypoint,goal:Waypoint,reach=1.05,terrain?:Excavation):Waypoint[]|null{
 if(![start.x,start.z,goal.x,goal.z,reach].every(Number.isFinite)||reach<0||reach>3)return null;
 const sx=Math.round(start.x),sz=Math.round(start.z);
 if(Math.abs(sx)>LIMIT||Math.abs(sz)>LIMIT||Math.abs(goal.x)>LIMIT||Math.abs(goal.z)>LIMIT)return null;
 const origin=key(sx,sz),visited=new Set([origin]),prev=new Map<string,string>(),queue:Waypoint[]=[{x:sx,z:sz}];
 let head=0,found:string|null=null;
 while(head<queue.length){
  const p=queue[head++],k=key(p.x,p.z);
  if(Math.hypot(p.x-goal.x,p.z-goal.z)<=reach){found=k;break;}
  for(const [dx,dz] of cardinal){
   const x=p.x+dx,z=p.z+dz,n=key(x,z);
   if(Math.abs(x)>LIMIT||Math.abs(z)>LIMIT||visited.has(n))continue;
   if(world.groundObstructions(x,z).length||(terrain?.depth(x,z)??0)>=2)continue;
   visited.add(n);prev.set(n,k);queue.push({x,z});
  }
 }
 if(found===null)return null;
 const path:Waypoint[]=[];for(let k=found;k!==origin;k=prev.get(k)!){
  const [x,z]=k.split(',').map(Number);path.push({x,z});
 }
 return path.reverse();
}
