/** Deterministic shallow earthworks, separate from masonry and deposit extraction. */
import {LIMIT,type World} from './model.ts';
export const MAX_DEPTH=3;
/** Three .60m strata: 1.8m at bedrock; deep cuts require terraced exits or jumping. */
export const STRATUM_HEIGHT=0.6;
export type Pit={x:number;z:number;depth:number};
export type DigResult={ok:boolean;reason:string;depth:number;stone:number};
const key=(x:number,z:number)=>`${x},${z}`;
export class Excavation{
 readonly pits=new Map<string,number>();revision=0;
 private world:World;
 constructor(world:World){this.world=world;}
 depth(x:number,z:number){return this.pits.get(key(x,z))??0;}
 groundY(x:number,z:number){const d=this.depth(Math.round(x),Math.round(z));return d===0?0:-STRATUM_HEIGHT*d;}
 canDig(x:number,z:number):{ok:boolean;reason:string}{
  if(!Number.isInteger(x)||!Number.isInteger(z)||Math.abs(x)>LIMIT-1||Math.abs(z)>LIMIT-1)return {ok:false,reason:'Вне зоны земляных работ'};
  if(this.depth(x,z)>=MAX_DEPTH)return {ok:false,reason:'Ниже — неразрушимый древний фундамент'};
  if(this.world.get(x,0,z)||this.world.get(x,1,z))return {ok:false,reason:'Сначала убери постройку'};
  if(Math.hypot(x-9,z)<3||Math.hypot(x+6,z-5)<3||Math.hypot(x-4,z-3)<2)return {ok:false,reason:'Земляные работы запрещены у важных объектов'};
  return {ok:true,reason:'Можно копать'};
 }
 /** One unit of soil removed. Worker labor carries stone to stockpile; manual digging credits instantly. */
 dig(x:number,z:number,creditStone=true):DigResult{
  const check=this.canDig(x,z),depth=this.depth(x,z);
  if(!check.ok)return {ok:false,reason:check.reason,depth,stone:0};
  const next=depth+1;this.pits.set(key(x,z),next);this.revision++;
  const stone=next===3?2:1;if(creditStone)this.world.resources.stone+=stone;
  return {ok:true,reason:'Грунт вынут',depth:next,stone};
 }
 /** Ground-only AI treats trenches as costly terrain, not magical walls. */
 traversalPenalty(x:number,z:number){return this.depth(x,z)*9;}
 snapshot(){return JSON.stringify({schema:1,pits:[...this.pits]});}
 restore(json:string){const raw=JSON.parse(json) as {schema:number;pits:unknown};
  if(raw.schema!==1||!Array.isArray(raw.pits)||raw.pits.length>2000)throw Error('Invalid excavation save');
  const fresh=new Map<string,number>();
  for(const item of raw.pits){if(!Array.isArray(item)||item.length!==2||typeof item[0]!=='string'||!/^[-]?\d+,[-]?\d+$/.test(item[0])||!Number.isInteger(item[1])||item[1]<1||item[1]>MAX_DEPTH)throw Error('Invalid trench');
   const [x,z]=item[0].split(',').map(Number);if(Math.abs(x)>LIMIT-1||Math.abs(z)>LIMIT-1||fresh.has(item[0]))throw Error('Invalid trench cell');fresh.set(item[0],item[1]);}
  this.pits.clear();for(const [k,v] of fresh)this.pits.set(k,v);this.revision++;
 }
 reset(){this.pits.clear();this.revision++;}
 cells():Pit[]{return [...this.pits].map(([k,depth])=>{const [x,z]=k.split(',').map(Number);return {x,z,depth};});}
}
