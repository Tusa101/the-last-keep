# G10.1 Manual Playtest — do not sign off until run on real devices

**Record:** tester/date, exact GitHub Pages URL, `release.json` version, device model, browser version, orientation, screen size, approximate FPS in each wave, and a screenshot for every critical failure.

## Desktop full campaign (15–25 minutes)

1. Open deployed site and verify the WebGL scene, tutorial and active mouse controls; reload and confirm no bootstrap error screen.
2. Gather stone and wood; build a wall, remove a block, repair damaged masonry; save, refresh, then load.
3. Hire worker, queue wall construction and excavation; verify resources move through the stockpile and new walls exist.
4. Dig an actual trench; jump in/out; check hoppers traverse while ordinary raiders reroute.
5. Open Architect, plan walls; open War Room, install **two different** defense machines in specified slots.
6. Fight all **three** waves; inspect combat effects, audio, sound mute, wave reports, and final victory/defeat.
7. Restart new run from results; verify wave/resource reset; load an older compatible save where available.
8. Test force failure path by disabling WebGL in an isolated browser profile (optional) and confirm recovery panel.

## Physical Android Chrome

1. Open **normal tab**, then tap **⛶ Экран** (enter/exit fullscreen where Chrome supports it).
2. Portrait: hold joystick with left thumb and fire with right; check camera swipe, jump, build and repair, no stuck input after tab switch.
3. Landscape: repeat; check top buttons, bottom controls and overlays remain separated.
4. Open and scroll secondary menu to the bottom; tap save/load, War Room, Architect, Progression and the tutorial hints.
5. Test phone navigation bar/safe inset areas. Inspect performance during **10-unit third wave**, rotate the phone mid-session, reload saved game.

## iPhone Safari (if supported)

Verify game, touch controls, audio-unlock and menu safe areas. Some Safari versions do not provide Fullscreen API to ordinary webpages: run from Home Screen (standalone mode) when needed and document the actual behavior rather than counting it as an app defect.

## Exit criteria

Critical bugs count = 0; no repeatable JS/WebGL bootstrap crashes; controls and results buttons work in both orientations; user can complete a real run; performance is acceptable for intended minimum device. If any criterion fails, G10.1 stays a **release candidate**.
