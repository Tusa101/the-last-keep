# G8.1 — War Room, Preparation Flow & Balance Observability (v2.0)

## Intent

Strengthen the existing finite three-wave preparation/build/defend/recover loop **without inflating the feature count**. The MVP's balance cannot yet be claimed solved: a real, playable WebGL build and multiple complete runs on phone/desktop are still necessary. The main deliverable is a pre-wave **War Room** that makes meaningful preparation choices visible and controllable.

## Implemented

1. **Pausable tactical preparation screen** (`R` desktop; `☰ → ⚑ Военный совет` mobile). Reports the *authored* next wave's types and quantities, likely attack directions, known counterplay, Nexus health, physical material stocks and finite unmined reserves, number of workers, damaged masonry count, and existing emplacement assignments. Its danger/caution/ready labels are heuristics rather than forecasts or difficulty scores.
2. **Explicit choice of turret slot** in a fixed pool of three existing spots. Previously `I` and `O` could only install in the next free slot. The War Room now allows slot 1, 2 or 3, then individual choice of carrot tower, cheese mortar or syrup sprayer. Installation goes through `Defenses.install` — same resource prices, occupancy, phase guards and authoritative costs as before. Clicking/selecting alone NEVER spends resources. The legacy quick install shortcut remains.
3. **Preparation/transition controls.** When opening during `RESULT`, there is a `Начать подготовку` button that transitions to `PREP` (without repairing blocks or refilling resources). During `PREP`/`WARNING`, the War Room offers `Начать осаду сейчас`. Simulation and preparation countdown freeze while the overlay is open. The player cannot harvest or exploit free NPC productivity while it is open.
4. **Integrated routes to progression**, accessible from inside the briefing; it closes one modal before opening the other.
5. **Research phase fix:** purchases of legacy `5/6/7` upgrades now only work during `PREP` or `RESULT`. It was previously possible to spend research while defeated/victorious; this was inconsistent with the progression tree.
6. **Touch safe modal layout:** scrollable and sized for portrait, landscape, tall/narrow screens, with 44px minimum buttons, focus outline, safe-area insets and a distinct z-index above the touch controller. Existing touch controls were not moved.
7. **CI browser smoke extension** (`scripts/smoke.mjs`): desktop briefing opening and closing, 3 slots and 3 kinds, actual installation in slot 3, mobile menu briefing entry, screenshot and modal overflow assertion. Will execute in CI **only after** installing dependencies and launching a browser.

## Defensive strategic summary

- Wave 1: four jelly soldiers, no worker requirement; learn manual defense and repair the initial gate gap.
- Wave 2: jumping scouts render trenches insufficient alone; minimum viable counter is a wall and/or a turret; first worker becomes available after wave 1.
- Wave 3: ranged pudding artillery damages masonry; exposed walls have to be supported by return fire. War Room warns when there are no automatic defenses.

**No silent changes** were made to initial resource stock (90 stone, 45 wood), deposits, upgrade costs, worker throughput, battle HP, wave timers, existing three scripted wave compositions, weapon cooldowns, or game victory/defeat conditions. This avoids untested balance changes in the absence of real full-run evidence.

## Tests

- `npm test`: **130/130 pass** (118 preexisting + 12 new), Node 22.
- `npm run typecheck:core`: **pass**.
- `npm run typecheck`: **blocked** by missing `three` and `@types/three` npm dependencies (the existing two implicit-any errors are consequences of missing Three.js types).
- `npm run build`: **not successfully verified** (npm registry DNS `EAI_AGAIN`).
- Playwright / real Android / iOS: **not run** in this environment. Smoke code exists but is not proof of successful execution.

## What remains for balance work

Before claiming gameplay balance, capture at least 5 runs on each target screen class and track:

| Metric | Baseline target / decision rule |
| --- | --- |
| Full three-wave completion | Measure survival rate; avoid both near-certain wins and impossible first waves |
| Damage to Nexus by wave | Ensure siege 2 creates pressure without forcing a restart in every run |
| Resource surplus before each wave | Look for dominant strategies or long idle periods |
| Defense combinations selected | Confirm that carrot/cheese/syrup choices are each useful in some circumstances |
| Worker delivery time vs prep timer | Ensure travel routes don't make automation meaningless |
| Preparation time usage | Review whether 90 s encourages meaningful priorities or rushed UI management |
| Mobile fps and UI collisions | Verify 360×740 portrait and 740×360 landscape, physical Android, touch inputs |

Only after real playtests should we tune costs, rewards, wave timings or combat numbers. **Next milestone: G9 Visual/Audio Feedback + actual integration QA** (or corrective G8.2 if CI smoke fails).

## Releases / deploy

Drop `THE_LAST_KEEP_G8_1_WAR_ROOM_v2_0.zip` into the repo root after adding the GitHub Pages Starter's `.github/workflows/deploy.yml` and `scripts/select_latest.py` outside the archive. The version selector numerically prefers `v2_0` to `v1_9`. Check the Actions run and browser smoke artifacts before considering the deployment verified.
