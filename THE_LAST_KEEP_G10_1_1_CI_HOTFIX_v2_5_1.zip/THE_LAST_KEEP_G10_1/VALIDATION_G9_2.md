# G9.2 — Verification report

## Executed checks

- `npm test` — **147 passed / 147 total**; includes 9 new tutorial unit tests (event gating, out-of-order evidence, persistence, malformed payloads, optional dismissal, completion, reset).
- `npm run typecheck:core` — **passed** (TypeScript global tsc).
- Independent `tsc --noEmit --strict ... src/game/tutorial.ts src/ui/tutorial.ts src/ui/mobile.ts` — **passed**.
- TypeScript `transpileModule` on changed interface/game entry modules — **0 syntax diagnostics**.
- Chromium (Python Playwright): **11/11 mobile viewport fixture checks passed** at 280×653, 320×568, 360×640, 390×844, 430×932, 568×320, 667×375, 740×360, 844×390, 932×430, 1024×600. Main HUD status, tutorial card, joystick, main actions and top buttons had no overlaps. Verified that performing the first objective reveals the CTA, tapping it opens/scolls to/highlights Gather, guide is suppressed on menu opening, and that Hide works. No WebGL was rendered in this fixture.
- ZIP integrity, version selection and archive extraction checked during packaging.

## Not verified

- `npm run build`: **not run successfully** — npm registry `EAI_AGAIN`, Three.js/Vite/@types/three not available locally. Full app `tsc` produces missing `three` type/module errors, so its result must not be reported as passing.
- The repository's JavaScript Playwright test (`npm run smoke:tutorial`) and full browser WebGL test (`npm run smoke`) **not run here**; they are configured for GitHub Actions after `npm install` and Playwright browser install.
- Physical Android/iPhone playtest **not performed**; mobile responsiveness does not prove smooth FPS or Fullscreen API behavior on a device.

## Next gate (G10)

Obtain a real successful npm/Vite build and playable GitHub Pages URL, execute 3-wave end-to-end WebGL sessions on desktop and Android Chrome, inspect console and render errors, verify save restoration, wave results and FPS. Only then call the vertical slice playable and ready for external testing.
