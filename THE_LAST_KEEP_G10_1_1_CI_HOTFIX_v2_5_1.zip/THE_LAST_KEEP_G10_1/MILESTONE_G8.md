# G8 — Castle Progression & Economy (v1.9)

## Goal

Make each 90-second preparation interval a choice between constructing more defenses, hiring labor, repairing existing masonry, or permanently developing the castle. Keep resource earning physical: wave rewards yield research, quarries/woodlots supply limited materials, and workers must transport harvested materials to the stockpile.

## Upgrade system — 3 branches × 2 tiers

| Branch | Tier | Requirements | Cost | Actual mechanical effect |
| --- | --- | --- | --- | --- |
| Masonry | 1 | Wave 1 cleared; PREP/RESULT | 12 research, 18 stone | +15 HP to manual and worker repairs |
| Masonry | 2 | Wave 2 cleared; PREP/RESULT | 22 research, 28 stone, 4 wood | Further +15 repair HP; 15% reduction to Nexus damage from arriving/timeout enemies |
| Logistics | 1 | Wave 1 cleared; PREP/RESULT | 12 research, 14 wood | Workers carry 10 stone / 8 wood instead of 8 / 6 |
| Logistics | 2 | Wave 2 cleared; PREP/RESULT | 22 research, 7 stone, 20 wood | Workers carry 12 stone / 10 wood; harvesting 1.6→1.2 s, building 1.1→0.85 s, digging 1.8→1.4 s |
| Ordnance | 1 | Wave 1 cleared; PREP/RESULT | 18 research, 10 stone, 8 wood | +25% turret/mortar damage; +0.35 s syrup stun |
| Ordnance | 2 | Wave 2 cleared; PREP/RESULT | 28 research, 18 stone, 14 wood | Total +50% turret/mortar damage; total +0.7 s syrup stun; 15% faster cooldown |

All prices are paid **atomically** at the instant of purchase. A failed purchase does not consume resources. Upgrades are permanent for the current run, do not grant material resources, and do not bypass existing constraints.

Legacy `5/6/7` research remains available, spending the **same research currency**. A player choosing the new progression therefore gives up an opportunity to purchase carrot weapon, upgraded Nexus trap charges, or classic repair research. There are three combat waves; no endless mode is implemented.

## Weapon placement: choice, not fixed sequence

There are still **three physical emplacement sites**, installed in ascending free-slot order. The player can choose **which** machine is placed at each site, including duplicates. Selection and installation are separate actions: `I` cycles carrot turret → cheese mortar → syrup sprayer; `O` installs the selected one, if the site is empty, resources are sufficient, and the phase is PREP/RESULT. On mobile, both controls are in `☰` menu.

- Carrot turret: 9 wood, 3 stone.
- Cheese mortar: 6 wood, 12 stone.
- Syrup sprayer: 12 wood, 4 stone.

Once built, an emplacement cannot be re-specialized yet. This is intended as a decision with consequences, not an adjustable free bonus.

## User interface

- Desktop `U`: toggles a scrollable and keyboard-focusable development screen; close with `U` or the ✕ button.
- Mobile `☰ → ⚒ Развитие замка`: separate full-screen overlay and large touch-sized buttons, usable in portrait and landscape. Previous permanent mobile buttons remain unchanged.
- Live status, current tiers, exact costs, effects, affordability feedback and wallet balance are displayed inside the development screen.
- Game simulation pauses while the development overlay is open; purchases remain locked in WARNING/SIEGE/DEFEAT/VICTORY.
- Desktop HUD shows a compact branch level summary. The touch HUD hides that extra text to avoid crowding.
- Corrected previously conflicting `V` binding (vertical construction / defense install): defense controls are now `I` and `O`.

## Save and validation

The envelope remains `version:4` for compatibility with existing v2/v3/v4 user saves. A new **optional** `progression` JSON field stores three integer levels. Loading validates the additional data in a sandbox world before touching current state; missing progression field resets branch levels to zero. Bonus values are derived after load and never independently persisted. Worker cargo save validation now accepts logistics-upgraded transport of up to 12 items; the normal delivery rule still credits the stockpile only once.

## Known limits / follow-up

- This is an *economy/progression prototype*, not a fully balanced metagame. Costs and cooldowns require browser playtests on multiple difficulty profiles.
- Three waves, two workers maximum, three fixed weapon slots, finite above-ground resource deposits. No market, passive production, turret dismantling, or free-choice tower placement.
- Physical Android/iOS responsiveness is not yet verified in the current build environment.
- No claim of a successful full Vite/WebGL build: npm registry unavailable in isolated environment.

## Suggested G8.1

Run verified browser and phone playtests with the real deployed app; tune costs / wave pacing / worker tasks; add explicit pre-wave loadout screen, make defense emplacement placement more flexible, and introduce a short onboarding/tutorial loop. Fix real defects before adding further waves or content.
