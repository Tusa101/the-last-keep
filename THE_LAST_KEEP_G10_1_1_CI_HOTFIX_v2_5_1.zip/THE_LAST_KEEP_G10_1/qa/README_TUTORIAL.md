Screenshots in this folder are real headless Chromium renders of the CSS/mobile-controls/tutorial UI *only*, with a blank background; they are not real Three.js game screenshots.
