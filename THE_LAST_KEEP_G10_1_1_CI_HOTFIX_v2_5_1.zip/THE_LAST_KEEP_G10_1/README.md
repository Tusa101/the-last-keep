# THE LAST KEEP — G10.1 v2.5 Demo Release Candidate

**Status:** RC — offline unit and UI recovery tests passed, but full production Vite/WebGL build and real-device acceptance are **pending**. Do not mistake this source archive for a certified public release. The game includes the existing 3-wave vertical slice with all G10 systems.

**New in v2.5:** dependency-free preboot watchdog and touch-friendly error recovery, real first-frame health signal, better GitHub Pages CI release gating, `release.json` version receipt, production Chromium mobile viewport matrix, Pages root/subpath handling. No new gameplay features or balance numbers were introduced.

For release details see **`MILESTONE_G10_1.md`** and **`VALIDATION_G10_1.md`**. For deployment see **`DEPLOY_PAGES.md`**, and for final human device checks see **`DEVICE_PLAYTEST.md`**.

## Quick start

```bash
npm install
npm test
npm run check:balance
npm run dev
```

The new startup monitor displays useful recovery buttons if the game cannot start rather than leaving a black WebGL canvas. Saved games are **not** cleared when reloading.

---

# THE LAST KEEP — G10 Vertical Slice (v2.4)

**Latest build:** a three-wave, single-run vertical slice with a real debrief scorecard, victory/failure summary, touch-friendly report, save compatibility and a deterministic balance regression. Start with [`MILESTONE_G10.md`](MILESTONE_G10.md), then [`VALIDATION_G10.md`](VALIDATION_G10.md).

**This is not yet a certified playable release:** Three.js/Vite npm dependencies were unreachable in the development environment, so a full Vite build and full WebGL run have not been verified here. GitHub Actions now checks the production bundle (including Pages subpath) when CI runs online.

**Offline quick checks:** `npm test` (152 tests), `npm run typecheck:core`, `npm run check:balance`. **Online build:** `npm install && npm run build`; run Playwright production smoke through the GitHub workflow.

**GitHub Pages:** upload `THE_LAST_KEEP_G10_VERTICAL_SLICE_v2_4.zip` at the repository root after installing the workflow and `scripts/select_latest.py` in the real repository outside archives. In Settings → Pages, select **GitHub Actions** as the publishing source.

---

# THE LAST KEEP — v2.3 (G9.2: Tutorial & Player Experience)

**What's new:** a non-blocking, objective-based eight-step tutorial that reacts to real player actions (movement, harvesting, construction, defenses, first wave, victory, first worker and architect). Interactive guide supports mobile action spotlighting, optional dismissal, and resuming/restarting independently from existing save data. The post-wave result panel now contains a real clickable continue/new-run button for touch screens.

**Desktop:** `F1` toggles the guide, `Shift+F1` restarts it. **Phone:** `☰ Menu → Settings → ⚑ Обучение заново`, or dismiss with `✕` on the guide. A guide action button helps locate deep mobile menu commands; it **does not execute** expensive or dangerous actions automatically.

**Verified:** 147/147 Node tests; core TypeScript and independent tutorial/touch TypeScript checks; Chromium UI-only fixture for 11 touch viewport sizes including narrow landscape, with no collisions between onboarding panel and the main controls. Real Three.js WebGL + production Vite build + physical mobile tests have **not** been verified (npm registry unavailable). See `MILESTONE_G9_2.md`, `VALIDATION_G9_2.md`.

**GitHub Pages:** upload `THE_LAST_KEEP_G9_2_TUTORIAL_PLAYER_EXPERIENCE_v2_3.zip` to the root of the repo with the existing Starter workflow. The ZIP selector should choose v2.3. The included workflow runs `smoke:tutorial` in addition to the existing full game smoke.

---

# THE LAST KEEP — v2.2 (G9.1 Mobile Quality)

**This release focuses on the smartphone interface.** Persistent touch controls use separate grid/corner zones, the status strip is condensed, the mobile menu is scrollable and organized into four groups, and joystick input is bound to its rendered size. Fullscreen button labels reflect the browser's current fullscreen state. The `qa/` images are **CSS+mobile-controls-only browser fixtures**, not rendered WebGL gameplay screenshots.

**Verification:** 138/138 Node tests pass; TypeScript core typecheck passes; 11 touch viewport layouts were checked in real headless Chromium with no control collisions or offscreen controls. The full app build and physical phone playtests are still pending because npm dependencies were inaccessible in this environment. See [`MILESTONE_G9_1.md`](MILESTONE_G9_1.md) and [`VALIDATION_G9_1.md`](VALIDATION_G9_1.md).

**To deploy:** upload `THE_LAST_KEEP_G10_VERTICAL_SLICE_v2_4.zip` to the root of the repository containing the GitHub Pages starter's `.github/workflows/deploy.yml` and `scripts/select_latest.py`. For local testing use `npm install && npm run dev`. The Pages workflow now includes `npm run smoke:ui` (browser viewport regression test) before its full-game WebGL smoke test.

---

# THE LAST KEEP — G9 / Visual & Audio Polish (v2.1)

**Game:** playable-source 3D first-person medieval castle-building and siege prototype featuring deliberately absurd alchemical attackers and defenses. **Tech:** TypeScript, Three.js, Vite. Intended for desktop and mobile browsers.

## Quick start

Requires **Node.js 22+** (unit tests use Node's experimental built-in TypeScript stripping).

```bash
npm install
npm test
npm run typecheck:core
npm run dev
```

Open the URL printed by Vite. Run `npm run build` for a production bundle. Run `npm run smoke` against a running local server to test browser boot, mobile menu, WebGL, War Room and progression UI (Playwright + Chromium must be installed). Full build and browser tests require npm connectivity; they were **not** verified in the artifact author's isolated environment.

## What changed in v2.0 — G8.1

- **War Room / Военный совет:** desktop `R`; mobile `☰ → ⚑ Военный совет`. A scrollable tactical briefing presents the upcoming authored wave, enemy composition, attack directions, Nexus health, wall damage, resource deposits, worker count, and current emplacements.
- **Physical defense slot choice:** choose 1 of 3 actual sites and choose carrot turret, cheese mortar, or syrup sprayer for that site. Costs remain exactly the same; resources are charged only when installation succeeds. This removes the earlier forced ascending-slot placement **in the War Room**; `I` + `O` still installs to the next free slot as a quick shortcut.
- **Preparation workflow:** start the next preparation from the post-wave report or trigger the current siege directly from the briefing. The game timer does not advance while the War Room is open. Opening the room never spends materials automatically.
- **Honest readiness checks:** advisory status of damaged/critically damaged blocks, Nexus, finite material deposits, basic wave counters. This is *not* a battle outcome prediction.
- **Balance/consistency fix:** the classic 5/6/7 research purchases no longer work after victory or defeat. Existing saves remain compatible, no new save schema is required.
- **Quality guardrails:** 12 new unit tests and expanded Playwright smoke checks for desktop/mobile War Room. Full WebGL/browser verification is still pending installation of npm dependencies.

See [`MILESTONE_G8_1.md`](MILESTONE_G8_1.md).

## What changed in v2.1 — G9

- **Readability of combat:** 11 authored colour/physics particle presets, pooled into a single 160-particle instanced mesh (normally just one extra draw call). Hits, enemy eliminations, Nexus damage, breaching, trap triggers, building and repairs now have distinct debris/sparks.
- **Defense silhouettes:** carrot cannon, brass cheese mortar and syrup tank have distinct original low-poly models. Emplacements turn toward their targets and show brief visual projectiles.
- **Audio:** 11 short synthesized sounds via Web Audio (no downloads / third-party sound assets). User gesture gate, polyphony ceiling, rapid-hit throttling, graceful fallback without audio permissions. Toggle on desktop with **M**, on touch via **☰ → Звук**.
- **Damage clarity:** a pointer-transparent edge vignette appears when the Nexus takes damage and remains subtly visible below 35 HP. The overlay does not introduce a new touch control.
- **State fidelity:** VFX is decorative and does not change authoritative Siege, resource, collision or save logic. Changing emplacement kind when restoring a different save now rebuilds its visual model.
- **Regression:** 8 new pure simulation and audio tests (138 in total), a core TypeScript check and Node TS-syntax checks. Full Vite build / real browser playback **not validated here** because npm registry DNS resolution failed; see `VALIDATION_G9.md`.

See [`MILESTONE_G9.md`](MILESTONE_G9.md) and [`VALIDATION_G9.md`](VALIDATION_G9.md).

## Previous milestone: v2.0 — G8.1

The War Room, readiness scoring, emplacement selection and battle controls from v2.0 are retained. See [`MILESTONE_G8_1.md`](MILESTONE_G8_1.md).

## Previous milestone: v1.9 — G8

- **Three development branches (two tiers each):** masonry, logistics, alchemical artillery. Unlocks cost both research (earned from sieges) and actual stone/wood. Purchases require completed waves and PREP/RESULT phase.
- **Masonry:** player and NPC repairs restore more HP; rank 2 also reduces incoming Nexus damage by 15%.
- **Logistics:** workers carry more per trip; rank 2 accelerates harvesting, building and digging. Harvestable deposits remain finite and transport still requires walking to stockpile.
- **Ordnance:** carrot turrets and cheese mortars deal 25%/50% more damage; syrup stuns last longer; rank 2 accelerates firing.
- **Choose defense type per emplacement**, instead of always being forced to build carrot → cheese → syrup in that order. Three fixed physical slots remain; available resources make different combinations meaningful.
- **Development screen:** desktop **U**, mobile **☰ → ⚒ Развитие замка**. Explicit purchase buttons show the next effect and exact resource costs. Shows why a purchase is locked.
- **Desktop key conflict fixed:** `V` now exclusively switches vertical construction. `I` cycles defense selection and `O` builds selected defense.
- Saves include progression (older v2/v3/v4 saves load with an empty development tree). The progression save is validated before the live game state changes.
- Extended automated tests + browser smoke specification.

See [`MILESTONE_G8.md`](MILESTONE_G8.md) for cost table, balancing and limitations. Earlier milestones remain in `MILESTONE_G*.md`.

## Controls

**Desktop:** `WASD` move, mouse look, `Shift + left click` fire, `right click` build, `G` start siege early, `N` start next prep, `P` architect view, `B` line, `V` vertical, `Z` dig, `Shift+Z` order digging, `J` hire, `T` queue blueprint, `Y` worker priority, `C` cancel orders, **`U` development**, **`R` War Room**, **`I` choose defense**, **`O` install defense**, `5/6/7` legacy research, `K/L` save/load.

**Mobile:** left joystick and right drag to look, fire/build/remove/jump buttons, **☰** menu for architect, **War Room**, development, defense selection/installation, workers, gathering and save/load. **⛶ Экран** requests fullscreen where supported. Fullscreen API support depends on browser and platform.

## GitHub Pages: upload ZIP without unpacking

On a repository configured with the previously supplied GitHub Pages Starter, drop **`THE_LAST_KEEP_G10_VERTICAL_SLICE_v2_4.zip`** into the repository root. The workflow in `.github/workflows/deploy.yml` uses `scripts/select_latest.py` to pick the highest version number, extract the source, run unit tests, install dependencies, build and attempt browser smoke before publishing. Configure **Settings → Pages → Source → GitHub Actions** once. If CI fails, inspect its logs rather than assuming the game is deployed.

The ZIP itself contains a copy of the workflow and selector in case you are configuring the repository anew; GitHub Actions requires the workflow to exist **outside the ZIP** under `.github/workflows/deploy.yml` in the repository.

## Verification boundaries

Core TypeScript typecheck and Node unit tests are repeatable offline. The full application build, actual WebGL runtime and Android/iOS physical devices **have not been verified here** (`npm install` blocked by DNS error `EAI_AGAIN`). GitHub CI performs integration tests after installing dependencies. Report any failures from Actions to prioritize fixes.
