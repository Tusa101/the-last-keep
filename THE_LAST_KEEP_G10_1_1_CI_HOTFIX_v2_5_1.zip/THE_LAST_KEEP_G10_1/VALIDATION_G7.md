# G7 — Validation record

Local environment: Node v22.16.0; globally installed TypeScript v5.8.3.

| Command | Observed status |
|---|---|
| `npm test` | PASS, 100 tests |
| `npm run typecheck:core` | PASS |
| TypeScript transpile syntax check (`src/main.ts`, `src/render/{scene,characters}.ts`, `src/ui/minimap.ts`) | PASS |
| `npm install --no-audit --no-fund --fetch-retries=0 --fetch-timeout=6000` | FAILED, `EAI_AGAIN registry.npmjs.org` |
| `npm run build` | Not runnable: missing Three.js, Vite, `@types/three` |
| WebGL Chrome / mobile device | NOT RUN |

Do not interpret unit test success as proof of deployability or absence of device-specific defects.
