# G9 — Visual & Audio Polish (v2.1)

## Scope and design goal

Improve the clarity and atmosphere of combat without replacing the medieval architectural style. Absurd alchemical weapons and enemies should read as deliberately comic against a serious castle. The milestone is **presentation polishing**, not another gameplay rebalance.

### New visual effects

The new `src/game/vfx.ts` provides 11 reusable effects (`hit`, `kill`, `breach`, `trap`, `nexus`, `pudding`, `carrotTower`, `cheeseMortar`, `syrupSprayer`, `build`, `repair`). All particle velocities/colours/scale/lifetime are deterministic per seed and bounded. `src/render/particles.ts` displays up to **160** particles in **one InstancedMesh**; no entity, collision, resource or damage state is written by the renderer. Impact particles have gravity and shrink as they expire. Attack and construction VFX are cosmetic, not authoritative damage hitboxes.

For castle changes, `src/game/worldFeedback.ts` compares before/after block states. A single world revision emits **at most nine** visual feedback locations. Large collapse chains and loading saves do not cause runaway allocations or visual floods. Block placement produces stone dust, repair produces a mint glint, masonry impacts produce impact chips, and destruction produces debris.

### Defense appearance and firing

`src/render/defenseModels.ts`: carrot tower has brass barrel and green-tipped orange carrot, cheese mortar has a heavy angled brass tube with stylised ammunition, syrup tank has its own copper tank, pipe and nozzle. Each emplacement is clearly different at the same camera distance. It turns towards the target when firing; the carrot and cheese visually travel on a brief arc. Their **gameplay impacts remain immediate** according to the authoritative `Defenses.step` code. Visual arc timing is not projectile collision timing.

Defense firing events previously accumulated in `Defenses.events` but had no presentation consumer. `src/main.ts` now consumes and clears them once per frame to drive VFX and sound, including area attacks and syrup.

When loading a saved game whose defense slot has a different kind, the renderer now recreates the correct model (not just the old model by slot).

### Audio

`src/game/audio.ts`: distinct synthesized presets for medieval bolt, carrot, wall hit, trap, alarm, enemy death, Nexus hit, breach, turret, cheese and syrup. Audio only initializes after a gesture. Maximum 12 simultaneous voices; rapid repetitive effects are throttled. If the Web Audio API is disabled, gameplay continues silently. The game ships no downloadable audio files.

**Controls:** desktop `M` toggles audio. On touch: `☰ Меню → 🔊 Звук` (toggle in secondary menu; no extra permanent buttons).

### Screen feedback

When the Nexus is damaged a subtle screen-edge vignette signals danger; below 35 HP a weak warning persists. The overlay has `pointer-events:none`, sits underneath interactive UI, and supports reduced-motion preference. It does not block aiming or tapping.

### Compatibility / performance

- World, Siege, Worker and save schemas are unchanged.
- Mobile fullscreen action, compact main controls, Architect and War Room continue from v2.0.
- VFX renderer uses 160 maximum live particles, 9 block effects per state change, and no downloadable textures or audio.
- Scene renderer still needs Three.js installed through npm. Physical Android/iOS FPS and mobile-screen validation remain outstanding.

## Acceptance checklist for real playtests

1. Build/launch with `npm install && npm run build && npm run dev`.
2. On desktop, open War Room, buy each defense type and observe three distinct models.
3. Start a siege, verify spark/debris/splashes when shots connect and model targeting follows enemies.
4. Build/remove/repair walls and confirm cosmetic world VFX without changing resource amounts.
5. Allow an enemy through to damage Nexus; observe a brief vignette without interrupted control.
6. Play on Android portrait and landscape; verify menus and joystick do not overlap and frame rate remains acceptable.
7. Toggle touch sound; verify sound remains off when muted and the game remains playable if audio is blocked.
8. Save/load before and after changing emplacements; confirm restored model matches restored gameplay type.

## Known limitations

- Full production build, Playwright browser smoke and physical phone are **not confirmed** in the isolated environment (npm registry is unreachable).
- No professionally recorded soundtrack, character voice lines, character death ragdolls or authored cutscenes yet.
- Defense projectiles are *presentational*: their paths are not gameplay simulation and impacts are applied immediately.
- Combat readability and timing have not been tuned by human playtesters on actual handsets.

## Next suggested milestone — G9.1

Run a verified end-to-end browser + actual Android playtest, audit CSS at 360×740 and short landscape heights, fix CI failures and frame-time spikes; only then choose whether to add a short onboarding sequence and demo polish.
