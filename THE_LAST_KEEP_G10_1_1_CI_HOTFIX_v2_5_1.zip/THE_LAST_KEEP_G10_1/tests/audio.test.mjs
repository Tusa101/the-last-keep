import test from 'node:test';
import assert from 'node:assert/strict';
import {Sfx} from '../src/game/audio.ts';
test('SFX never starts Web Audio without an explicit unlock gesture',()=>{
 const previous=globalThis.AudioContext;let started=0,constructed=0;
 class FakeAudioContext{
  constructor(){constructed++;} state='running';currentTime=4;destination={};
  createOscillator(){return {type:'',frequency:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},start(){started++;},stop(){},addEventListener(){},disconnect(){}};}
  createGain(){return {gain:{setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},disconnect(){}};}
  createBiquadFilter(){return {type:'',frequency:{setValueAtTime(){}},connect(){},disconnect(){}};}
 }
 try{
  globalThis.AudioContext=FakeAudioContext;const audio=new Sfx();
  audio.play('bolt');assert.equal(constructed,0);assert.equal(started,0);
  audio.unlock();assert.equal(constructed,1);
  audio.play('hit');assert.equal(started,1);
  audio.play('hit');assert.equal(started,1,'rapid identical hits should be throttled');
  audio.enabled=false;audio.play('cheese');assert.equal(started,1,'mute prevents new voices');
 }finally{globalThis.AudioContext=previous;}
});
test('SFX ignores absent Web Audio API gracefully',()=>{
 const old=globalThis.AudioContext;
 try{delete globalThis.AudioContext;const audio=new Sfx();audio.unlock();audio.play('nexus');assert.ok(true);}finally{globalThis.AudioContext=old;}
});
