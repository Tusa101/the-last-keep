import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Excavation,MAX_DEPTH} from '../src/world/excavation.ts';
test('dig three layers then hit ancient foundation',()=>{const w=new World(),e=new Excavation(w);for(let d=1;d<=MAX_DEPTH;d++){const r=e.dig(1,10);assert.equal(r.ok,true);assert.equal(r.depth,d);}assert.equal(e.dig(1,10).ok,false);assert.equal(w.resources.stone,94);});
test('building and nexus protections',()=>{const w=new World(),e=new Excavation(w);w.seed({x:1,y:0,z:10});assert.equal(e.dig(1,10).ok,false);assert.equal(e.dig(9,0).ok,false);assert.equal(e.dig(22,0).ok,false);});
test('save roundtrip and transactional invalid load',()=>{const w=new World(),e=new Excavation(w);e.dig(2,10);const saved=e.snapshot();const restored=new Excavation(w);restored.restore(saved);assert.equal(restored.depth(2,10),1);assert.throws(()=>restored.restore('{"schema":1,"pits":[["2,10",9]]}'));assert.equal(restored.depth(2,10),1);});
test('trench route penalty increases by depth',()=>{const e=new Excavation(new World());assert.equal(e.traversalPenalty(2,10),0);e.dig(2,10);assert.equal(e.traversalPenalty(2,10),9);});
