import test from 'node:test';
import assert from 'node:assert/strict';
import {Tutorial,TUTORIAL_STEPS} from '../src/game/tutorial.ts';

test('tutorial has eight unique objectives, independent of game data and ordered',()=>{
 assert.equal(TUTORIAL_STEPS.length,8);
 assert.equal(new Set(TUTORIAL_STEPS.map(step=>step.id)).size,8);
 assert.ok(TUTORIAL_STEPS.every(step=>step.title&&step.description&&step.mobile&&step.desktop));
});
test('first objective advances only on correct gameplay evidence',()=>{
 const guide=new Tutorial();
 assert.equal(guide.step.id,'moved');
 assert.equal(guide.mark('harvested'),false);
 assert.equal(guide.step.id,'moved');
 assert.equal(guide.mark('moved'),true);
 assert.equal(guide.step.id,'built'); // harvested was completed early, should not block
 assert.equal(guide.progress.current,3);
});
test('a premature wave completion cannot skip unperformed building and defenses',()=>{
 const guide=new Tutorial();
 guide.mark('waveWon');guide.mark('workerHired');guide.mark('architectOpened');guide.mark('waveStarted');
 guide.mark('moved');guide.mark('harvested');
 assert.equal(guide.step.id,'built');
 guide.mark('built');assert.equal(guide.step.id,'defense');
 guide.mark('defense');assert.equal(guide.complete,true);
});
test('duplicate events are idempotent and progress stays bounded',()=>{
 const guide=new Tutorial();
 for(let i=0;i<20;i++)assert.equal(guide.mark('moved'),i===0);
 assert.equal(guide.index,1);
 for(const step of TUTORIAL_STEPS)guide.mark(step.id);
 assert.equal(guide.complete,true);
 assert.equal(guide.step,null);
 for(const step of TUTORIAL_STEPS)assert.equal(guide.mark(step.id),false);
 assert.equal(guide.progress.current,8);
});
test('tutorial visible setting does not alter gameplay objective tracking',()=>{
 const guide=new Tutorial();
 assert.equal(guide.toggle(),false);
 assert.equal(guide.mark('moved'),true);
 assert.equal(guide.index,1);
 assert.equal(guide.toggle(),true);
});
test('saving and restoring partial progress including out-of-order events',()=>{
 const guide=new Tutorial();
 guide.mark('architectOpened');guide.mark('harvested');guide.mark('moved');guide.toggle();
 const other=new Tutorial();
 assert.equal(other.restore(JSON.parse(JSON.stringify(guide.snapshot()))),true);
 assert.deepEqual(other.snapshot(),guide.snapshot());
 other.toggle();other.mark('built');other.mark('defense');other.mark('waveStarted');other.mark('waveWon');other.mark('workerHired');
 assert.equal(other.complete,true);
});
test('complete state survives save/restore with all evidence',()=>{
 const guide=new Tutorial();
 for(const step of TUTORIAL_STEPS)guide.mark(step.id);
 const other=new Tutorial();assert.equal(other.restore(guide.snapshot()),true);
 assert.equal(other.complete,true);
});
test('malformed saves must not corrupt active tutorial',()=>{
 const guide=new Tutorial();guide.mark('moved');const before=guide.snapshot();
 for(const payload of [null,{},[],{version:2,index:1,enabled:true,seen:['moved']},
  {version:1,index:-1,enabled:true,seen:[]},
  {version:1,index:100,enabled:true,seen:[]},
  {version:1,index:1.5,enabled:true,seen:['moved']},
  {version:1,index:1,enabled:'yes',seen:['moved']},
  {version:1,index:1,enabled:true,seen:['unsupported']},
  {version:1,index:1,enabled:true,seen:[]},
  {version:1,index:2,enabled:true,seen:['moved']},
  {version:1,index:8,enabled:true,seen:['moved']},
  {version:1,index:0,enabled:true,seen:Array(100).fill('moved')}]){
  assert.equal(guide.restore(payload),false,JSON.stringify(payload));
  assert.deepEqual(guide.snapshot(),before);
 }
});
test('reset re-enables and clears all collected objectives',()=>{
 const guide=new Tutorial();guide.mark('moved');guide.mark('built');guide.toggle();guide.reset();
 assert.deepEqual(guide.snapshot(),{version:1,index:0,enabled:true,seen:[]});
});
