import test from 'node:test';
import assert from 'node:assert/strict';
import {particleBurst,VFX_RECIPES} from '../src/game/vfx.ts';
test('every G9 VFX recipe emits bounded, finite, valid particles',()=>{
 for(const kind of Object.keys(VFX_RECIPES)){
  const list=particleBurst(kind,99);
  assert.equal(list.length,VFX_RECIPES[kind].count);
  for(const p of list){assert.ok([p.vx,p.vy,p.vz,p.life,p.size,p.gravity].every(Number.isFinite));assert.ok(p.life>0&&p.size>0&&p.gravity>0);assert.match(p.color,/^#[0-9a-fA-F]{6}$/);}
 }
});
test('effects are deterministic per seed, differ between seeds',()=>{
 assert.deepEqual(particleBurst('cheeseMortar',12),particleBurst('cheeseMortar',12));
 assert.notDeepEqual(particleBurst('cheeseMortar',12),particleBurst('cheeseMortar',13));
});
test('effects respect explicit remaining render budget',()=>{
 assert.equal(particleBurst('nexus',0,3).length,3);
 assert.equal(particleBurst('hit',0,0).length,0);
 assert.equal(particleBurst('hit',0,-1).length,0);
 assert.equal(particleBurst('hit',0,NaN).length,0);
 assert.equal(particleBurst('hit',0,200000).length,7);
});
test('particle emitter never consumes external randomness',()=>{
 const old=Math.random;Math.random=()=>{throw Error('should not be used');};
 try{assert.equal(particleBurst('trap',1729).length,24);}finally{Math.random=old;}
});
