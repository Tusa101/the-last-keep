import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Defenses} from '../src/game/defenses.ts';
import {Siege} from '../src/game/siege.ts';
function target(kind='jelly',x=-11,z=-5){return {id:1,kind,hp:55,maxHp:55,alive:true,spawnIn:0,stun:0,brain:{x,z}};}
test('defenses cost real resources and require preparation and free slots',()=>{
 const w=new World(),d=new Defenses(w);const before={...w.resources};
 assert.equal(d.install(0,'carrotTower','SIEGE'),false);
 assert.equal(d.install(0,'carrotTower','PREP'),true);
 assert.equal(w.resources.wood,before.wood-9);assert.equal(w.resources.stone,before.stone-3);
 assert.equal(d.install(0,'carrotTower','PREP'),false);
 assert.equal(d.install(3,'cheeseMortar','PREP'),false);
 assert.equal(d.install(1,'cheeseMortar','PREP'),true);
 assert.equal(d.install(2,'syrupSprayer','PREP'),true);
});
test('carrot turret shoots only during siege and respects cooldown',()=>{
 const d=new Defenses(new World());d.install(0,'carrotTower','PREP');const e=target(),events=[];
 d.step(2,'PREP',[e],events,()=>{});assert.equal(e.hp,55);
 d.step(.01,'SIEGE',[e],events,()=>{});assert.equal(e.hp,36);
 d.step(.5,'SIEGE',[e],events,()=>{});assert.equal(e.hp,36);
 d.step(.8,'SIEGE',[e],events,()=>{});assert.equal(e.hp,17);
});
test('cheese mortar deals area damage and registers kills once',()=>{
 const d=new Defenses(new World());d.install(1,'cheeseMortar','PREP');
 const a=target('jelly',-11,6),b=target('hopper',-10,6);a.hp=20;b.hp=30;let kills=0;
 d.step(.1,'SIEGE',[a,b],[],()=>kills++);
 assert.equal(a.alive,false);assert.equal(b.alive,false);assert.equal(kills,2);
 d.step(4,'SIEGE',[a,b],[],()=>kills++);assert.equal(kills,2);
});
test('syrup sprayer slows without dealing damage',()=>{
 const d=new Defenses(new World());d.install(2,'syrupSprayer','PREP');const e=target('hopper',1,-10);
 d.step(.1,'SIEGE',[e],[],()=>{});assert.equal(e.hp,55);assert.ok(e.stun>=1);
});
test('defenses serialize and reject invalid/duplicate saves without mutation',()=>{
 const d=new Defenses(new World());d.install(0,'carrotTower','PREP');const saved=d.snapshot();
 const restored=new Defenses(new World());restored.restore(saved);assert.deepEqual(restored.placed,d.placed);
 assert.throws(()=>restored.restore(JSON.stringify({version:1,placed:[{slot:0,kind:'carrotTower',cooldown:0},{slot:0,kind:'cheeseMortar',cooldown:0}]})));
 assert.deepEqual(restored.placed,d.placed);
});
