import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Siege} from '../src/game/siege.ts';
import {Defenses} from '../src/game/defenses.ts';
import {Progression,DEVELOPMENT,BRANCHES} from '../src/game/progression.ts';
import {Gathering} from '../src/game/gathering.ts';
import {Workers} from '../src/game/workers.ts';

function setup(){
 const world=new World(),siege=new Siege(world),progression=new Progression(world,siege);
 siege.research=120;
 return {world,siege,progression};
}

test('development has exactly three branches, each with two visible costs and effects',()=>{
 assert.deepEqual([...BRANCHES],['masonry','logistics','ordnance']);
 for(const b of BRANCHES){
  assert.equal(DEVELOPMENT[b].levels.length,2);
  assert.equal(DEVELOPMENT[b].costs.length,2);
  for(const cost of DEVELOPMENT[b].costs)assert.ok(cost.research>0&&cost.stone+cost.wood>0);
 }
});

test('research gates are strict: no wave zero free tech, no purchases during WARNING or SIEGE',()=>{
 const {progression}=setup();
 assert.equal(progression.buy('masonry','PREP',0).ok,false);
 assert.equal(progression.buy('masonry','WARNING',1).ok,false);
 assert.equal(progression.buy('masonry','SIEGE',1).ok,false);
 assert.equal(progression.buy('masonry','RESULT',1).ok,true);
 assert.equal(progression.buy('masonry','PREP',1).ok,false);
});

test('buying a first-tier upgrade debits research, stone and wood exactly once',()=>{
 const {world,siege,progression}=setup();
 const initial={research:siege.research,...world.resources};
 const price=DEVELOPMENT.ordnance.costs[0];
 assert.equal(progression.buy('ordnance','RESULT',1).ok,true);
 assert.equal(progression.level('ordnance'),1);
 assert.equal(siege.research,initial.research-price.research);
 assert.equal(world.resources.stone,initial.stone-price.stone);
 assert.equal(world.resources.wood,initial.wood-price.wood);
 assert.equal(progression.buy('ordnance','SIEGE',1).ok,false);
 assert.equal(siege.research,initial.research-price.research);
});

test('upgrade refuses insufficient knowledge without modifying wallet or level',()=>{
 const {world,siege,progression}=setup();siege.research=0;
 const initial={...world.resources};
 assert.equal(progression.buy('logistics','RESULT',1).ok,false);
 assert.deepEqual(world.resources,initial);
 assert.equal(progression.level('logistics'),0);
});

test('upgrade refuses insufficient resources atomically',()=>{
 const {world,siege,progression}=setup();world.resources.wood=0;
 const knowledge=siege.research,stone=world.resources.stone;
 assert.equal(progression.buy('logistics','PREP',1).ok,false);
 assert.equal(siege.research,knowledge);
 assert.equal(world.resources.stone,stone);
});

test('second level requires surviving the second wave and cannot exceed rank 2',()=>{
 const {world,siege,progression}=setup();world.resources.stone=500;world.resources.wood=500;
 assert.equal(progression.buy('ordnance','PREP',1).ok,true);
 assert.equal(progression.buy('ordnance','RESULT',1).ok,false);
 assert.equal(progression.buy('ordnance','RESULT',2).ok,true);
 assert.equal(progression.level('ordnance'),2);
 const before={research:siege.research,...world.resources};
 assert.equal(progression.buy('ordnance','PREP',3).ok,false);
 assert.deepEqual({research:siege.research,...world.resources},before);
});

test('new progression resets and loads pre-G8 as an empty tree',()=>{
 const {world,progression}=setup();
 progression.buy('masonry','RESULT',1);
 const snapshot=progression.snapshot();
 const restored=new Progression(world,{research:0});restored.restore(snapshot);
 assert.equal(restored.level('masonry'),1);
 restored.reset();assert.deepEqual(BRANCHES.map(b=>restored.level(b)),[0,0,0]);
});

test('malformed or unknown progression levels reject without partial mutation',()=>{
 const {progression}=setup();progression.buy('masonry','RESULT',1);
 const before=progression.snapshot();
 for(const levels of [{masonry:2,logistics:-1,ordnance:0},{masonry:9,logistics:0,ordnance:0},{masonry:0,logistics:0},{masonry:0,logistics:0,ordnance:0,extra:1}]){
  assert.throws(()=>progression.restore(JSON.stringify({version:1,levels})));
  assert.equal(progression.snapshot(),before);
 }
});

test('artillery upgrades increase actual defense damage and retain same physical build cost',()=>{
 const w=new World(),d=new Defenses(w),initial={...w.resources};
 assert.equal(d.install(0,'carrotTower','PREP'),true);
 assert.equal(w.resources.wood,initial.wood-9);
 const makeEnemy=()=>({id:1,kind:'jelly',hp:100,maxHp:100,alive:true,spawnIn:0,stun:0,brain:{x:-11,z:-5}});
 let enemy=makeEnemy();d.step(.05,'SIEGE',[enemy],[],()=>{});assert.equal(enemy.hp,81);
 d.ordnanceLevel=1;d.placed[0].cooldown=0;enemy=makeEnemy();d.step(.05,'SIEGE',[enemy],[],()=>{});assert.equal(enemy.hp,76);
 d.ordnanceLevel=2;d.placed[0].cooldown=0;enemy=makeEnemy();d.step(.05,'SIEGE',[enemy],[],()=>{});assert.equal(enemy.hp,71);
 assert.ok(d.placed[0].cooldown<1.25);
});

test('alchemy progression extends the syrup control window without direct damage',()=>{
 const w=new World(),d=new Defenses(w);assert.equal(d.install(0,'syrupSprayer','PREP'),true);
 d.ordnanceLevel=2;
 const enemy={id:1,kind:'hopper',hp:42,maxHp:42,alive:true,spawnIn:0,stun:0,brain:{x:-11,z:-5}};
 d.step(.01,'SIEGE',[enemy],[],()=>{});
 assert.equal(enemy.hp,42);assert.ok(enemy.stun>=1.8);
});

test('masonry buffs repair strength and reduces nexus damage from raider arrivals',()=>{
 const w=new World(),s=new Siege(w);
 assert.equal(s.repairStrength(),30);
 s.masonryLevel=1;assert.equal(s.repairStrength(),45);
 s.masonryLevel=2;assert.equal(s.repairStrength(),60);
 s.startEarly();
 // A raider arriving at the Nexus deals 15 base damage, shield level 2 absorbs 15%.
 const raider=s.raiders[0];s.raiders=[raider];raider.spawnIn=0;
 raider.brain.step=()=>{raider.brain.state='ARRIVED';};
 s.step(.1);
 assert.equal(s.nexus,87);
});

test('logistics increases actual carried goods without creating deposits',()=>{
 const w=new World(),g=new Gathering(w),workers=new Workers(w,g);
 assert.equal(workers.hire('PREP',1).ok,true);
 workers.setMode('gather');workers.logisticsLevel=2;
 const original=g.deposits.reduce((sum,d)=>sum+d.remaining,0);
 for(let i=0;i<700;i++)workers.step(.1,'PREP');
 const remaining=g.deposits.reduce((sum,d)=>sum+d.remaining,0);
 assert.ok(remaining<original,'worker has harvested finite material');
 assert.ok(workers.workers[0].amount<=12);
 assert.ok(remaining>=0);
});

test('worker save accepts upgraded 12-unit payloads and load does not regenerate material',()=>{
 const w=new World(),g=new Gathering(w),workers=new Workers(w,g);
 assert.equal(workers.hire('RESULT',1).ok,true);
 workers.workers[0].cargo='stone';workers.workers[0].amount=12;workers.workers[0].job='deliver';
 const saved=workers.snapshot(),newWorkers=new Workers(w,g);
 newWorkers.restore(saved);assert.equal(newWorkers.workers[0].amount,12);
 const before=w.resources.stone;
 newWorkers.step(.1,'PREP');
 assert.equal(w.resources.stone,before+12);
 newWorkers.step(.1,'PREP');
 assert.equal(w.resources.stone,before+12);
});
