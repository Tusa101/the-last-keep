import test from 'node:test';import assert from 'node:assert/strict';
import {blockFeedback} from '../src/game/worldFeedback.ts';
test('visual feedback distinguishes built, repaired and breached blocks',()=>{
 const a=new Map([['2,0,3',100],['4,1,7',20]]),b=new Map([['2,0,3',50],['4,1,7',40],['6,0,0',100]]);
 assert.deepEqual(blockFeedback(a,b,'damage'),[{x:2,y:.5,z:3,kind:'hit'},{x:4,y:1.5,z:7,kind:'repair'}]);
 assert.deepEqual(blockFeedback(a,b,'build'),[{x:2,y:.5,z:3,kind:'hit'},{x:4,y:1.5,z:7,kind:'repair'},{x:6,y:.5,z:0,kind:'build'}]);
 assert.deepEqual(blockFeedback(b,a,'remove'),[{x:2,y:.5,z:3,kind:'repair'},{x:4,y:1.5,z:7,kind:'hit'},{x:6,y:.5,z:0,kind:'breach'}]);
});
test('visual block feedback ignores load and caps mass collapses',()=>{
 const previous=new Map(Array.from({length:100},(_,i)=>[`${i},0,0`,50]));
 assert.equal(blockFeedback(previous,new Map(),'load').length,0);
 assert.equal(blockFeedback(previous,new Map(),'remove').length,9);
 assert.equal(blockFeedback(previous,new Map(),'remove',2).length,2);
 assert.deepEqual(blockFeedback(previous,new Map(),'remove',-1),[]);
});
