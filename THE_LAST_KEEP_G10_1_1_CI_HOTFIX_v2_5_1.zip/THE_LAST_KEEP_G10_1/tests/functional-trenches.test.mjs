import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Excavation,STRATUM_HEIGHT} from '../src/world/excavation.ts';
import {stepPlayer} from '../src/physics/player.ts';
import {Enemy} from '../src/ai/breach.ts';
import {findRoute} from '../src/ai/navigation.ts';
import {findWorkerRoute} from '../src/ai/workerNavigation.ts';
import {Gathering} from '../src/game/gathering.ts';
import {Workers} from '../src/game/workers.ts';
import {Siege} from '../src/game/siege.ts';

const tick=(w,n=1000)=>{for(let i=0;i<n;i++)w.step(.1,'PREP')};
const digTo=(e,x,z,count)=>{for(let i=0;i<count;i++)assert.equal(e.dig(x,z).ok,true)};
test('1–3 layers create actual meter-scale subsurface floor heights',()=>{
 const e=new Excavation(new World());for(let d=1;d<=3;d++){digTo(e,1,12,1);assert.ok(Math.abs(e.groundY(1,12)+d*STRATUM_HEIGHT)<.00001);}assert.equal(e.groundY(2,12),0);
});
test('player physically falls into a deep pit instead of floating on imaginary y=0 ground',()=>{
 const w=new World(),e=new Excavation(w);digTo(e,0,10,3);
 let p={x:0,y:0,z:10,vy:0,grounded:true};
 for(let i=0;i<110;i++)p=stepPlayer(w,p,{dx:0,dz:0,jump:false},1/60,e);
 assert.ok(Math.abs(p.y+1.8)<.000001,`player grounded y=${p.y}`);assert.equal(p.grounded,true);
});
test('deep trench cliff blocks horizontal exit until feet clear rim by jumping',()=>{
 const w=new World(),e=new Excavation(w);digTo(e,0,10,3);
 let p={x:0,y:-1.8,z:10,vy:0,grounded:true};
 for(let i=0;i<20;i++)p=stepPlayer(w,p,{dx:1,dz:0,jump:false},1/60,e);
 assert.ok(p.x<.5,`cannot walk horizontally out of 1.8m trench: ${p.x}`);
});
test('workers cannot traverse an unbridged two-layer pit',()=>{
 const w=new World(),e=new Excavation(w);digTo(e,0,10,2);
 const route=findWorkerRoute(w,{x:-1,z:10},{x:1,z:10},.1,e);
 assert.ok(route);assert.ok(route.every(c=>!(c.x===0&&c.z===10)));
});
test('enemy A* actively incorporates trench costs and reroutes around the cut',()=>{
 const w=new World(),e=new Excavation(w);digTo(e,0,10,2);
 const base=findRoute(w,{x:-2,z:10},{x:2,z:10});
 const avoid=findRoute(w,{x:-2,z:10},{x:2,z:10},e);
 assert.ok(base?.cells.some(p=>p.x===0&&p.z===10));
 assert.ok(avoid);assert.ok(!avoid.cells.some(p=>p.x===0&&p.z===10));
});
test('enemy brain uses earthworks and updates route after excavation revision',()=>{
 const w=new World(),e=new Excavation(w),enemy=new Enemy(w,e);
 enemy.x=-2;enemy.z=10;enemy.step(.05);
 digTo(e,0,10,3);
 for(let i=0;i<50;i++)enemy.step(.05);
 assert.notEqual(enemy.state,'REPATHING');
});
test('worker excavation queues a real task and stone is delivered, not minted instantly',()=>{
 const w=new World(),e=new Excavation(w),g=new Gathering(w),workers=new Workers(w,g,e);
 workers.hire('PREP',1);workers.setMode('build');
 const before=w.resources.stone;
 assert.equal(workers.queueDig([{x:5,z:10}]).ok,true);assert.equal(w.resources.stone,before);
 let dug=false;for(let i=0;i<700;i++){workers.step(.1,'PREP');if(e.depth(5,10)>0){dug=true;assert.equal(w.resources.stone,before);assert.equal(workers.workers[0].cargo,'stone');break;}}
 assert.ok(dug,'worker finishes digging');
 for(let i=0;i<700&&workers.workers[0].cargo;i++)workers.step(.1,'PREP');
 assert.equal(workers.workers[0].cargo,null);assert.equal(w.resources.stone,before+1);
});
test('workers stop digging during sieges, resume preparation',()=>{
 const w=new World(),e=new Excavation(w),g=new Gathering(w),workers=new Workers(w,g,e);
 workers.hire('PREP',1);workers.setMode('build');workers.queueDig([{x:5,z:10}]);
 for(let i=0;i<300;i++)workers.step(.1,'SIEGE');
 assert.equal(e.depth(5,10),0);tick(workers,700);assert.equal(e.depth(5,10),1);
});
test('excavation tasks survive save/restore and are not duplicated',()=>{
 const w=new World(),e=new Excavation(w),g=new Gathering(w),workers=new Workers(w,g,e);
 workers.hire('PREP',1);workers.queueDig([{x:5,z:10}]);const save=workers.snapshot();
 const copy=new Workers(w,g,e);copy.restore(save);assert.equal(copy.digOrders.length,1);
 copy.setMode('build');tick(copy,700);assert.equal(e.depth(5,10),1);assert.equal(copy.digOrders.length,0);
});
test('old v1 worker saves can be loaded with empty dig queue',()=>{
 const w=new World(),g=new Gathering(w),e=new Excavation(w),workers=new Workers(w,g,e);
 workers.hire('PREP',1);const legacy=JSON.parse(workers.snapshot());legacy.version=1;delete legacy.digOrders;
 const receiver=new Workers(w,g,e);receiver.restore(JSON.stringify(legacy));assert.equal(receiver.digOrders.length,0);
});
test('invalid excavation task restore is atomic and does not corrupt active workers',()=>{
 const w=new World(),g=new Gathering(w),e=new Excavation(w),workers=new Workers(w,g,e);
 workers.hire('PREP',1);workers.queueDig([{x:5,z:10}]);const before=workers.snapshot(),invalid=JSON.parse(before);
 invalid.digOrders.push({...invalid.digOrders[0]});assert.throws(()=>workers.restore(JSON.stringify(invalid)));
 assert.equal(workers.snapshot(),before);
});
test('excavation prevents digging below warehouse floor and foundation',()=>{
 const e=new Excavation(new World());assert.equal(e.canDig(4,3).ok,false);assert.equal(e.canDig(9,0).ok,false);
});
test('siege uses excavation-aware enemy brains including restored raiders',()=>{
 const w=new World(),e=new Excavation(w),siege=new Siege(w,e);siege.startEarly();
 assert.ok(siege.raiders.every(r=>r.brain.terrain===e));
 const copy=new Siege(w,e);copy.restore(siege.snapshot());assert.ok(copy.raiders.every(r=>r.brain.terrain===e));
});
