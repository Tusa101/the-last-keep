import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Excavation} from '../src/world/excavation.ts';
import {Enemy} from '../src/ai/breach.ts';
import {findRoute} from '../src/ai/navigation.ts';
import {waveIntel,raiderSpawn} from '../src/game/encounters.ts';
import {bombardmentTarget} from '../src/game/siegeTactics.ts';
import {Siege} from '../src/game/siege.ts';

function wave3(world=new World(),terrain){
 const siege=new Siege(world,terrain);
 for(let wave=1;wave<3;wave++){
  assert.equal(siege.startEarly(),true);
  siege.raiders.forEach(r=>r.alive=false);siege.step(.01);siege.next();
 }
 siege.startEarly();return siege;
}

test('wave briefings are authoritative for four troop classes, and preserve three-wave victory',()=>{
 const expected=[[4,0,0,0],[3,1,3,0],[4,1,3,2]];
 for(let wave=1;wave<=3;wave++){
  const intel=waveIntel(wave);
  assert.deepEqual([intel.jellies,intel.brutes,intel.hoppers,intel.bombardiers],expected[wave-1]);
  assert.equal(intel.jellies+intel.brutes+intel.hoppers+intel.bombardiers,expected[wave-1].reduce((a,b)=>a+b,0));
  const count=expected[wave-1].reduce((a,b)=>a+b,0);
  for(let i=0;i<count;i++){
   const start=raiderSpawn(wave,i,count);
   assert.ok(Math.abs(start.x)<=22&&Math.abs(start.z)<=22);
   assert.ok(start.front==='west'||start.front==='north');
  }
 }
 const s=wave3();
 assert.equal(s.raiders.filter(r=>r.kind==='hopper').length,3);
 assert.equal(s.raiders.filter(r=>r.kind==='bombardier').length,2);
 assert.ok(s.raiders.some(r=>r.brain.z<=-17));
 s.raiders.forEach(r=>r.alive=false);s.step(.02);assert.equal(s.phase,'VICTORY');
});

test('hopper vault navigation ignores depth penalty but ordinary infantry avoids costly trench',()=>{
 const world=new World(),earth=new Excavation(world);
 for(let z=-8;z<=8;z++){
  for(let depth=0;depth<3;depth++)earth.dig(0,z,false);
 }
 const normal=findRoute(world,{x:-3,z:0},{x:3,z:0},earth);
 const vault=findRoute(world,{x:-3,z:0},{x:3,z:0});
 assert.ok(normal&&vault);
 assert.ok(normal.cost>vault.cost);
 assert.ok(normal.cells.length>vault.cells.length);
 const inf=new Enemy(world,earth),hopper=new Enemy(world,earth);
 inf.x=-3;hopper.x=-3;inf.z=hopper.z=0;inf.speed=hopper.speed=1.5;hopper.vaultTrenches=true;
 // The hopper chooses the direct approach; a normal unit detours around the trench.
 inf.step(.20);hopper.step(.20);
 assert.ok(hopper.target?.z===0);
 assert.ok(normal.cells.some(p=>Math.abs(p.z)>8));
 assert.ok(vault.cells.every(p=>p.z===0));
});

test('hopper movement on a deep trench does not incur soil penalty',()=>{
 const world=new World(),earth=new Excavation(world);
 for(let d=0;d<3;d++)earth.dig(0,0,false);
 const normal=new Enemy(world,earth),hopper=new Enemy(world,earth);
 normal.x=hopper.x=0;normal.z=hopper.z=0;
 normal.speed=hopper.speed=2;hopper.vaultTrenches=true;
 normal.step(.2);hopper.step(.2);
 assert.ok(hopper.x>normal.x+.15);
});

test('bombardment chooses closest first visible wall and never targets empty terrain',()=>{
 const world=new World();
 assert.equal(bombardmentTarget(world,0,0),null);
 world.seed({x:3,y:0,z:0});world.seed({x:5,y:0,z:0});
 assert.deepEqual(bombardmentTarget(world,0,0),{x:3,y:0,z:0});
 assert.equal(bombardmentTarget(world,-8,0),null);
});

test('bombardier damages castle masonry from distance, not the Nexus directly',()=>{
 const world=new World();world.seed({x:3,y:0,z:0});
 const s=wave3(world),b=s.raiders.find(r=>r.kind==='bombardier');
 assert.ok(b);s.raiders.filter(r=>r!==b).forEach(r=>r.alive=false);
 b.spawnIn=0;b.brain.x=0;b.brain.z=0;
 const hp=world.get(3,0,0).hp,nexus=s.nexus;
 s.step(1.4);assert.equal(world.get(3,0,0).hp,hp);
 s.step(1.4);assert.equal(world.get(3,0,0).hp,hp-22);
 assert.equal(b.brain.state,'BOMBARDING');assert.equal(s.nexus,nexus);
 assert.ok(s.events.some(e=>e.kind==='pudding'));
});

test('bombardier artillery has a cooldown and cannot attack through range limit',()=>{
 const world=new World();world.seed({x:3,y:0,z:0});
 const s=wave3(world),b=s.raiders.find(r=>r.kind==='bombardier');
 s.raiders.filter(r=>r!==b).forEach(r=>r.alive=false);
 b.spawnIn=0;b.brain.x=0;b.brain.z=0;
 s.step(2.8);const hp=world.get(3,0,0).hp;
 s.step(.2);assert.equal(world.get(3,0,0).hp,hp);
 // Removing target ends bombardment and resets charge.
 b.brain.x=-9;b.brain.z=0;s.step(.2);assert.equal(b.specialClock,0);
});

test('artillery can be shot before firing; dead raiders never fire',()=>{
 const world=new World();world.seed({x:3,y:0,z:0});
 const s=wave3(world),b=s.raiders.find(r=>r.kind==='bombardier');
 s.raiders.filter(r=>r!==b).forEach(r=>r.alive=false);
 b.spawnIn=0;b.brain.x=0;b.brain.z=0;
 // Use direct shot near artillery with no wall between shooter and target.
 for(let i=0;i<3;i++)s.shoot({x:-2,y:.9,z:0},{x:1,y:0,z:0});
 assert.equal(b.alive,false);const hp=world.get(3,0,0).hp;
 s.step(3);assert.equal(world.get(3,0,0).hp,hp);
});

test('G7 save preserves artillery cooldown and vault property',()=>{
 const world=new World();world.seed({x:3,y:0,z:0});
 const s=wave3(world),b=s.raiders.find(r=>r.kind==='bombardier');
 b.spawnIn=0;b.brain.x=0;b.brain.z=0;
 s.step(1.1);assert.ok(b.specialClock>1);
 const clone=new Siege(world);clone.restore(s.snapshot());
 assert.equal(clone.raiders.find(r=>r.kind==='bombardier').specialClock,b.specialClock);
 assert.ok(clone.raiders.filter(r=>r.kind==='hopper').every(r=>r.brain.vaultTrenches));
 assert.equal(clone.raiders.length,s.raiders.length);
});

test('legacy siege v2 save lacking specialClock remains loadable',()=>{
 const s=new Siege(new World());s.startEarly();const state=JSON.parse(s.snapshot());
 for(const r of state.raiders)delete r.specialClock;
 const old=new Siege(new World());old.restore(JSON.stringify(state));
 assert.ok(old.raiders.every(r=>r.specialClock===0));
});

test('tampered artillery charge is rejected without partial state changes',()=>{
 const s=wave3();const before=s.snapshot();const state=JSON.parse(before);
 state.raiders.at(-1).specialClock=999;
 assert.throws(()=>s.restore(JSON.stringify(state)),/Invalid raider/);
 assert.equal(s.snapshot(),before);
});
