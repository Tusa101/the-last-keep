# G8 validation record — v1.9

Automated tests run via Node.js 22 (`node --experimental-strip-types --test tests/*.test.mjs`). The new `tests/progression.test.mjs` covers economics, affordability gates, double spending prevention, wave locks, save migration/atomic validation, actual weapon bonus damage/stuns, worker carrying and masonry protection.

Commands to repeat:

```bash
npm test
npm run typecheck:core
npm run typecheck
npm run build
```

`npm run typecheck` and `npm run build` require installed `three` typings and Vite, which **cannot be installed in this isolated runtime** because npm registry lookup fails with `EAI_AGAIN`. Those steps must run in GitHub Actions or on a local machine with dependencies available.

For browser checks, run `npm run dev` and `npm run smoke` (with Playwright Chromium installed). The smoke script checks desktop WebGL boot, upgrade panel with three disabled branches before wave 1, mobile coarse-pointer controls, absence of overlaps among main touch buttons, and ability to open the upgrade panel from mobile menu. Screenshots are written to `smoke-*.png`.

Physical Android/iPhone playtest is still required, including fullscreen support and orientation transitions. No fabricated FPS measurements or browser QA results are included.
