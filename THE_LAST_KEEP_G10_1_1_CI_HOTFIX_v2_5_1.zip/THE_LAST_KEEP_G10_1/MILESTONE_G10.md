# THE LAST KEEP — G10 / v2.4: Vertical Slice Integration

## Goal and delivered scope

Package a coherent **three-assault single-run vertical slice** on the existing Three.js castle builder/siege prototype. This is a functional engineering milestone, **not** a certification that the game is release-ready. The only authored waves are those defined in `src/game/encounters.ts`.

### Player experience

1. **Preparation:** the existing tutorials, quarry/woodcutting, build/repair, workers, castle architect and War Room remain available. A 90-second preparation phase and a 15-second warning precede each assault; `G` or mobile **⚑ Волна** starts early.
2. **Assault 1:** four jelly troops, from the west. The player learns to hold the gates, fire the crossbow, and buy emplacement(s).
3. **Assault 2:** jelly soldiers, a battering ram and trench-vaulting hoppers. Players are encouraged to combine masonry and ranged defenses, not rely solely on ditches.
4. **Assault 3:** two-front attack with bombardiers, their pudding wall damage, and all previous raider types. This is the run climax.
5. **Debrief:** after **each** assault a scorecard shows cumulative per-wave scores, casualties, remaining Nexus HP and the final title. Use the **Next preparation** or **New run** button (including touch) to continue.

### New code

- `src/game/campaign.ts`: immutable *per-wave* report entries, deterministic 0–100 score, aggregate rank, strict save validation, idempotent recording. Score = **40** for surviving the wave + up to **40** for Nexus remaining HP + up to **20** for proportion of enemies eliminated. Defeat gets 0. Three completed waves and ≥90 mean give **Legend**, ≥75 mean **Veteran**, else **Defender**. Scoring does **not** award resources or affect enemy AI.
- `src/main.ts`: wire the campaign to phase transitions, show full results, freeze simulated player movement during debrief, preserve old saves v2/v3/v4, and write a v5 envelope with `campaign`. Reset clears all run reports. The battle itself retains the 3-wave win condition.
- `src/game/siege.ts`: when the Nexus falls, update `lastReport` for the **current wave** before reporting defeat, rather than mistakenly reusing last wave's statistics. Defeats earn no knowledge.
- `src/ui/style.css`: compact scorecard on mobile. A special `body.game-result` stacking context places the result panel **above** the touch controls, hides the controls during debrief, and allows vertical scrolling on low-height landscape screens.
- `scripts/balance.mjs`: deterministic full three-wave simulation for different equipment combinations, testing the actual world, enemies, siege engine, defenses, Nexus HP and victory/defeat conditions.
- `scripts/vertical-slice-smoke.mjs`: Playwright E2E **after a production build**. Produces a valid serialized victory save from core classes, loads it through the actual desktop and mobile UI, checks all three report rows and the final title, then taps the **New run** action.
- `.github/workflows/deploy.yml`: CI now executes the deterministic balance test; the browser smoke tests the **Vite production preview under the GitHub Pages project subpath**, not the Vite development server.

## Verified offline behavior

- `npm test`: **152/152** Node integration/unit tests.
- `npm run typecheck:core`: **pass**.
- `npm run check:balance`: **pass**; see `VALIDATION_G10.md` for actual results. Without defense the castle fails in wave 2; a single carrot turret fails in wave 3; carrot turret + cheese mortar (and all-three setup) pass in the current deterministic simulation.
- Chromium CSS-only mobile **end-of-run screen**: viewport sizes 280×653, 320×568, 390×844, 568×320, 667×375, 844×390, 1024×600; report CTA can be reached, panel scrolls where needed and controls do not cover it. This is NOT a full WebGL test.

## Pending integration — blocking demo release

**The full Vite production build, WebGL runtime, mobile touch interactions in the actual game, production E2E run and physical-device FPS remain unverified** here. The current environment cannot reach npm registry (`EAI_AGAIN`), and Three.js/Vite/Playwright are not installed inside the project. GitHub Actions is configured to perform those checks when online, but CI results have not yet been supplied. Never treat a passing Node unit test as proof that the browser app runs correctly.

## Release gate for G10.1

1. GitHub Actions `npm install`, `npm test`, `npm run check:balance`, `npm run build` and all Playwright tests complete successfully on production preview and correct Pages base path.
2. Open deployed URL on mobile Chrome and Safari where possible. Confirm fullscreen behavior, touch controls, 3D animation, no UI overlap, correct scene/performance during 10-unit wave 3 and result-screen actions.
3. Complete a real three-wave playthrough with different strategies and record qualitative balance/UX feedback. Fix regressions before labeling this a demo release.

## GitHub Pages update

With the Starter workflow+selector already in the repository, commit **`THE_LAST_KEEP_G10_VERTICAL_SLICE_v2_4.zip`** into the root. It sorts as newer than v2_3, extracts and builds. If you are starting a new repo, first extract `.github/workflows/deploy.yml` and `scripts/select_latest.py` from the archive into the corresponding real repository paths. A workflow packed **inside** a ZIP is not executed by GitHub itself.

### Additional mobile tap reliability fix

The result card is no longer regenerated 5–10 times a second when gameplay is frozen. Previously the HUD replaced its DOM children every 100–180 ms, which could swallow a long touch between pointerdown and pointerup. The production E2E test now checks that the result CTA remains attached for at least 400 ms before tapping it.
