import test from 'node:test';import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';import {seedCastle} from '../src/world/preset.ts';
import {Defenses,DEFENSE_SLOTS} from '../src/game/defenses.ts';
import {Siege} from '../src/game/siege.ts';
import {CampaignJournal} from '../src/game/campaign.ts';
import {TOTAL_WAVES,waveIntel,raiderSpawn} from '../src/game/encounters.ts';

test('all five turret pads are physically free in the ACTUAL seeded castle, and can be built',()=>{
 const world=new World();seedCastle(world);const turrets=new Defenses(world);
 assert.equal(DEFENSE_SLOTS.length,5);
 for(const [slot,p] of DEFENSE_SLOTS.entries()){
  assert.deepEqual(world.groundObstructions(p.x,p.z),[],`Pad ${slot+1} must be reachable and empty`);
  assert.equal(turrets.checkInstall(slot,'carrotTower','PREP').ok,true);
 }
 assert.equal(turrets.installDetailed(0,'carrotTower','PREP').ok,true);
 assert.equal(turrets.placed[0].slot,0);
 assert.equal(turrets.placed[0].kind,'carrotTower');
 assert.equal(turrets.checkInstall(0,'cheeseMortar','PREP').ok,false);
});
test('turret installation failure has a precise reason and cannot charge resources',()=>{
 const world=new World();seedCastle(world);const turrets=new Defenses(world);
 const before={...world.resources};
 assert.match(turrets.installDetailed(0,'cheeseMortar','SIEGE').reason,/подготовки/);
 assert.deepEqual(world.resources,before);
 const pad=DEFENSE_SLOTS[0];world.seed({x:pad.x,y:0,z:pad.z});
 assert.match(turrets.installDetailed(0,'cheeseMortar','PREP').reason,/перекрыта кладкой/);
 assert.deepEqual(world.resources,before);
 world.blocks.delete(`${pad.x},0,${pad.z}`);
 world.resources.wood=0;
 assert.match(turrets.installDetailed(0,'cheeseMortar','PREP').reason,/Не хватает ресурсов/);
 assert.equal(turrets.placed.length,0);
});
test('all six attack recipes are bounded, non-identical, and their spawns fit the map',()=>{
 assert.equal(TOTAL_WAVES,6);
 const sizes=[];
 for(let wave=1;wave<=TOTAL_WAVES;wave++){
  const intel=waveIntel(wave),count=intel.jellies+intel.brutes+intel.hoppers+intel.bombardiers;
  sizes.push(count);for(let i=0;i<count;i++){const p=raiderSpawn(wave,i,count);
   assert.ok(Math.abs(p.x)<=22&&Math.abs(p.z)<=22,`wave ${wave} spawn ${i} out of bounds`);
  }
 }
 assert.deepEqual(sizes,[4,7,10,13,15,19]);
});
test('six-wave victory only after finale; legacy wave-3 VICTORY save becomes RESULT',()=>{
 const world=new World(),s=new Siege(world),d=new Defenses(world),journal=new CampaignJournal();
 for(let wave=1;wave<=6;wave++){
  assert.equal(s.startEarly(),true);
  s.raiders.forEach(e=>e.alive=false);s.kills=s.raiders.length;s.step(.016);
  assert.equal(s.phase,wave===6?'VICTORY':'RESULT');
  assert.equal(journal.record(s,world,d),true);
  if(wave<6)s.next();
 }
 assert.equal(journal.records.length,6);assert.equal(journal.rating(),'legend');
 const old=new Siege(world),snapshot=JSON.parse(s.snapshot());snapshot.phase='VICTORY';snapshot.wave=3;
 old.restore(JSON.stringify(snapshot));assert.equal(old.phase,'RESULT');assert.equal(old.wave,3);assert.equal(old.next(),true);
});
test('nexus repair requires actual resources, respects cap and combat phases',()=>{
 const world=new World(),s=new Siege(world);s.nexus=45;const before={...world.resources};
 assert.equal(s.repairNexus().ok,true);assert.equal(s.nexus,70);
 assert.equal(world.resources.stone,before.stone-8);assert.equal(world.resources.wood,before.wood-4);
 s.phase='SIEGE';assert.equal(s.repairNexus().ok,false);
 s.phase='PREP';s.nexus=94;assert.equal(s.repairNexus().ok,true);assert.equal(s.nexus,100);
 assert.equal(s.repairNexus().ok,false);
});

test('minimap renders all numbered placement pads and installed defenses',async()=>{
 const {drawMinimap}=await import('../src/ui/minimap.ts');
 const world=new World();seedCastle(world);const defs=new Defenses(world);defs.install(0,'carrotTower','PREP');
 const texts=[];
 const ctx=new Proxy({fillText:(text)=>texts.push(String(text))},{get(obj,key){if(key in obj)return obj[key];return ()=>{};},set(obj,key,value){obj[key]=value;return true;}});
 const canvas={width:480,height:480,getContext:()=>ctx};
 drawMinimap(canvas,world,{x:0,z:0},0,[],null,false,[],undefined,defs.placed);
 assert.deepEqual(texts.slice(0,5),['1','2','3','4','5']);
});
