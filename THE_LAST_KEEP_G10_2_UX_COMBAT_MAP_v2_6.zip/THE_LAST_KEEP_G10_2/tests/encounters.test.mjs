import test from 'node:test';import assert from 'node:assert/strict';
import {waveIntel,nextIntel,raiderSpawn,TOTAL_WAVES,clockLabel,phaseLabel} from '../src/game/encounters.ts';
import {World} from '../src/world/model.ts';import {Siege} from '../src/game/siege.ts';
test('waves disclose matching, actionable fronts before an assault',()=>{
 assert.deepEqual(waveIntel(1).fronts,['west']);assert.deepEqual(nextIntel(2).fronts,['west','north']);
 assert.equal(nextIntel(TOTAL_WAVES),null);assert.equal(phaseLabel('WARNING'),'АРМИЯ БЛИЗКО');assert.equal(clockLabel(75.1),'1:16');
});
test('third siege enters from BOTH west and north, previous from west',()=>{
 for(let wave=1;wave<=TOTAL_WAVES;wave++){
  const intel=waveIntel(wave),count=intel.jellies+intel.brutes;
  const starts=Array.from({length:count},(_,i)=>raiderSpawn(wave,i,count));
  assert.ok(starts.some(s=>s.front==='west'));
  if(wave>=3)assert.ok(starts.some(s=>s.front==='north'&&s.z<=-17));
  else assert.ok(starts.every(s=>s.front==='west'));
 }
});
test('Siege spawns match preannounced number and fronts',()=>{
 const s=new Siege(new World());
 for(let wave=1;wave<=TOTAL_WAVES;wave++){
  const intel=waveIntel(wave);s.startEarly();
  assert.equal(s.raiders.filter(r=>r.kind==='jelly').length,intel.jellies);
  assert.equal(s.raiders.filter(r=>r.kind==='brute').length,intel.brutes);
  if(wave>=3)assert.ok(s.raiders.some(r=>r.brain.z<=-17));
  s.raiders.forEach(r=>r.alive=false);s.step(.016);if(wave<TOTAL_WAVES)s.next();
 }
});
test('reserve raiders cannot be shot until they march into the map',()=>{
 const s=new Siege(new World());s.startEarly();
 const reserve=s.raiders[1];reserve.brain.x=3;reserve.brain.z=0;
 const blocked=s.shoot({x:0,y:.72,z:0},{x:1,y:0,z:0});assert.notEqual(blocked.targetId,reserve.id);
 s.step(3.0);assert.equal(reserve.spawnIn,0);
 const allowed=s.shoot({x:0,y:.72,z:0},{x:1,y:0,z:0});assert.equal(allowed.kind,'enemy');
});
