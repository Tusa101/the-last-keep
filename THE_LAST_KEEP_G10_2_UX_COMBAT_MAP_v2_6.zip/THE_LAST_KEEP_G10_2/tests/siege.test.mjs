import test from 'node:test';import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Siege} from '../src/game/siege.ts';
const fire=(s,weapon='bolt',origin={x:0,y:.72,z:0},direction={x:1,y:0,z:0})=>s.shoot(origin,direction,weapon);
test('preparation warning and early start',()=>{const s=new Siege(new World());s.step(90);assert.equal(s.phase,'WARNING');assert.equal(s.startEarly(),true);assert.equal(s.wave,1);assert.equal(s.raiders.length,4);});
test('six waves and knowledge do not materialize wall materials',()=>{const w=new World(),s=new Siege(w);const stone=w.resources.stone;for(let i=0;i<6;i++){s.startEarly();for(const e of s.raiders)e.alive=false;s.step(.02);assert.equal(s.phase,i===5?'VICTORY':'RESULT');if(i<5)s.next();}assert.equal(w.resources.stone,stone);assert.equal(s.research,120);});
test('3D shots damage and eliminate an unoccluded raider',()=>{const s=new Siege(new World());s.startEarly();const e=s.raiders[0];e.brain.x=2;e.brain.z=0;assert.equal(fire(s).kind,'enemy');assert.equal(e.hp,20);assert.equal(fire(s).kind,'enemy');assert.equal(e.alive,false);});
test('nexus loss ends run',()=>{const s=new Siege(new World());s.startEarly();s.nexus=10;for(const e of s.raiders){e.brain.state='ARRIVED';}s.step(.1);assert.equal(s.phase,'DEFEAT');});
test('research unlocks have real effects, unique purchases, and never grant blocks',()=>{
 const w=new World(),s=new Siege(w);const stone=w.resources.stone;s.research=100;
 assert.equal(s.unlock('carrot'),true);assert.equal(s.unlock('carrot'),false);assert.equal(s.research,80);
 assert.equal(s.unlock('trap'),true);assert.equal(s.unlock('repair'),true);assert.equal(s.repairStrength(),55);
 assert.equal(w.resources.stone,stone);s.startEarly();assert.equal(s.trapCharges,5);
 assert.equal(s.unlock('repair'),false);
});
test('carrot stuns and pushes a jelly further than a brute',()=>{
 const s=new Siege(new World());s.research=20;s.unlock('carrot');s.startEarly();
 const j=s.raiders[0];j.brain.x=2;j.brain.z=0;
 const hit=fire(s,'carrot');assert.equal(hit.kind,'enemy');assert.ok(hit.knockback>1.5);assert.ok(j.stun>.5);
 const b=s.raiders[1];b.brain.x=3;b.brain.z=4;b.kind='brute';b.maxHp=130;b.hp=130;b.spawnIn=0;
 const heavy=fire(s,'carrot',{x:0,y:.97,z:4});assert.equal(heavy.kind,'enemy');assert.ok(heavy.knockback<1);assert.ok(b.stun<.3);
});
test('carrot cannot knock enemies through new masonry',()=>{
 const w=new World(),s=new Siege(w);s.research=20;s.unlock('carrot');s.startEarly();
 const j=s.raiders[0];j.brain.x=0;j.brain.z=0;w.seed({x:2,y:0,z:0});
 const result=fire(s,'carrot',{x:-2,y:.72,z:0});assert.equal(result.kind,'enemy');assert.ok(j.brain.x<1.5);
});
test('saving and restoring in-progress raid retains waves, research, enemies, time and options',()=>{
 const w=new World(),s=new Siege(w);s.research=20;s.unlock('carrot');s.startEarly();
 s.step(1.2);s.raiders[0].hp=14;s.raiders[0].brain.x=-3;s.raiders[0].stun=.4;
 const save=s.snapshot(),restored=new Siege(w);restored.restore(save);
 assert.equal(restored.phase,'SIEGE');assert.equal(restored.wave,1);assert.equal(restored.raiders[0].hp,14);
 assert.equal(restored.raiders[0].brain.x,-3);assert.equal(restored.raiders[0].stun,.4);
 assert.equal(restored.unlocked.has('carrot'),true);assert.equal(restored.time,s.time);
 for(const r of restored.raiders)r.alive=false;restored.step(.1);assert.equal(restored.phase,'RESULT');
 const reward=restored.research;restored.step(5);assert.equal(restored.research,reward);
});
test('invalid siege save is rejected without mutation',()=>{
 const s=new Siege(new World());s.startEarly();const before=s.snapshot();
 const corrupt=JSON.parse(before);corrupt.raiders[0].x=Number.POSITIVE_INFINITY;
 assert.throws(()=>s.restore(JSON.stringify(corrupt)),/Invalid raider/);assert.equal(s.snapshot(),before);
});
test('jelly and brute attack rates, speeds and damage are genuinely different',()=>{
 const s=new Siege(new World());s.startEarly();s.raiders[0].brain.x=0;
 // Spawn wave two for brute.
 s.raiders.forEach(r=>r.alive=false);s.step(.01);s.next();s.startEarly();
 const j=s.raiders[0],b=s.raiders.at(-1);
 assert.ok(j.brain.speed>b.brain.speed);assert.ok(b.brain.attackDamage>j.brain.attackDamage);
 assert.ok(b.brain.attackInterval<j.brain.attackInterval);
});
