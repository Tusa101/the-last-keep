import test from 'node:test';
import assert from 'node:assert/strict';
import {CampaignJournal,waveScore} from '../src/game/campaign.ts';
import {World} from '../src/world/model.ts';
import {Siege} from '../src/game/siege.ts';
import {Defenses} from '../src/game/defenses.ts';

test('journal rejects recording during preparation and repeated results',()=>{
 const w=new World(),s=new Siege(w),d=new Defenses(w),j=new CampaignJournal();
 assert.equal(j.record(s,w,d),false);s.startEarly();s.raiders.forEach(e=>e.alive=false);s.kills=s.raiders.length;s.step(.1);
 assert.equal(j.record(s,w,d),true);assert.equal(j.record(s,w,d),false);
 assert.equal(j.records.length,1);assert.equal(j.records[0].wave,1);
 assert.equal(j.records[0].score,100);
});
test('journal produces meaningful six-wave scorecard and can be saved',()=>{
 const w=new World(),s=new Siege(w),d=new Defenses(w),j=new CampaignJournal();
 for(let i=1;i<=6;i++){
  s.startEarly();s.raiders.forEach(r=>r.alive=false);s.kills=s.raiders.length;s.step(.1);
  assert.equal(j.record(s,w,d),true);if(i<6)assert.equal(s.next(),true);
 }
 assert.equal(j.rating(),'legend');assert.equal(j.totalScore(),600);
 const loaded=new CampaignJournal();loaded.restore(j.snapshot());assert.deepEqual(loaded.records,j.records);
 assert.equal(loaded.record(s,w,d),false);
});
test('defeat records ACTUAL wave statistics rather than stale previous report',()=>{
 const w=new World(),s=new Siege(w),d=new Defenses(w),j=new CampaignJournal();
 s.startEarly();s.raiders.forEach(r=>r.alive=false);s.step(.02);j.record(s,w,d);s.next();
 s.startEarly();s.nexus=10;s.kills=2;s.raiders.forEach(e=>{e.brain.state='ARRIVED';e.spawnIn=0;});
 s.step(.1);assert.equal(s.phase,'DEFEAT');assert.equal(s.lastReport.kills,2);
 assert.equal(s.lastReport.researchEarned,0);assert.equal(s.lastReport.nexusLost,100);
 assert.equal(j.record(s,w,d),true);assert.equal(j.records[1].outcome,'fallen');
 assert.equal(j.records[1].kills,2);assert.equal(j.rating(),'fallen');
});
test('journal rejects tampering and preserves current records',()=>{
 const w=new World(),s=new Siege(w),d=new Defenses(w),j=new CampaignJournal();
 s.startEarly();s.raiders.forEach(r=>r.alive=false);s.kills=s.raiders.length;s.step(.1);j.record(s,w,d);
 const saved=j.snapshot(),altered=JSON.parse(saved);altered.records[0].score=99;
 assert.throws(()=>j.restore(JSON.stringify(altered)),/Invalid campaign/);
 assert.equal(j.snapshot(),saved);
 altered.records[0].score=100;altered.records[0].nexus=0;
 assert.throws(()=>j.restore(JSON.stringify(altered)),/Invalid campaign/);
});
test('ratings reward remaining nexus and clear enemies',()=>{
 assert.equal(waveScore('held',100,4,4),100);
 assert.equal(waveScore('held',20,1,4),53);
 assert.equal(waveScore('fallen',100,4,4),0);
});
