import test from 'node:test';
import assert from 'node:assert/strict';
import {World} from '../src/world/model.ts';
import {Siege} from '../src/game/siege.ts';
import {Defenses} from '../src/game/defenses.ts';
import {Gathering} from '../src/game/gathering.ts';
import {Workers} from '../src/game/workers.ts';
import {warBriefing,canAffordDefense} from '../src/game/readiness.ts';

function setup(){
 const world=new World(),siege=new Siege(world),defenses=new Defenses(world),gathering=new Gathering(world),workers=new Workers(world,gathering);
 return {world,siege,defenses,gathering,workers,brief:()=>warBriefing(world,siege,defenses,gathering,workers)};
}

test('first briefing names authored first wave and does not require locked workers',()=>{
 const s=setup(),brief=s.brief();
 assert.equal(brief.intel.wave,1);assert.equal(brief.intel.jellies,4);
 assert.equal(brief.checks.find(c=>c.id==='defenses').severity,'ready');
 assert.equal(brief.checks.some(c=>c.id==='labor'),false);
});
test('second briefing correctly warns about no automatic defenses and no hired workers',()=>{
 const s=setup();s.siege.startEarly();s.siege.phase='RESULT';
 const brief=s.brief();assert.equal(brief.intel.wave,2);
 assert.equal(brief.checks.find(c=>c.id==='defenses').severity,'caution');
 assert.equal(brief.checks.find(c=>c.id==='labor').severity,'caution');
 assert.equal(brief.risk,'caution');
});
test('successful emplacement appears in its actual slot with exact label',()=>{
 const s=setup();
 assert.equal(s.defenses.install(2,'cheeseMortar','PREP'),true);
 const brief=s.brief();assert.equal(brief.emplacements[0].occupied,false);
 assert.equal(brief.emplacements[2].kind,'cheeseMortar');
 assert.match(brief.emplacements[2].label,/Сырная/);
});
test('briefing immediately reflects wall damage and warns about critical blocks',()=>{
 const s=setup();s.world.seed({x:0,y:0,z:0});
 assert.equal(s.brief().damagedBlocks,0);
 s.world.damage({x:0,y:0,z:0},61);
 const b=s.brief();assert.equal(b.damagedBlocks,1);assert.equal(b.criticalBlocks,1);
 assert.equal(b.checks.find(c=>c.id==='walls').severity,'danger');
});
test('moderately damaged wall yields caution, not critical risk',()=>{
 const s=setup();s.world.seed({x:0,y:0,z:0});s.world.damage({x:0,y:0,z:0},12);
 const b=s.brief();assert.equal(b.criticalBlocks,0);
 assert.equal(b.checks.find(c=>c.id==='walls').severity,'caution');
});
test('nexus risk thresholds track actual remaining HP',()=>{
 const s=setup();s.siege.nexus=65;
 assert.equal(s.brief().checks.find(c=>c.id==='nexus').severity,'caution');
 s.siege.nexus=35;
 assert.equal(s.brief().risk,'danger');
});
test('quotes use exact affordability at zero surplus, never a free turret',()=>{
 const s=setup();s.world.resources.wood=9;s.world.resources.stone=3;
 assert.equal(canAffordDefense(s.world,'carrotTower'),true);
 s.world.resources.stone=2.99;
 assert.equal(canAffordDefense(s.world,'carrotTower'),false);
 assert.equal(canAffordDefense(s.world,'cheeseMortar'),false);
});
test('finite deposits are reported separately from stored resources',()=>{
 const s=setup();const before=s.brief();assert.ok(before.resources.stoneRemaining>0);
 for(const d of s.gathering.deposits)d.remaining=0;
 s.world.resources.stone=0;
 const after=s.brief();assert.equal(after.resources.stoneRemaining,0);
 assert.equal(after.checks.find(c=>c.id==='stone').severity,'danger');
});
test('briefing never mutates gameplay state',()=>{
 const s=setup();const before={world:s.world.serialize(),siege:s.siege.snapshot(),g:s.gathering.snapshot(),d:s.defenses.snapshot(),workers:s.workers.snapshot()};
 for(let i=0;i<20;i++)s.brief();
 assert.deepEqual({world:s.world.serialize(),siege:s.siege.snapshot(),g:s.gathering.snapshot(),d:s.defenses.snapshot(),workers:s.workers.snapshot()},before);
});
test('no phantom wave or enemy counts are fabricated after victory',()=>{
 const s=setup();s.siege.wave=6;s.siege.phase='VICTORY';
 const b=s.brief();assert.equal(b.intel,null);assert.equal(b.recommendation,'Все шесть осад пройдены.');
});
test('legacy research is disallowed in victory or defeat and remains available during preparation',()=>{
 const s=setup();s.siege.research=100;
 s.siege.phase='VICTORY';assert.equal(s.siege.unlock('carrot'),false);
 s.siege.phase='DEFEAT';assert.equal(s.siege.unlock('carrot'),false);
 s.siege.phase='PREP';assert.equal(s.siege.unlock('carrot'),true);
 assert.equal(s.siege.research,80);
});
test('new strategy text distinguishes wall-vaulting scouts from ranged artillery',()=>{
 const s=setup();s.siege.wave=1;
 assert.match(s.brief().recommendation,/Прыгуны/);
 s.siege.wave=2;
 assert.match(s.brief().recommendation,/Артиллеристы/);
});
