# G10.1.2 — Touch Detection & CI Diagnostics (v2.5.2)

CI failure on v2.5.1: Playwright could not find visible `#mobile-controls`. The root cause is not proven from the screenshot alone.

Changes:
- Touch detection now includes `navigator.maxTouchPoints > 0` in addition to coarse-pointer and `ontouchstart` detection.
- Production smoke prints the emulated device signals before asserting the touch UI exists.
- Tests assert control DOM attachment separately from button visibility, providing more useful failure messages.
- Saves and game balance unchanged.

If the smoke still fails, download `smoke-debug` from Actions and inspect `smoke-mobile-missing-controls.png`. Do not assume a successful deployment until CI passes.
