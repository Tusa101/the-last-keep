import * as THREE from 'three';
import {World,type Cell,type Shape,type Orientation} from '../world/model.ts';
import type {Excavation} from '../world/excavation.ts';
import {STRATUM_HEIGHT} from '../world/excavation.ts';
import {shapeBoxes} from '../world/shapes.ts';
import {collectBatches} from './batches.ts';
import {DEFENSE_SLOTS,type Defense} from '../game/defenses.ts';
import type {Raider,Weapon,BattleEvent} from '../game/siege.ts';
import type {Vec3} from '../game/combat.ts';
import {makeSurfaceTexture} from './textures.ts';
import {makeScenery} from './scenery.ts';
import {makeDepositVisuals} from './deposits.ts';
import type {Deposit} from '../game/gathering.ts';
import {STOCKPILE,type Worker,type Order} from '../game/workers.ts';
import {workerRenderer} from './workers.ts';
import {createParticles} from './particles.ts';
import {blockFeedback} from '../game/worldFeedback.ts';
import {makeDefenseModel} from './defenseModels.ts';
import {makeRaiderVisual,animateRaiderVisual,removeRaiderVisual,type RaiderVisual} from './characters.ts';
export type Aim={hit:Cell|null;place:Cell|null};
export function makeScene(world:World,terrain?:Excavation){
 const scene=new THREE.Scene();scene.background=new THREE.Color('#bdc6b1');scene.fog=new THREE.Fog('#bdc6b1',34,94);
 const camera=new THREE.PerspectiveCamera(76,innerWidth/innerHeight,.06,140);
 const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);
 renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;
 renderer.domElement.id='game-canvas';
 document.body.appendChild(renderer.domElement);
 const hemisphere=new THREE.HemisphereLight('#f9e7c6','#5b6252',2.15);scene.add(hemisphere);
 const sun=new THREE.DirectionalLight('#fff0c9',2.15);sun.position.set(-14,27,21);scene.add(sun);
 // Ground is generated as actual heightfield quads (with sidewalls) in syncTrenches.
 let terrainFloor:THREE.Mesh|null=null,terrainWalls:THREE.Mesh|null=null;
 const stoneMap=makeSurfaceTexture('stone'),woodMap=makeSurfaceTexture('wood');
 const materials={
  stone:new THREE.MeshLambertMaterial({map:stoneMap,color:'#ddd7c8'}),wood:new THREE.MeshLambertMaterial({map:woodMap,color:'#e5d6b9'}),
  stoneDamaged:new THREE.MeshLambertMaterial({map:stoneMap,color:'#8a7771'}),woodDamaged:new THREE.MeshLambertMaterial({map:woodMap,color:'#986c65'})
 };
 const cube=new THREE.BoxGeometry(1,1,1),batchMeshes:THREE.InstancedMesh[]=[];
 const dummy=new THREE.Object3D();const tint=new THREE.Color();
 const seed=(x:number,y:number,z:number,part:number)=>{
  const hash=Math.sin(x*31.17+y*39.67+z*13.19+part*92.3)*43758.5453;
  return .88+((hash-Math.floor(hash))*.19);
 };
 /** Instancing groups identical material and damage state into a handful of draw calls.
  * For now edits still rebuild all instance buffers; chunk-dirty updates come later. */
 function rebuild(){
  for(const mesh of batchMeshes){scene.remove(mesh);mesh.dispose();}batchMeshes.length=0;
  const groups=collectBatches(world);
  for(const [kind,items] of groups){
   const mesh=new THREE.InstancedMesh(cube,materials[kind as keyof typeof materials],items.length);
   const lookup:Cell[]=[];
   items.forEach(({cell,box},i)=>{
    dummy.position.set(cell.x+(box.x0+box.x1)/2,cell.y+(box.y0+box.y1)/2,cell.z+(box.z0+box.z1)/2);
    dummy.scale.set(box.x1-box.x0,box.y1-box.y0,box.z1-box.z0);dummy.rotation.set(0,0,0);dummy.updateMatrix();
    mesh.setMatrixAt(i,dummy.matrix);tint.setScalar(seed(cell.x,cell.y,cell.z,i));mesh.setColorAt(i,tint);
    lookup.push(cell);
   });
   mesh.instanceMatrix.needsUpdate=true;
   if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
   mesh.userData.cells=lookup;mesh.computeBoundingSphere();scene.add(mesh);batchMeshes.push(mesh);
  }
 }
 world.onChange(rebuild);rebuild();
 /** Batched, watertight grid: a floor at each depth and vertical cliff walls
  * on edges to higher neighbours. Only rebuilt after terrain revision. Two meshes
  * rather than one mesh per cell (previously hundreds of draw calls).
  * This is an authoritative geometric representation, not a visual overlay.
  */
 const grassMat=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
 const cliffMat=new THREE.MeshLambertMaterial({vertexColors:true,side:THREE.DoubleSide});
 let trenchRevision=-1;
 function syncTrenches(pits:readonly {x:number;z:number;depth:number}[],revision:number){
  if(revision===trenchRevision)return;trenchRevision=revision;
  if(terrainFloor){scene.remove(terrainFloor);terrainFloor.geometry.dispose();}
  if(terrainWalls){scene.remove(terrainWalls);terrainWalls.geometry.dispose();}
  const map=new Map(pits.map(c=>[`${c.x},${c.z}`,c.depth]));
  const depth=(x:number,z:number)=>map.get(`${x},${z}`)??0;
  const verts:number[]=[],colors:number[]=[],walls:number[]=[],wallColors:number[]=[];
  const green=new THREE.Color('#81936d'),soil=new THREE.Color('#675340');
  const edge=new THREE.Color('#9f7d58'),rock=new THREE.Color('#57483e');
  function quad(points:[number,number,number][],tint:THREE.Color,out:number[],outColor:number[]){
   for(const i of [0,1,2,0,2,3]){
    out.push(...points[i]);outColor.push(tint.r,tint.g,tint.b);
   }
  }
  for(let x=-23;x<=23;x++)for(let z=-23;z<=23;z++){
   const d=depth(x,z),y=-d*STRATUM_HEIGHT;
   const c=d===0?green.clone():soil.clone();
   const varied=1+Math.sin(x*13.12+z*8.43)*.042;c.multiplyScalar(varied);
   quad([[x-.5,y,z-.5],[x-.5,y,z+.5],[x+.5,y,z+.5],[x+.5,y,z-.5]],c,verts,colors);
   for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){
    const neighborY=-depth(x+dx,z+dz)*STRATUM_HEIGHT;
    if(neighborY<=y)continue;
    const edgeTint=edge.clone().lerp(rock,Math.min(d/4,.8));
    let a:[number,number,number],b:[number,number,number];
    if(dx===1){a=[x+.5,y,z-.5];b=[x+.5,y,z+.5];}
    else if(dx===-1){a=[x-.5,y,z+.5];b=[x-.5,y,z-.5];}
    else if(dz===1){a=[x+.5,y,z+.5];b=[x-.5,y,z+.5];}
    else{a=[x-.5,y,z-.5];b=[x+.5,y,z-.5];}
    quad([a,b,[b[0],neighborY,b[2]],[a[0],neighborY,a[2]]],edgeTint,walls,wallColors);
   }
  }
  function makeGeometry(positions:number[],rgb:number[]){
   const g=new THREE.BufferGeometry();
   g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
   g.setAttribute('color',new THREE.Float32BufferAttribute(rgb,3));
   g.computeVertexNormals();g.computeBoundingSphere();return g;
  }
  terrainFloor=new THREE.Mesh(makeGeometry(verts,colors),grassMat);
  terrainWalls=new THREE.Mesh(makeGeometry(walls,wallColors),cliffMat);
  terrainFloor.userData.ground=true;scene.add(terrainFloor,terrainWalls);
 }
 syncTrenches(terrain?.cells()??[],terrain?.revision??0);
 const defenseGroup=new THREE.Group();scene.add(defenseGroup);
 // Permanent labelled floor pads make emplacement locations discoverable BEFORE buying.
 const defensePads:THREE.Group[]=[];
 const padFree=new THREE.MeshLambertMaterial({color:'#a58154'}),padFilled=new THREE.MeshLambertMaterial({color:'#4f9e82'});
 DEFENSE_SLOTS.forEach((p,index)=>{
  const group=new THREE.Group();group.position.set(p.x,(terrain?.groundY(p.x,p.z)??0)+.045,p.z);
  const base=new THREE.Mesh(new THREE.CylinderGeometry(.90,.90,.08,12),padFree);base.position.y=.04;group.add(base);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(.78,.065,6,14),new THREE.MeshLambertMaterial({color:'#f1c87b'}));rim.rotation.x=-Math.PI/2;rim.position.y=.13;group.add(rim);
  // Number of the emplacement shown as 3D marker plus minimap label.
  const count=new THREE.Mesh(new THREE.BoxGeometry(.18,.19,.18),new THREE.MeshLambertMaterial({color:'#ffeed1'}));count.position.set(0,.24,0);group.add(count);
  group.userData.base=base;group.userData.slot=index;scene.add(group);defensePads.push(group);
 });

 const defenseMeshes=new Map<number,THREE.Group>();
 function syncDefenses(defenses:readonly Defense[]){
  for(const pad of defensePads){const base=pad.userData.base as THREE.Mesh;const index=pad.userData.slot as number;base.material=defenses.some(d=>d.slot===index)?padFilled:padFree;}
  const desired=new Map(defenses.map(d=>[d.slot,d.kind]));
  for(const [slot,group] of defenseMeshes)if(!desired.has(slot)||group.userData.kind!==desired.get(slot)){
   defenseGroup.remove(group);
   group.traverse(obj=>{if(obj instanceof THREE.Mesh){obj.geometry.dispose();(obj.material as THREE.Material).dispose();}});
   defenseMeshes.delete(slot);
  }
  for(const d of defenses){if(defenseMeshes.has(d.slot))continue;
   const group=makeDefenseModel(d.kind),p=DEFENSE_SLOTS[d.slot];group.userData.kind=d.kind;
   group.position.set(p.x,terrain?.groundY(p.x,p.z)??0,p.z);
   defenseGroup.add(group);defenseMeshes.set(d.slot,group);
  }
 }
 const preview=new THREE.Group();scene.add(preview);
 const green=new THREE.MeshBasicMaterial({color:'#70edb3',transparent:true,opacity:.40,depthWrite:false,side:THREE.DoubleSide});
 const red=new THREE.MeshBasicMaterial({color:'#ff7770',transparent:true,opacity:.44,depthWrite:false,side:THREE.DoubleSide});
 let previewSignature='';
 function showPreview(cells:Cell[],valid:boolean,shape:Shape,dir:Orientation=0){
  const signature=`${valid}/${shape}/${dir}/${cells.map(c=>`${c.x},${c.y},${c.z}`).join(';')}`;
  if(signature===previewSignature)return;previewSignature=signature;
  preview.clear();
  const boxes=shapeBoxes(shape,dir);
  for(const c of cells)for(const box of boxes){
   const mesh=new THREE.Mesh(cube,valid?green:red);
   mesh.position.set(c.x+(box.x0+box.x1)/2,c.y+(box.y0+box.y1)/2,c.z+(box.z0+box.z1)/2);
   mesh.scale.set(box.x1-box.x0,box.y1-box.y0,box.z1-box.z0);preview.add(mesh);
  }
 }
 // Worker construction orders appear as transparent blue plans, not built masonry.
 // These projections never alter collisions, resources or the authoritative world.
 const ordersVisual=new THREE.Group();scene.add(ordersVisual);
 const orderMaterial=new THREE.MeshBasicMaterial({color:'#80c9bd',transparent:true,opacity:.24,depthWrite:false,side:THREE.DoubleSide});
 let orderSignature='';
 function syncOrders(orders:readonly Order[]){
  const signature=orders.map(o=>`${o.id}@${o.cell.x},${o.cell.y},${o.cell.z}/${o.shape}/${o.dir}`).join('|');
  if(signature===orderSignature)return;orderSignature=signature;ordersVisual.clear();
  for(const o of orders){
   for(const part of shapeBoxes(o.shape,o.dir)){
    const mesh=new THREE.Mesh(cube,orderMaterial);
    mesh.position.set(o.cell.x+(part.x0+part.x1)/2,o.cell.y+(part.y0+part.y1)/2,o.cell.z+(part.z0+part.z1)/2);
    mesh.scale.set(part.x1-part.x0,part.y1-part.y0,part.z1-part.z0);
    ordersVisual.add(mesh);
   }
  }
 }
 const ray=new THREE.Raycaster();ray.far=8;const direction=new THREE.Vector3();
 function aim():Aim{
  camera.getWorldDirection(direction);ray.set(camera.position,direction);
  const hits=ray.intersectObjects([...batchMeshes,...(terrainFloor?[terrainFloor]:[])]);if(!hits.length)return {hit:null,place:null};
  const h=hits[0];if(h.object.userData.ground)return {hit:null,place:{x:Math.round(h.point.x),y:0,z:Math.round(h.point.z)}};
  const cell=(h.object.userData.cells as Cell[])[h.instanceId??-1];
  if(!cell||!h.face)return {hit:null,place:null};
  const n=h.face.normal;
  return {hit:cell,place:{x:cell.x+Math.round(n.x),y:cell.y+Math.round(n.y),z:cell.z+Math.round(n.z)}};
 }
 // Environmental meshes are visual props, never blockers or resource deposits.
 const scenery=makeScenery(scene);
 let depositVisuals:ReturnType<typeof makeDepositVisuals>|null=null;
 function setDeposits(deposits:readonly Deposit[]){if(!depositVisuals)depositVisuals=makeDepositVisuals(scene,deposits);}
 const nexus=new THREE.Mesh(new THREE.OctahedronGeometry(1.15),new THREE.MeshLambertMaterial({color:'#70d9c5',emissive:'#14675c',emissiveIntensity:.5}));nexus.position.set(9,1.65,0);scene.add(nexus);
 const pedestal=new THREE.Mesh(new THREE.CylinderGeometry(1.2,1.5,.6,8),new THREE.MeshLambertMaterial({color:'#67675c'}));pedestal.position.set(9,.3,0);scene.add(pedestal);
 // A simple visible spring trap near the Nexus; its charges are simulated by Siege.
 const trap=new THREE.Group();trap.position.set(7,0,0);scene.add(trap);
 // The common stockpile is intentionally readable from a distance. Supplies
 // enter the shared resource economy ONLY when a porter returns here.
 const stock=new THREE.Group();stock.position.set(STOCKPILE.x,0,STOCKPILE.z);scene.add(stock);
 const stockWood=new THREE.MeshLambertMaterial({color:'#7c543a'});
 const stockIron=new THREE.MeshLambertMaterial({color:'#3d4d49'});
 const stockCloth=new THREE.MeshLambertMaterial({color:'#d5bd8a'});
 const platform=new THREE.Mesh(new THREE.BoxGeometry(2.5,.16,2.5),stockWood);
 platform.position.y=.08;stock.add(platform);
 for(const [x,z] of [[-.85,-.85],[.85,-.85],[-.85,.85],[.85,.85]]){
  const post=new THREE.Mesh(new THREE.BoxGeometry(.13,1.65,.13),stockWood);
  post.position.set(x,.9,z);stock.add(post);
 }
 const canopy=new THREE.Mesh(new THREE.ConeGeometry(1.83,.95,4),stockCloth);
 canopy.rotation.y=Math.PI/4;canopy.position.set(0,2.1,0);stock.add(canopy);
 for(const x of [-.45,.40]){
  const crate=new THREE.Mesh(new THREE.BoxGeometry(.65,.52,.60),stockWood);
  crate.position.set(x,.40,.60);stock.add(crate);
  const band=new THREE.Mesh(new THREE.BoxGeometry(.71,.10,.65),stockIron);
  band.position.set(x,.42,.60);stock.add(band);
 }
 const stockFlag=new THREE.Mesh(new THREE.PlaneGeometry(.64,.42),new THREE.MeshLambertMaterial({color:'#658f7e',side:THREE.DoubleSide}));
 stockFlag.position.set(0,1.24,-.94);stock.add(stockFlag);
 const springMetal=new THREE.MeshStandardMaterial({color:'#bf8d48',metalness:.5,roughness:.4});
 const trapBase=new THREE.Mesh(new THREE.CylinderGeometry(.67,.76,.25,10),springMetal);trapBase.position.y=.15;trap.add(trapBase);
 for(let i=0;i<5;i++){const coil=new THREE.Mesh(new THREE.TorusGeometry(.3,.036,6,14),springMetal);coil.rotation.x=Math.PI/2;coil.position.y=.38+i*.12;trap.add(coil);}
 const springHead=new THREE.Mesh(new THREE.IcosahedronGeometry(.32,0),new THREE.MeshLambertMaterial({color:'#e9a638'}));springHead.position.y=1.06;trap.add(springHead);
 // G9: capped single-draw-call impact particles; presentation never affects game state.
 const particles=createParticles(scene,160);
 let previousBlocks=new Map([...world.blocks].map(([id,block])=>[id,block.hp]));
 world.onChange(reason=>{
  const current=new Map([...world.blocks].map(([id,block])=>[id,block.hp]));
  for(const effect of blockFeedback(previousBlocks,current,reason,9))particles.spawn(effect.kind,effect);
  previousBlocks=current;
 });
 // Short-lived local VFX; drawn separately from the authoritative combat simulation.
 const effects:{object:THREE.Object3D;ttl:number;duration:number;type:'shot'|'burst'|'projectile';from?:THREE.Vector3;to?:THREE.Vector3}[]=[];
 const beamGeo=new THREE.CylinderGeometry(.025,.025,1,6);
 function playShot(from:Vec3,to:Vec3,weapon:Weapon){
  const a=new THREE.Vector3(from.x,from.y,from.z),b=new THREE.Vector3(to.x,to.y,to.z),delta=b.clone().sub(a);
  if(delta.lengthSq()<.001)return;
  const beam=new THREE.Mesh(beamGeo,new THREE.MeshBasicMaterial({color:weapon==='carrot'?'#f98a24':'#e9d8a0',transparent:true,opacity:.9,depthWrite:false}));
  beam.position.copy(a).add(b).multiplyScalar(.5);beam.scale.y=delta.length();beam.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());
  scene.add(beam);effects.push({object:beam,ttl:.12,duration:.12,type:'shot'});
 }
 function playImpact(point:Vec3,type:BattleEvent['kind']){
  const geometry=new THREE.IcosahedronGeometry(type==='kill'?.32:.16,0);
  const tint=type==='pudding'?'#ba69ed':type==='trap'?'#ffb33a':type==='breach'?'#dad3b4':type==='kill'?'#ffa4cd':type==='nexus'?'#45ecdf':'#ffe6aa';
  const mesh=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:tint,transparent:true,opacity:.95,depthWrite:false}));
  mesh.position.set(point.x,point.y,point.z);scene.add(mesh);
  effects.push({object:mesh,ttl:type==='kill'?.48:.25,duration:type==='kill'?.48:.25,type:'burst'});
  particles.spawn(type,point);
 }
 function playDefense(kind:'carrotTower'|'cheeseMortar'|'syrupSprayer',from:Vec3,to:Vec3){
  const turret=defenseMeshes.get((DEFENSE_SLOTS as readonly {x:number;z:number}[]).findIndex(p=>p.x===from.x&&p.z===from.z))?.userData.turret as THREE.Group|undefined;
  if(turret){turret.rotation.y=Math.atan2(to.x-from.x,-(to.z-from.z));}
  particles.spawn(kind,{x:from.x,y:.95,z:from.z});
  particles.spawn(kind,{x:to.x,y:.75,z:to.z});
  if(kind!=='syrupSprayer'){
   const fromPoint=new THREE.Vector3(from.x,from.y,from.z),toPoint=new THREE.Vector3(to.x,to.y,to.z);
   const missile=new THREE.Mesh(kind==='cheeseMortar'?new THREE.IcosahedronGeometry(.25,0):new THREE.ConeGeometry(.115,.36,6),
    new THREE.MeshBasicMaterial({color:kind==='cheeseMortar'?'#ffe36a':'#e88e33',transparent:true,opacity:.98,depthWrite:false}));
   if(kind==='carrotTower')missile.rotation.x=Math.PI/2;
   missile.position.copy(fromPoint);scene.add(missile);
   effects.push({object:missile,ttl:kind==='cheeseMortar'?.52:.24,duration:kind==='cheeseMortar'?.52:.24,
    type:'projectile',from:fromPoint,to:toPoint});
  }
 }
 function playPudding(from:Vec3,to:Vec3){
  // Projectile is a presentation only; wall damage is resolved in the deterministic Siege.
  const goo=new THREE.Mesh(new THREE.IcosahedronGeometry(.24,1),
   new THREE.MeshBasicMaterial({color:'#c781ef',transparent:true,opacity:.95,depthWrite:false}));
  const a=new THREE.Vector3(from.x,from.y,from.z),b=new THREE.Vector3(to.x,to.y,to.z);
  goo.position.copy(a);scene.add(goo);
  effects.push({object:goo,ttl:.43,duration:.43,type:'projectile',from:a,to:b});
 }
 function tickEffects(dt:number){particles.tick(dt);for(let i=effects.length-1;i>=0;i--){const effect=effects[i];effect.ttl-=dt;
  if(effect.type==='burst')effect.object.scale.setScalar(1+(1-effect.ttl/effect.duration)*1.8);
  if(effect.type==='projectile'&&effect.from&&effect.to){
   const t=Math.max(0,Math.min(1,1-effect.ttl/effect.duration));
   effect.object.position.copy(effect.from).lerp(effect.to,t);
   effect.object.position.y+=(effect.duration>.5?2.1:1.15)*Math.sin(Math.PI*t);
  }
  const mesh=effect.object as THREE.Mesh;const mat=mesh.material as THREE.MeshBasicMaterial;mat.opacity=Math.max(0,effect.ttl/effect.duration);
  if(effect.ttl<=0){scene.remove(effect.object);if(effect.type!=='shot')mesh.geometry.dispose();mat.dispose();effects.splice(i,1);}
 }}
 // Two lightweight first-person props make the weapon identity readable without external assets.
 scene.add(camera);
 const weaponMount=new THREE.Group();weaponMount.position.set(.46,-.40,-.77);camera.add(weaponMount);
 const boltModel=new THREE.Group(),carrotModel=new THREE.Group();weaponMount.add(boltModel,carrotModel);
 const oak=new THREE.MeshLambertMaterial({color:'#805236'}),metal=new THREE.MeshLambertMaterial({color:'#4e5456'});
 const carrotOrange=new THREE.MeshLambertMaterial({color:'#ee8233'}),greens=new THREE.MeshLambertMaterial({color:'#5aa76a'});
 function cylinder(parent:THREE.Group,from:THREE.Vector3,to:THREE.Vector3,r:number,mat:THREE.Material){
  const diff=to.clone().sub(from);const beam=new THREE.Mesh(new THREE.CylinderGeometry(r,r,diff.length(),7),mat);
  beam.position.copy(from).add(to).multiplyScalar(.5);beam.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),diff.normalize());parent.add(beam);
 }
 // Conventional small medieval crossbow: stock, arms and visible steel bowstring.
 cylinder(boltModel,new THREE.Vector3(0,-.15,.22),new THREE.Vector3(0,0,-.60),.08,oak);
 cylinder(boltModel,new THREE.Vector3(-.28,0,-.48),new THREE.Vector3(.28,0,-.48),.075,oak);
 cylinder(boltModel,new THREE.Vector3(-.28,0,-.48),new THREE.Vector3(0,-.025,-.15),.009,metal);
 cylinder(boltModel,new THREE.Vector3(.28,0,-.48),new THREE.Vector3(0,-.025,-.15),.009,metal);
 cylinder(boltModel,new THREE.Vector3(0,.03,.05),new THREE.Vector3(0,.04,-.60),.022,metal);
 // Absurd equipment keeps a medieval stock and brass fittings, not sci-fi styling.
 cylinder(carrotModel,new THREE.Vector3(0,-.15,.22),new THREE.Vector3(0,-.03,-.30),.10,oak);
 const fat=new THREE.Mesh(new THREE.ConeGeometry(.135,.54,8),carrotOrange);fat.rotation.x=Math.PI/2;fat.position.set(0,.03,-.42);carrotModel.add(fat);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(.14,.025,8,16),metal);ring.position.set(0,.03,-.17);carrotModel.add(ring);
 for(const angle of [-.45,0,.45]){const leaf=new THREE.Mesh(new THREE.ConeGeometry(.04,.23,5),greens);leaf.rotation.x=1.25;leaf.rotation.z=angle;leaf.position.set(angle*.18,.13,-.24);carrotModel.add(leaf);}
 let currentWeapon:Weapon='bolt',recoil=0;
 function setWeapon(type:Weapon){currentWeapon=type;boltModel.visible=type==='bolt';carrotModel.visible=type==='carrot';}
 function fireWeapon(){recoil=.19;}
 setWeapon('bolt');
 function animateWeapon(dt:number,now:number){recoil=Math.max(0,recoil-dt*.8);weaponMount.position.z=-.77+recoil;
  weaponMount.rotation.x=-recoil*.7+Math.sin(now*.0019)*.008;}
 const workerViews=workerRenderer(scene,(x,z)=>terrain?.groundY(x,z)??0);
 const raiderMeshes=new Map<number,RaiderVisual>();
 function syncRaiders(raiders:Raider[],now:number){
  const active=new Set<number>();
  for(const r of raiders){if(!r.alive||r.spawnIn>0)continue;active.add(r.id);
   let visual=raiderMeshes.get(r.id);
   if(!visual){visual=makeRaiderVisual(r);scene.add(visual.root);raiderMeshes.set(r.id,visual);}
   animateRaiderVisual(visual,r,now,camera);
   // A hopper vaults the ditch instead of gliding down the excavation floor.
   const trenchY=terrain?.groundY(r.brain.x,r.brain.z)??0;
   visual.root.position.y+=r.kind==='hopper'&&trenchY<0 ? .15+Math.abs(Math.sin(now*.012+r.id))*Math.min(1,-trenchY):trenchY;
  }
  for(const [id,visual] of raiderMeshes)if(!active.has(id)){
   removeRaiderVisual(scene,visual);raiderMeshes.delete(id);
  }
 }
 let currentPhase='PREP';
 const colors:Record<string,{sky:string;sun:string;strength:number;hemi:number;fog:number}>={
  PREP:{sky:'#bdc6b1',sun:'#fff0c9',strength:2.15,hemi:2.15,fog:94},
  WARNING:{sky:'#b49b8b',sun:'#ffd4a1',strength:2.2,hemi:1.95,fog:84},
  SIEGE:{sky:'#819fa5',sun:'#d5dfe4',strength:1.66,hemi:1.72,fog:77},
  RESULT:{sky:'#b9c5ae',sun:'#fff0c9',strength:2.15,hemi:2.15,fog:94},
  VICTORY:{sky:'#e2cba7',sun:'#fff2be',strength:2.45,hemi:2.3,fog:100},
  DEFEAT:{sky:'#8b7a79',sun:'#c9b5aa',strength:1.36,hemi:1.50,fog:68}
 };
 function setPhase(phase:string){currentPhase=phase;}
 const sky=new THREE.Color(),sunColor=new THREE.Color();
 const updateAtmosphere=()=>{
  const settings=colors[currentPhase]??colors.PREP;
  sky.set(settings.sky);sunColor.set(settings.sun);
  (scene.background as THREE.Color).lerp(sky,.045);
  (scene.fog as THREE.Fog).color.copy(scene.background as THREE.Color);
  sun.color.lerp(sunColor,.045);sun.intensity+=(settings.strength-sun.intensity)*.04;
  hemisphere.intensity+=(settings.hemi-hemisphere.intensity)*.04;
  (scene.fog as THREE.Fog).far+=(settings.fog-(scene.fog as THREE.Fog).far)*.04;
 };
 const feedback=document.createElement('div');feedback.id='nexus-feedback';feedback.setAttribute('aria-hidden','true');document.body.appendChild(feedback);
 let hitFlash=0;
 function flashNexus(){hitFlash=1;}
 function tickFeedback(dt:number,nexusHealth:number){
  hitFlash=Math.max(0,hitFlash-Math.max(0,dt)*2.3);
  const healthWarning=Math.max(0,(35-nexusHealth)/35);
  feedback.style.opacity=String(Math.min(.83,hitFlash*.72+healthWarning*.24));
  feedback.classList.toggle('critical',nexusHealth<=25);
 }
 let resolutionScale=1;
 const updateResolution=()=>{renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)*resolutionScale);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);};
 addEventListener('resize',updateResolution);
 return {camera,renderer,syncDefenses,syncTrenches,syncOrders,syncRaiders,syncWorkers:(people:readonly Worker[],now:number)=>workerViews.sync(people,now),setPhase,setDeposits,syncDeposits:(deposits:readonly Deposit[],now:number)=>depositVisuals?.sync(deposits,now),aim,showPreview,playShot,playImpact,playPudding,playDefense,flashNexus,tickFeedback,tickEffects,setWeapon,fireWeapon,animateWeapon,stats:()=>({drawCalls:renderer.info.render.calls,batches:batchMeshes.length,particles:particles.count,turretModels:defenseMeshes.size,emplacementPads:defensePads.length}),
  setResolutionScale:(scale:number)=>{resolutionScale=Math.max(.5,Math.min(1.4,scale));updateResolution();},
  render:(now:number)=>{updateAtmosphere();scenery.animate(now,currentPhase);nexus.rotation.y+=.008;nexus.position.y=1.65+.12*Math.sin(now*.002);springHead.position.y=1.06+.055*Math.sin(now*.008);renderer.render(scene,camera);}};
}
