import type {World} from '../world/model.ts';
import type {Raider,BattleEvent,Phase} from './siege.ts';
export type DefenseKind='carrotTower'|'cheeseMortar'|'syrupSprayer';
export type Defense={slot:number;kind:DefenseKind;cooldown:number};
// Five accessible, visible emplacements INSIDE the walls; each can be identified on the map.
export const DEFENSE_SLOTS=[{x:-8,z:-6},{x:-8,z:6},{x:2,z:-6},{x:6,z:-6},{x:6,z:6}] as const;
export type InstallationCheck={ok:boolean;reason:string};
export const DEFENSE_COSTS:Record<DefenseKind,{wood:number;stone:number;label:string}>={
 carrotTower:{wood:9,stone:3,label:'Морковная турель'},
 cheeseMortar:{wood:6,stone:12,label:'Сырная мортира'},
 syrupSprayer:{wood:12,stone:4,label:'Сиропный распылитель'}
};
export type DefenseEvent={kind:'carrotTower'|'cheeseMortar'|'syrupSprayer';x:number;z:number;targetX:number;targetZ:number};
/** Fixed emplacements are explicit slots, not invisible global buffs. */
export class Defenses{
 readonly placed:Defense[]=[];events:DefenseEvent[]=[];
 /** Derived from progression; no need to put it into defense saves. */
 ordnanceLevel=0;
 readonly world:World;
 constructor(world:World){this.world=world;}
 checkInstall(slot:number,kind:DefenseKind,phase:Phase):InstallationCheck{
  const cost=DEFENSE_COSTS[kind];
  if(!cost)return {ok:false,reason:'Неизвестное орудие'};
  if(!Number.isInteger(slot)||slot<0||slot>=DEFENSE_SLOTS.length)return {ok:false,reason:'Такой позиции не существует'};
  if(!['PREP','RESULT'].includes(phase))return {ok:false,reason:'Орудия строятся только во время подготовки'};
  if(this.placed.some(d=>d.slot===slot))return {ok:false,reason:`Позиция ${slot+1} уже занята`};
  const p=DEFENSE_SLOTS[slot];
  if(this.world.groundObstructions(p.x,p.z).length)return {ok:false,reason:`Позиция ${slot+1} перекрыта кладкой — разбери мешающий блок`};
  if(this.world.resources.wood<cost.wood||this.world.resources.stone<cost.stone)
   return {ok:false,reason:`Не хватает ресурсов: нужно ${cost.wood} дерева и ${cost.stone} камня (есть ${Math.floor(this.world.resources.wood)}/${Math.floor(this.world.resources.stone)})`};
  return {ok:true,reason:`Можно построить: ${cost.label}`};
 }
 installDetailed(slot:number,kind:DefenseKind,phase:Phase):InstallationCheck{
  const check=this.checkInstall(slot,kind,phase);if(!check.ok)return check;
  const cost=DEFENSE_COSTS[kind];this.world.resources.wood-=cost.wood;this.world.resources.stone-=cost.stone;
  this.placed.push({slot,kind,cooldown:0});return {ok:true,reason:`${cost.label} установлена на позиции ${slot+1}`};
 }
 install(slot:number,kind:DefenseKind,phase:Phase):boolean{return this.installDetailed(slot,kind,phase).ok;}

 step(dt:number,phase:Phase,raiders:Raider[],events:BattleEvent[],onKill:()=>void){
  if(phase!=='SIEGE'||!Number.isFinite(dt)||dt<=0)return;
  for(const d of this.placed){d.cooldown=Math.max(0,d.cooldown-dt);if(d.cooldown>0)continue;
   const pos=DEFENSE_SLOTS[d.slot];const radius=d.kind==='carrotTower'?8:d.kind==='cheeseMortar'?7:4;
   const targets=raiders.filter(r=>r.alive&&r.spawnIn<=0&&Math.hypot(r.brain.x-pos.x,r.brain.z-pos.z)<=radius);
   if(!targets.length)continue;
   targets.sort((a,b)=>Math.hypot(a.brain.x-pos.x,a.brain.z-pos.z)-Math.hypot(b.brain.x-pos.x,b.brain.z-pos.z));
   const first=targets[0];d.cooldown=(d.kind==='carrotTower'?1.25:d.kind==='cheeseMortar'?3.2:2.4)*(this.ordnanceLevel>=2?.85:1);
   this.events.push({kind:d.kind,x:pos.x,z:pos.z,targetX:first.brain.x,targetZ:first.brain.z});
   const victims=d.kind==='cheeseMortar'?targets.filter(r=>Math.hypot(r.brain.x-first.brain.x,r.brain.z-first.brain.z)<=2.2):[first];
   for(const r of victims){
    if(d.kind==='syrupSprayer'){r.stun=Math.max(r.stun,1.1+this.ordnanceLevel*.35);continue;}
    const damage=Math.round((d.kind==='carrotTower'?19:32)*(1+.25*this.ordnanceLevel));r.hp=Math.max(0,r.hp-damage);
    events.push({kind:'hit',point:{x:r.brain.x,y:.9,z:r.brain.z}});
    if(r.hp===0&&r.alive){r.alive=false;onKill();events.push({kind:'kill',point:{x:r.brain.x,y:1,z:r.brain.z}});}
   }
  }
 }
 reset(){this.placed.length=0;this.events.length=0;}
 snapshot(){return JSON.stringify({version:1,placed:this.placed});}
 restore(json:string){const raw=JSON.parse(json) as {version:number;placed:Defense[]};
  if(raw.version!==1||!Array.isArray(raw.placed)||raw.placed.length>DEFENSE_SLOTS.length)throw Error('Invalid defenses save');
  const slots=new Set<number>();const next:Defense[]=[];
  for(const d of raw.placed){if(!d||!Number.isInteger(d.slot)||d.slot<0||d.slot>=DEFENSE_SLOTS.length||slots.has(d.slot)||
   !Object.hasOwn(DEFENSE_COSTS,d.kind)||typeof d.cooldown!=='number'||!Number.isFinite(d.cooldown)||d.cooldown<0||d.cooldown>4)throw Error('Invalid defense');
   slots.add(d.slot);next.push({...d});}
  this.placed.splice(0,this.placed.length,...next);this.events.length=0;
 }
}
