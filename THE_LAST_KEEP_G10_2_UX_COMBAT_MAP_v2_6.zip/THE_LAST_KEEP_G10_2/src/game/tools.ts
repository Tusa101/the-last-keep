/** One authoritative interaction mode shared by keyboard, mouse, and touch. */
export const TOOL_ORDER=['combat','build','demolish','repair','gather','dig'] as const;
export type Tool=typeof TOOL_ORDER[number];
export const TOOL_INFO:Record<Tool,{label:string;short:string;icon:string;hint:string}>={
 combat:{label:'Бой',short:'Огонь',icon:'⚔',hint:'Стреляет только во время осады'},
 build:{label:'Строительство',short:'Строить',icon:'🧱',hint:'Наведи прицел на свободную клетку'},
 demolish:{label:'Разборка',short:'Разобрать',icon:'🔨',hint:'Разбирает выбранную кладку'},
 repair:{label:'Ремонт',short:'Чинить',icon:'✚',hint:'Ремонтирует повреждённый блок'},
 gather:{label:'Добыча',short:'Добыть',icon:'⛏',hint:'Добывает материалы рядом с игроком'},
 dig:{label:'Земляные работы',short:'Копать',icon:'🕳',hint:'Углубляет грунт под прицелом'}
};
export class ToolSelection{
 private active:Tool='combat';
 get current():Tool{return this.active;}
 select(value:unknown):Tool|false{
  if(!TOOL_ORDER.includes(value as Tool))return false;
  this.active=value as Tool;return this.active;
 }
 get info(){return TOOL_INFO[this.active];}
 reset(){this.active='combat';}
}
/** Number row 1–6 is dedicated to selecting tools. */
export function toolFromKey(code:string):Tool|null{
 const n=Number(/^Digit([1-6])$/.exec(code)?.[1]??0);
 return n?TOOL_ORDER[n-1]:null;
}
