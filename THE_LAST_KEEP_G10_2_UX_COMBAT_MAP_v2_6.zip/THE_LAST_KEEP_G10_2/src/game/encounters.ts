/** Six authored waves: each adds a new tactical pressure without inventing enemy classes. */
export type AssaultFront='west'|'north';
export type Intel={wave:number;title:string;brief:string;fronts:AssaultFront[];
 jellies:number;brutes:number;hoppers:number;bombardiers:number};
export const ENCOUNTERS:readonly Intel[]=[
 {wave:1,title:'ПРОБА ВОРОТ',brief:'Четыре желейных рекрута с запада. Изучи прицел и восстанови проход.',fronts:['west'],jellies:4,brutes:0,hoppers:0,bombardiers:0},
 {wave:2,title:'ПРУЖИННАЯ РАЗВЕДКА',brief:'С запада идут прыгуны и карамельный таран. Рвы уже не спасут в одиночку.',fronts:['west'],jellies:3,brutes:1,hoppers:3,bombardiers:0},
 {wave:3,title:'ПУДИНГОВЫЙ ОБСТРЕЛ',brief:'Два фронта! Артиллеристы разрушают стены издалека. Найди их первыми.',fronts:['west','north'],jellies:4,brutes:1,hoppers:3,bombardiers:2},
 {wave:4,title:'ВТОРАЯ СМЕНА АЛХИМИКОВ',brief:'Враги наступают сразу с двух сторон. Усиль фланговые позиции и ремонт.',fronts:['west','north'],jellies:6,brutes:2,hoppers:3,bombardiers:2},
 {wave:5,title:'СЛАДКАЯ ОСАДНАЯ МАШИНА',brief:'Больше таранов и артиллерии. Береги дерево для починки и своевременной установки орудий.',fronts:['west','north'],jellies:5,brutes:2,hoppers:5,bombardiers:3},
 {wave:6,title:'ПОСЛЕДНИЙ КАРНАВАЛ',brief:'Финальная атака с запада и севера: тяжёлые тараны, прыгуны и пудинговая артиллерия.',fronts:['west','north'],jellies:7,brutes:3,hoppers:5,bombardiers:4}
];
export const TOTAL_WAVES=ENCOUNTERS.length;
export function waveIntel(wave:number):Intel{return ENCOUNTERS[Math.max(0,Math.min(TOTAL_WAVES-1,Math.floor(wave)-1))];}
export function nextIntel(currentWave:number):Intel|null{return currentWave>=TOTAL_WAVES?null:waveIntel(currentWave+1);}
/** Keeps ALL spawn positions inside bounds even for the 19-enemy final attack. */
export function raiderSpawn(wave:number,index:number,count:number):{x:number;z:number;front:AssaultFront}{
 const north=wave>=3&&index>=Math.ceil(count/2);
 const lane=north?index-Math.ceil(count/2):index;
 if(north)return {x:-9+(lane%10)*2,z:-17-Math.floor(lane/10),front:'north'};
 return {x:-17-Math.floor(lane/9),z:-8+(lane%9)*2,front:'west'};
}
export function clockLabel(seconds:number){const n=Math.max(0,Math.ceil(Number.isFinite(seconds)?seconds:0));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;}
export function phaseLabel(phase:string):string{return ({PREP:'ПОДГОТОВКА',WARNING:'АРМИЯ БЛИЗКО',SIEGE:'ОСАДА',RESULT:'ОТБИТО',VICTORY:'ПОБЕДА',DEFEAT:'НЕКСУС ПАЛ'} as Record<string,string>)[phase]??phase;}
