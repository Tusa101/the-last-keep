import {nextIntel,type Intel} from './encounters.ts';
import {DEFENSE_COSTS,DEFENSE_SLOTS,type DefenseKind,type Defenses} from './defenses.ts';
import type {World} from '../world/model.ts';
import {maxHP} from '../world/model.ts';
import type {Gathering} from './gathering.ts';
import type {Siege} from './siege.ts';
import type {Workers} from './workers.ts';

export type PreparationCheck={id:string;label:string;detail:string;severity:'ready'|'caution'|'danger'};
export type EmplacementQuote={slot:number;occupied:boolean;kind:DefenseKind|null;label:string};
export type WarBriefing={intel:Intel|null;checks:PreparationCheck[];risk:'ready'|'caution'|'danger';
 damagedBlocks:number;criticalBlocks:number;resources:{stone:number;wood:number;stoneRemaining:number;woodRemaining:number};
 emplacements:EmplacementQuote[];recommendation:string};

/** Read-only player guidance, not a predictive battle simulation. Never modifies game state. */
export function warBriefing(world:World,siege:Siege,defenses:Defenses,gathering:Gathering,workers:Workers):WarBriefing{
 const intel=nextIntel(siege.wave);
 let damagedBlocks=0,criticalBlocks=0;
 for(const block of world.blocks.values()){
  if(block.hp<maxHP(block.material)){damagedBlocks++;if(block.hp<=maxHP(block.material)*.4)criticalBlocks++;}
 }
 const stoneRemaining=gathering.deposits.filter(d=>d.material==='stone').reduce((s,d)=>s+d.remaining,0);
 const woodRemaining=gathering.deposits.filter(d=>d.material==='wood').reduce((s,d)=>s+d.remaining,0);
 const quotes=DEFENSE_SLOTS.map((_,slot)=>{
  const placed=defenses.placed.find(d=>d.slot===slot);
  return {slot,occupied:!!placed,kind:placed?.kind??null,label:placed?DEFENSE_COSTS[placed.kind].label:'Свободная позиция'};
 });
 const checks:PreparationCheck[]=[];
 const add=(id:string,label:string,detail:string,severity:PreparationCheck['severity'])=>checks.push({id,label,detail,severity});
 if(siege.nexus<=40)add('nexus','Нексус под угрозой',`${siege.nexus}/100 HP — ещё один прорыв может завершить забег.`,'danger');
 else if(siege.nexus<=70)add('nexus','Нексус повреждён',`${siege.nexus}/100 HP — не допускай новых прорывов.`,'caution');
 else add('nexus','Нексус держится',`${siege.nexus}/100 HP.`,'ready');
 if(criticalBlocks>0)add('walls','Аварийные укрепления',`${criticalBlocks} блок(а) ниже 40% прочности; всего повреждено ${damagedBlocks}.`,'danger');
 else if(damagedBlocks>0)add('walls','Нужен ремонт',`Повреждено ${damagedBlocks} блок(а). Ремонт: F или приоритет рабочих.`,'caution');
 else add('walls','Стены без повреждений','Существующая кладка цела, но проломы изначального замка могут сохраняться.','ready');
 if(intel?.wave===1)add('defenses','Первая встреча','Четыре рекрута: арбалета и ловушки достаточно для знакомства с боем.','ready');
 else if(intel){
  const count=defenses.placed.length;
  add('defenses',count===0?'Нет автоматической защиты':`${count}/${DEFENSE_SLOTS.length} оборонительных позиций`,
   count===0?'На следующей волне будут быстрые или дистанционные противники.':`Осталось свободных позиций: ${DEFENSE_SLOTS.length-count}.`,
   count===0?'caution':'ready');
 }
 if(intel&&world.resources.stone<3&&stoneRemaining<=0)add('stone','Камень исчерпан','Нет запаса камня и доступных залежей.','danger');
 else if(intel&&world.resources.wood<6&&woodRemaining<=0)add('wood','Древесина исчерпана','Нет древесины для новых машин и нет доступных залежей.','danger');
 else add('supplies','Запасы снабжения',`На складе ${Math.floor(world.resources.stone)} камня и ${Math.floor(world.resources.wood)} дерева.`,'ready');
 if(intel&&intel.wave>=2){
  add('labor',workers.workers.length===0?'Нет рабочих':`${workers.workers.length} рабочих`,
   workers.workers.length===0?'После первой волны найми помощника (J), чтобы разгрузить строительство.':
    `В очереди ${workers.orders.length} блок(а), ${workers.digOrders.length} раскопок.`,
   workers.workers.length===0?'caution':'ready');
 }
 const risk=checks.some(c=>c.severity==='danger')?'danger':checks.some(c=>c.severity==='caution')?'caution':'ready';
 const recommendation=!intel?'Все шесть осад пройдены.':
  intel.wave===1?'Закрой начальный пролом; проверь траекторию выстрела через бойницы.':
  intel.wave===2?'Прыгуны игнорируют штраф траншей: комбинируй стены и морковные турели.':
  'Артиллеристы бьют по кладке. Не полагайся на одни стены: расставь орудия и перехватывай артиллерию.';
 return {intel,checks,risk,damagedBlocks,criticalBlocks,
  resources:{stone:world.resources.stone,wood:world.resources.wood,stoneRemaining,woodRemaining},emplacements:quotes,recommendation};
}

export function canAffordDefense(world:World,kind:DefenseKind){
 const cost=DEFENSE_COSTS[kind];return !!cost&&world.resources.stone>=cost.stone&&world.resources.wood>=cost.wood;
}
