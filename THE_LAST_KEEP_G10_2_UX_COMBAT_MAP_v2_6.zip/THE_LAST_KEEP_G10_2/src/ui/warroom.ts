import {TOTAL_WAVES} from '../game/encounters.ts';
import {warBriefing} from '../game/readiness.ts';
import {drawMinimap} from './minimap.ts';
import {DEFENSE_COSTS,DEFENSE_SLOTS,type DefenseKind,type Defenses} from '../game/defenses.ts';
import type {World} from '../world/model.ts';
import type {Siege} from '../game/siege.ts';
import type {Gathering} from '../game/gathering.ts';
import type {Workers} from '../game/workers.ts';

const kinds:DefenseKind[]=['carrotTower','cheeseMortar','syrupSprayer'];
function safe(s:string){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));}

/** Pausable tactical briefing. Slot/type selection explicitly costs materials when installed. */
export function installWarRoom(world:World,siege:Siege,defenses:Defenses,gathering:Gathering,workers:Workers,
 onMessage:(message:string)=>void,onDeploy:()=>void,onNext:()=>void,onDevelopment:()=>void,onSelection:(kind:DefenseKind)=>void, getPlayer:()=>{x:number;z:number;yaw:number}=()=>({x:0,z:0,yaw:0})){
 const root=document.createElement('section');root.id='war-room';root.hidden=true;root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');
 root.setAttribute('aria-label','Военный совет');document.body.append(root);
 let chosenKind:DefenseKind='carrotTower',chosenSlot=0,focusReturn:HTMLElement|null=null;
 const isBetween=()=>siege.phase==='PREP'||siege.phase==='RESULT';
 const render=()=>{
  if(root.hidden)return;
  const intel=warBriefing(world,siege,defenses,gathering,workers);
  const cost=DEFENSE_COSTS[chosenKind];
  const slot=intel.emplacements[chosenSlot];
  const check=defenses.checkInstall(chosenSlot,chosenKind,siege.phase);
  const canInstall=check.ok;
  root.innerHTML=`<div class="war-panel"><header><div><p class="war-eyebrow">THE LAST KEEP · ВОЕННЫЙ СОВЕТ</p><h2>${safe(intel.intel?.title??'ОСАДЫ ЗАВЕРШЕНЫ')}</h2><p>${safe(intel.intel?.brief??'Все атаки отбиты.')}</p></div><button type="button" data-war="close" class="war-close">✕ Закрыть</button></header>
   <div class="war-data"><strong>Следующая волна: ${intel.intel?.wave??'—'} / ${TOTAL_WAVES}</strong><span>Нексус: ${siege.nexus}/100</span><span>Камень: ${Math.floor(world.resources.stone)} · дерево: ${Math.floor(world.resources.wood)} · знания: ${siege.research}</span><span>До атаки: ${Math.ceil(siege.time)} с ${siege.phase==='RESULT'?'(между волнами)':''}</span></div>
   <div class="war-columns"><article class="war-section"><h3>⚑ Разведданные</h3><p class="war-hint">${safe(intel.recommendation)}</p><div class="war-foes">${intel.intel?`Желе: ${intel.intel.jellies} · Прыгуны: ${intel.intel.hoppers} · Тараны: ${intel.intel.brutes} · Артиллерия: ${intel.intel.bombardiers}`:'—'}</div><h3>Готовность — ${intel.risk==='danger'?'критические риски':intel.risk==='caution'?'есть замечания':'без явных рисков'}</h3>
   <div class="war-checks">${intel.checks.map(c=>`<div class="war-check ${c.severity}"><b>${c.severity==='ready'?'✓':c.severity==='danger'?'!':'•'} ${safe(c.label)}</b><small>${safe(c.detail)}</small></div>`).join('')}</div><p class="war-hint">На карте остаются ${intel.resources.stoneRemaining} ед. камня и ${intel.resources.woodRemaining} ед. дерева в месторождениях.</p></article>
   <article class="war-section"><h3>🛡 План обороны</h3><p>Коснись номера площадки на карте или выбери кнопку ниже. Зелёные маркеры — установленные орудия. Все площадки внутри крепости.</p><canvas id="war-emplacement-map" width="360" height="360" aria-label="Карта размещения оборонительных орудий"></canvas><div class="war-slots">${intel.emplacements.map(s=>`<button type="button" data-war-slot="${s.slot}" class="${s.slot===chosenSlot?'selected':''}" aria-pressed="${s.slot===chosenSlot}">${s.slot+1} · ${safe(s.label)}${s.occupied?' 🔒':''}</button>`).join('')}</div>
   <div class="war-types">${kinds.map(kind=>`<button type="button" data-war-kind="${kind}" class="${kind===chosenKind?'selected':''}" aria-pressed="${kind===chosenKind}">${safe(DEFENSE_COSTS[kind].label)}<small>${DEFENSE_COSTS[kind].wood} 🌲 / ${DEFENSE_COSTS[kind].stone} 🪨</small></button>`).join('')}</div>
   <button type="button" class="war-install" data-war="install" ${canInstall?'':'disabled'}>Установить: ${safe(cost.label)} — позиция ${chosenSlot+1}</button>
   <small class="war-warning">${safe(check.reason)} · Площадка отмечена номером на миникарте.</small>
   <button type="button" class="war-secondary" data-war="heal" ${isBetween()&&siege.nexus<100&&world.resources.stone>=8&&world.resources.wood>=4?'':'disabled'}>◈ Починить Нексус: +25 HP · 8 🪨 / 4 🌲</button>
   <button type="button" class="war-secondary" data-war="development">⚒ Развитие крепости</button></article></div>
   <footer><p>Совет оценивает состояние крепости, но не гарантирует исход боя.</p>${siege.phase==='RESULT'?'<button data-war="next" type="button">Начать подготовку</button>':''}${siege.phase==='PREP'||siege.phase==='WARNING'?'<button data-war="deploy" type="button" class="war-deploy">⚔ Начать осаду сейчас</button>':''}</footer></div>`;
  const p=getPlayer();drawMinimap(root.querySelector<HTMLCanvasElement>('#war-emplacement-map')!,world,p,p.yaw,siege.raiders,intel.intel,true,workers.workers,undefined,defenses.placed);
 };
 const close=()=>{if(root.hidden)return;root.hidden=true;focusReturn?.focus();};
 const open=()=>{if(!root.hidden)return;focusReturn=document.activeElement instanceof HTMLElement?document.activeElement:null;
  root.hidden=false;render();root.querySelector<HTMLButtonElement>('.war-close')?.focus();};
 root.addEventListener('pointerdown',e=>{
  const canvas=(e.target as HTMLElement).closest<HTMLCanvasElement>('#war-emplacement-map');if(!canvas)return;
  const bounds=canvas.getBoundingClientRect();const x=((e.clientX-bounds.left)/bounds.width-.5)*48;
  const z=((e.clientY-bounds.top)/bounds.height-.5)*48;
  const slot=DEFENSE_SLOTS.findIndex(p=>Math.hypot(p.x-x,p.z-z)<2.2);
  if(slot>=0){chosenSlot=slot;render();}
 });
 root.addEventListener('click',e=>{
  const t=e.target;if(!(t instanceof Element))return;
  const button=t.closest<HTMLButtonElement>('button');if(!button||!root.contains(button))return;
  if(button.dataset.warSlot!==undefined){chosenSlot=Number(button.dataset.warSlot);render();return;}
  if(button.dataset.warKind!==undefined){const kind=button.dataset.warKind as DefenseKind;if(kinds.includes(kind)){chosenKind=kind;onSelection(kind);}render();return;}
  switch(button.dataset.war){
   case 'close':close();break;
   case 'install':{
    const result=defenses.installDetailed(chosenSlot,chosenKind,siege.phase);
    onMessage(result.reason);
    if(result.ok){const next=warBriefing(world,siege,defenses,gathering,workers).emplacements.find(s=>!s.occupied);if(next)chosenSlot=next.slot;}
    render();break;
   }
   case 'heal':{const result=siege.repairNexus();onMessage(result.reason);render();break;}
   case 'deploy':close();onDeploy();break;
   case 'next':onNext();render();break;
   case 'development':close();onDevelopment();break;
  }
 });
 root.addEventListener('pointerdown',e=>{if(e.target===root)close();});
 return {open,close,toggle:()=>root.hidden?open():close(),isOpen:()=>!root.hidden,refresh:render,
  selectKind:(kind:DefenseKind)=>{if(kinds.includes(kind)){chosenKind=kind;render();}}};
}
