import {TOOL_ORDER,TOOL_INFO,type Tool} from '../game/tools.ts';
/** Persistent clickable desktop toolbar; the HUD is frequently re-rendered. */
export function installDesktopToolbelt(onSelect:(tool:Tool)=>void){
 const root=document.createElement('nav');root.id='desktop-toolbelt';root.setAttribute('aria-label','Игровые инструменты');
 root.innerHTML=TOOL_ORDER.map((tool,i)=>`<button type="button" data-tool="${tool}" aria-pressed="${tool==='combat'}" title="${TOOL_INFO[tool].hint}"><kbd>${i+1}</kbd> ${TOOL_INFO[tool].icon} ${TOOL_INFO[tool].label}</button>`).join('');
 root.addEventListener('click',e=>{const btn=(e.target as HTMLElement).closest<HTMLButtonElement>('button[data-tool]');
  if(btn)onSelect(btn.dataset.tool as Tool);});
 document.body.append(root);
 return {root,setTool:(tool:Tool)=>{root.querySelectorAll<HTMLButtonElement>('button[data-tool]').forEach(b=>{
  const active=b.dataset.tool===tool;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));
 });}};
}
