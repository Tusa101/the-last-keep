# Validation — G10.2 v2.6.0

**Дата:** 2026-10-10. **Система:** Node.js 22, глобальный TypeScript, исходники v2.5.2 → v2.6.0.

## Успешно выполнено в текущей среде

| Проверка | Результат |
|---|---|
| `npm test` | **160 passed, 0 failed** |
| `npm run typecheck:core` | **PASS** |
| `npm run check:balance` | **PASS**; 6 волн симуляции, regression assertions |
| Unit test: стартовые орудийные места | **5/5 реально свободны** внутри `seedCastle`, проверка `checkInstall`, проверка покупки |
| Unit test: ошибка монтажа не тратит ресурсы | **PASS** |
| Unit test: номера площадок на миникарте | **1–5, PASS** |
| Unit test: 6 разных атак, спавны внутри границ | **PASS** |
| Unit test: победа только на 6-й волне | **PASS** |
| Unit test: сохранение победы старой 3-й волны | **PASS**, перевод в RESULT |
| Unit test: расход материалов на починку Нексуса | **PASS** |
| Unit test: выбор инструмента | **PASS** |

**Отдельная оговорка:** автоматический баланс-симулятор намеренно не стреляет оружием игрока, не ремонтирует и не строит в процессе. Даже 5 установленных орудий при таком сценарии терпят поражение в 5-й волне; это сигнал для плейтеста, а не провал скрипта, поскольку предполагается участие игрока.

## Непроверенные шаги (не выдавать за PASS)

- `npm install` в текущей среде — **неуспех (DNS EAI_AGAIN)**, пакеты `three`, `vite`, `playwright` недоступны локально.
- `npm run build` и **полный** TypeScript с типами Three.js — **не выполнены успешно** по указанной причине.
- Playwright UI-only matrix на 10 размерах экранов и production WebGL + Pages subpath — **перенесено в CI**.
- Проверка касаний, рендера и FPS на физическом Android/iPhone — **не проводилась**.
- Реальная победа в шести волнах и ручной баланс — **требуется прохождение**.

## Обязательный CI-gate

1. Обнаружение и распаковка ZIP v2.6.0.
2. `npm ci` (при lockfile) или `npm install`.
3. `npm test && npm run typecheck:core && npm run check:balance`.
4. `npm run build && npm run write:release && npm run verify:dist` (в контексте GitHub Pages base path).
5. Playwright проверяет **покупку орудия и создание настоящего Three.js mesh** через `#game-canvas[data-turret-models]`; далее `smoke:boot`, `smoke:ui`, `smoke:tutorial`, `smoke`, `smoke:slice`, `smoke:devices`.
6. Pages deployment **только при зелёном CI**.

Если CI упадёт, открыть неуспешный шаг и приложить логи / `smoke-debug` — это точнее, чем выпускать следующий ZIP без установленной причины.
