/** Independent onboarding + touch layout regression (does not require WebGL). */
import fs from 'node:fs';
import ts from 'typescript';
import {chromium} from 'playwright';
const css=fs.readFileSync(new URL('../src/ui/style.css',import.meta.url),'utf8');
const scripts=['../src/game/tools.ts','../src/game/tutorial.ts','../src/ui/tutorial.ts','../src/ui/mobile.ts'].map(rel=>{
 const source=fs.readFileSync(new URL(rel,import.meta.url),'utf8');
 return ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/^import .*?;\n/gm,'').replace(/^export /gm,'');
}).join('\n');
const sizes=[[280,653],[320,568],[360,640],[390,844],[430,932],[568,320],[667,375],[740,360],[844,390],[932,430],[1024,600]];
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
try{
 for(const [width,height] of sizes){
  const page=await browser.newPage({viewport:{width,height},hasTouch:true,isMobile:true});
  try{
   const errors=[];page.on('pageerror',e=>errors.push(e.message));
   await page.setContent(`<!doctype html><html lang="ru"><head><meta name="viewport" content="width=device-width, initial-scale=1,viewport-fit=cover"><style>${css}</style></head><body class="touch-mode"><div id="hud"><div class="mobile-status"><span class="mobile-stat danger">◈ 100/100</span><span class="mobile-stat">⚑ 1/6 · 1:30</span><span class="mobile-stat">🪨 20</span><span class="mobile-stat">🪵 20</span><span class="mobile-stat small">60 FPS</span></div></div></body></html>`);
   await page.addScriptTag({content:scripts+`
    window.tutorial = new Tutorial();
    window.mobile = installMobileControls(()=>{},()=>{});
    window.guide = installTutorialGuide(tutorial,{mobile:true,onChange:()=>{},onShowAction:step=>mobile.spotlightAction(step.action)});
   `});
   const overlaps=await page.evaluate(()=>{
    const queries=['#tutorial-guide','.mobile-status','.mobile-top','.mobile-toolbelt','.mobile-joystick','.mobile-actions'];
    const boxes=queries.map(name=>({name,rect:document.querySelector(name).getBoundingClientRect()}));
    const overlap=[];
    for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){
     const a=boxes[i],b=boxes[j];
     const area=Math.max(0,Math.min(a.rect.right,b.rect.right)-Math.max(a.rect.left,b.rect.left))*Math.max(0,Math.min(a.rect.bottom,b.rect.bottom)-Math.max(a.rect.top,b.rect.top));
     if(area>15)overlap.push(`${a.name}/${b.name}`);
    }
    return overlap;
   });
   if(overlaps.length)throw Error(`Overlaps at ${width}x${height}: ${overlaps.join(', ')}`);
   // Complete movement; tutorial should advance, and deep menu action should be reachable.
   await page.evaluate(()=>{tutorial.mark('moved');guide.refresh();});
   await page.locator('#tutorial-guide [data-tutorial=show]').tap();
   if(!(await page.locator('.mobile-toolbelt [data-tool=gather]').evaluate(e=>e.classList.contains('tutorial-spotlight'))))throw Error('Gather tool not spotlighted');
   await page.evaluate(()=>{guide.setSuppressed(true);});
   if(!(await page.locator('#tutorial-guide').isHidden()))throw Error('Guidance did not hide behind modal');
   // Help is now in the toolbelt and need not open the command menu.
   await page.evaluate(()=>{guide.setSuppressed(false);});
   await page.locator('#tutorial-guide [data-tutorial=hide]').tap();
   if(!(await page.locator('#tutorial-guide').isHidden()))throw Error('Hide tutorial failed');
   if(errors.length)throw Error('Browser errors: '+errors.join('; '));
   console.log(`PASS tutorial responsive/touch ${width}x${height}`);
  }finally{await page.close();}
 }
}finally{await browser.close();}
